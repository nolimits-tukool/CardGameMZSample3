﻿/*==========================================================================
 NLM_CardLayoutMZ.js
----------------------------------------------------------------------------
 (C)2025 NoLimits
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
----------------------------------------------------------------------------
 Version
 1.0.0 2025/09/16 初版
============================================================================*/

/*:
 * @target MZ
 * @plugindesc MZ用カードレイアウト・プラグイン (v1.0.0)
 * @author ノリミツ (NoLimits)
 * 
 * @command itemPictureSet
 * @text アイテム画ピクチャ設置
 * @desc 任意のカード画のピクチャを画面上中央に不透明度ゼロ（透明）で　設置します（この後「ピクチャの移動」で利用して下さい）
 * 
 * @arg itemId
 * @text アイテムID
 * @desc 設置したいカード画のアイテムID
 * @type item
 * @default 0
 * 
 * @arg idVar
 * @text アイテムIDの変数ID
 * @desc アイテムIDを「変数」で指定する場合の変数ID　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg picId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVar
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command skillPictureSet
 * @text スキル画ピクチャ設置
 * @desc 任意のカード画のピクチャを画面上中央に不透明度ゼロ（透明）で　設置します（この後「ピクチャの移動」で利用して下さい）
 * 
 * @arg itemId
 * @text スキルID
 * @desc 設置したいカード画のスキルID
 * @type skill
 * @default 0
 * 
 * @arg idVar
 * @text スキルIDの変数ID
 * @desc スキルIDを「変数」で指定する場合の変数ID　　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg picId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVar
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command enemyPictureSet
 * @text エネミー画ピクチャ設置
 * @desc 任意のカード画のピクチャを画面上中央に不透明度ゼロ（透明）で　設置します（この後「ピクチャの移動」で利用して下さい）
 * 
 * @arg itemId
 * @text エネミーID
 * @desc 設置したいカード画のエネミーID
 * @type enemy
 * @default 0
 * 
 * @arg idVar
 * @text エネミーIDの変数ID
 * @desc エネミーIDを「変数」で指定する場合の変数ID　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg picId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVar
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command actorPictureSet
 * @text アクター画ピクチャ設置
 * @desc 任意のカード画のピクチャを画面上中央に不透明度ゼロ（透明）で　設置します（この後「ピクチャの移動」で利用して下さい）
 * 
 * @arg itemId
 * @text アクターID
 * @desc 設置したいカード画のアクターID
 * @type actor
 * @default 0
 * 
 * @arg idVar
 * @text アクターIDの変数ID
 * @desc アクターIDを「変数」で指定する場合の変数ID　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg picId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVar
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command weaponPictureSet
 * @text 武器画ピクチャ設置
 * @desc 任意のカード画のピクチャを画面上中央に不透明度ゼロ（透明）で　設置します（この後「ピクチャの移動」で利用して下さい）
 * 
 * @arg itemId
 * @text 武器ID
 * @desc 設置したいカード画の武器ID
 * @type weapon
 * @default 0
 * 
 * @arg idVar
 * @text 武器IDの変数ID
 * @desc 武器IDを「変数」で指定する場合の変数ID　　　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg picId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVar
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command armorPictureSet
 * @text 防具画ピクチャ設置
 * @desc 任意のカード画のピクチャを画面上中央に不透明度ゼロ（透明）で　設置します（この後「ピクチャの移動」で利用して下さい）
 *
 * @arg itemId
 * @text 防具ID
 * @desc 設置したいカード画の防具ID
 * @type armor
 * @default 0
 * 
 * @arg idVar
 * @text 防具IDの変数ID
 * @desc 防具IDを「変数」で指定する場合の変数ID　　　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg picId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVar
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command reverseSet
 * @text 裏面画ピクチャ設置
 * @desc 裏面画(カードと同サイズの1枚絵)のピクチャを画面上中央に不透明度ゼロ(透明)で設置します（この後「ピクチャの移動」で利用）
 * 
 * @arg reverseFile
 * @text 裏面画ファイル
 * @desc 裏面画のファイル名（picturesフォルダのみ指定できます）　　（なしの場合パラメータの共通裏面画を使用)
 * @type file
 * @dir img/pictures
 * 
 * @arg reverseType
 * @text サイズ元タイプ
 * @desc サイズ元となるカードのタイプ
 * @type select
 * @option アイテム･武器･防具
 * @value 1
 * @option スキル
 * @value 0
 * @option エネミー
 * @value 4
 * @option アクター
 * @value 5
 * @default 1
 * 
 * @arg rAutoScale
 * @text 裏面画の自動拡縮
 * @desc 裏面画の自動スケーリング
 * @type select
 * @option 0：共通裏面画と同じ
 * @value 0
 * @option 1：原寸大（自動拡縮しない）
 * @value 1
 * @option 2：縦横比を維持して縦尺に合わせ自動拡縮
 * @value 2
 * @option 3：縦横比を維持して横尺に合わせ自動拡縮
 * @value 3
 * @option 4：縦横比を無視して最大に自動拡縮
 * @value 4
 * @default 0
 * 
 * @arg reversePicId
 * @text ピクチャ番号
 * @desc ピクチャの移動などで指定するピクチャの番号　　　　　　　　（2倍画が拡大率100％となるので調節を）
 * @type number
 * @min 1
 * @default 32
 * 
 * @command pictureCopy
 * @text ピクチャをコピー
 * @desc ピクチャをコピーし、同じ状態で重ねて表示します
 * 
 * @arg originId
 * @text コピー元ピクチャ番号
 * @desc コピー元のピクチャ番号
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg originVarId
 * @text コピー元ピクチャ変数ID
 * @desc コピー元ピクチャ番号を「変数」で指定する場合の変数ID　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg copyId
 * @text コピー先ピクチャ番号
 * @desc コピー先のピクチャ番号
 * @type number
 * @min 1
 * @default 21
 * 
 * @arg copyVarId
 * @text コピー先ピクチャ変数ID
 * @desc コピー先ピクチャ番号を「変数」で指定する場合の変数ID　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command picturesErase
 * @text ピクチャをまとめて消去
 * @desc 複数のピクチャをまとめて消去します。多数のピクチャを同時に消したい時に便利です
 * 
 * @arg fromId
 * @text 消去開始ピクチャ番号
 * @desc 消去を開始するピクチャ番号（1以上の値）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg toId
 * @text 消去終了ピクチャ番号
 * @desc 消去を終了するピクチャ番号
 * @type number
 * @min 1
 * @default 50
 * 
 * @command pictureRotationStop
 * @text ピクチャの回転と停止
 * @desc ピクチャを回転させ、指定角度で停止させます　　　　　　　　　（回転中のウエイトなしのため、必要なら この後ウエイト追加を）
 * 
 * @arg pictureId
 * @text ピクチャ番号
 * @desc 回転させたいピクチャの番号
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg picVariable
 * @text ピクチャ番号の変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg angle
 * @text 停止角度
 * @desc 停止させる角度（-360～360）（一回転以上は不可）　　　　　　（入力角度は回転角でなく、停止位置の角度である点に注意）
 * @type number
 * @max 360
 * @min -360
 * @default 90
 * 
 * @arg angVariable
 * @text 停止角度の変数ID
 * @desc 停止角度を「変数」で指定する場合の変数ID　　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg speed
 * @text 回転速度
 * @desc 時計回りに回転する速度（マイナス値だと反時計回りの速度）
 * @type number
 * @min -999
 * @default 20
 * 
 * @arg spdVariable
 * @text 回転速度の変数ID
 * @desc 回転速度を「変数」で指定する場合の変数ID　　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @command pictureUpdate
 * @text ピクチャ画像更新
 * @desc 数値が変化した時など、ピクチャ画像を更新(再描画)したい時に利用　（多数更新すると処理が重くなるので注意）
 * 
 * @arg fromId
 * @text 更新開始ピクチャ番号
 * @desc 更新を開始するピクチャ番号（1以上の値）
 * @type number
 * @min 1
 * @default 1
 * 
 * @arg toId
 * @text 更新終了ピクチャ番号
 * @desc 更新を終了するピクチャ番号（0の時は開始番号のみ更新）　　　（開始番号より大きい値の時は まとめて更新ができます）
 * @type number
 * @default 0
 * 
 * @arg varId
 * @text ピクチャ番号変数ID
 * @desc ピクチャ番号を「変数」で指定する場合の変数ID（変数IDを指定すると上の定数値は無効。変数指定ではその番号1枚のみ更新）
 * @type variable
 * @default 0
 * 
 * @command cardUpdate
 * @text カード化画像更新
 * @desc 戦闘時においてカード化した敵画像・SVアクターを更新(再描画)する　（数値変更が反映されない時のみ利用)（ピクチャは更新されない)
 * 
 * 
 * @param itemOn
 * @text ◆◆アイテムで適用◆◆
 * @desc アイテム欄（武器・防具含め）でカード画表示を適用　　　　　（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param itemCols
 * @parent itemOn
 * @text アイテム項目の列数
 * @desc アイテム項目の列数（デフォルト：6、ツクールデフォ：2）
 * @type number
 * @default 6
 * 
 * @param itemLayout
 * @parent itemOn
 * @text アイテム･レイアウト
 * @desc アイテム項目のレイアウト（上から順に描画されるため（下の行ほど前面）、文字・数値を図形・画像の下に配置するのがコツ)
 * @type struct<Layout>[]
 * @default ["{\"type\":\"四角描画\",\"memoNum\":\"9\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"6\",\"color2\":\"20\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"メモ指定メイン画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"細枠描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"8\",\"py\":\"8\",\"color1\":\"15\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"-8\",\"height\":\"-8\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"四角描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"170\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"15\",\"color2\":\"15\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"32\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"アイコン\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"32\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"名前(制御文字不可)\",\"memoNum\":\"8\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"34\",\"py\":\"2\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"-6\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"円描画\",\"memoNum\":\"0\",\"noDispTime\":\"個数が非表示時\",\"opacity\":\"254\",\"startPoint\":\"右下\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"18\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"個数(スキル以外)\",\"memoNum\":\"0\",\"noDispTime\":\"個数が非表示時\",\"opacity\":\"255\",\"startPoint\":\"右下\",\"px\":\"-13\",\"py\":\"-17\",\"color1\":\"27\",\"color2\":\"0\",\"fontSize\":\"26\",\"align\":\"center\",\"width\":\"26\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"自由文字(制御文字可)\",\"memoNum\":\"1\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"2\",\"py\":\"32\",\"color1\":\"17\",\"color2\":\"0\",\"fontSize\":\"18\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}"]
 * 
 * @param itemIconMag
 * @parent itemOn
 * @text アイコン画倍率％
 * @desc メイン画指定がない時のアイコン画表示の自動スケーリング後の修正倍率％（デフォルト：50）（0 の時はアイコン画表示なし）
 * @type number
 * @default 50
 * 
 * @param weaponOpacity
 * @parent itemOn
 * @text 武器防具は暗転化しない
 * @desc 武器・防具は常に全て暗転化しない（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param shopMag
 * @parent itemOn
 * @text 店カード画倍率％
 * @desc 店でアイテム購入時に表示するカード画の倍率％（デフォルト：150）（0 の時は表示なし）（武器・防具は表示できません）
 * @type number
 * @default 150
 * 
 * @param equipMag
 * @parent itemOn
 * @text 装備カード画倍率％
 * @desc 装備Slotで表示するカード画の倍率％（デフォルト：100）　　（0 の時は表示なし）（個数は非表示になる）
 * @type number
 * @default 100
 * 
 * @param equipPx
 * @parent equipMag
 * @text 装備カード画補正X
 * @desc 装備Slotのカード画の補正X座標（デフォルト：0）
 * @type number
 * @min -9999
 * @default 0
 * 
 * @param skillOn
 * @text ◆◆スキルで適用◆◆
 * @desc スキル欄でカード画表示を適用（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param skillCols
 * @parent skillOn
 * @text スキル項目の列数
 * @desc スキル項目の列数（デフォルト：6、ツクールデフォ：2）
 * @type number
 * @default 6
 * 
 * @param skillLayout
 * @parent skillOn
 * @text スキル･レイアウト
 * @desc スキル項目のレイアウト（上から順に描画されるため（下の行ほど前面）、文字・数値を図形・画像の下に配置するのがコツ)
 * @type struct<Layout>[]
 * @default ["{\"type\":\"四角描画\",\"memoNum\":\"9\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"6\",\"color2\":\"20\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"メモ指定メイン画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"細枠描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"8\",\"py\":\"8\",\"color1\":\"15\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"-8\",\"height\":\"-8\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"四角描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"170\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"15\",\"color2\":\"15\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"32\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"アイコン\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"32\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"名前(制御文字不可)\",\"memoNum\":\"8\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"34\",\"py\":\"2\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"-6\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"円描画\",\"memoNum\":\"0\",\"noDispTime\":\"MPコストがゼロ時\",\"opacity\":\"254\",\"startPoint\":\"右下\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"1\",\"color2\":\"0\",\"fontSize\":\"18\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"MPコスト値\",\"memoNum\":\"0\",\"noDispTime\":\"MPコストがゼロ時\",\"opacity\":\"255\",\"startPoint\":\"右下\",\"px\":\"-13\",\"py\":\"-17\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"26\",\"align\":\"center\",\"width\":\"26\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"円描画\",\"memoNum\":\"0\",\"noDispTime\":\"TPコストがゼロ時\",\"opacity\":\"254\",\"startPoint\":\"左下\",\"px\":\"16\",\"py\":\"0\",\"color1\":\"3\",\"color2\":\"0\",\"fontSize\":\"18\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"TPコスト値\",\"memoNum\":\"0\",\"noDispTime\":\"TPコストがゼロ時\",\"opacity\":\"255\",\"startPoint\":\"左下\",\"px\":\"2\",\"py\":\"-17\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"26\",\"align\":\"center\",\"width\":\"26\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"自由文字(制御文字可)\",\"memoNum\":\"1\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"2\",\"py\":\"32\",\"color1\":\"17\",\"color2\":\"0\",\"fontSize\":\"18\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}"]
 * 
 * @param skillIconMag
 * @parent skillOn
 * @text アイコン画倍率％
 * @desc メイン画指定がない時のアイコン画表示の自動スケーリング後の修正倍率％（デフォルト：50）（0 の時はアイコン画表示なし）
 * @type number
 * @default 50
 * 
 * @param enemyOn
 * @text ◆◆エネミーで適用◆◆
 * @desc 戦闘エネミーウインドウでカード画表示を適用（デフォルト：OFF）（OFFでも敵画像倍率％は設定可。色相値は無視される)
 * @type boolean
 * @default false
 * 
 * @param enemyCols
 * @parent enemyOn
 * @text エネミー項目の列数
 * @desc エネミー項目の列数（デフォルト：6、ツクールデフォ：2）
 * @type number
 * @default 6
 * 
 * @param enemyLayout
 * @parent enemyOn
 * @text エネミー･レイアウト
 * @desc エネミー項目のレイアウト（上から順に描画されるため（下の行ほど前面）、文字・数値を図形・画像の下に配置するのがコツ)
 * @type struct<Elayout>[]
 * @default ["{\"type\":\"四角描画\",\"memoNum\":\"9\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"6\",\"color2\":\"20\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"メモ指定メイン画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"細枠描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"7\",\"py\":\"7\",\"color1\":\"15\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"-8\",\"height\":\"-8\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"四角描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"195\",\"startPoint\":\"左下\",\"px\":\"0\",\"py\":\"-17\",\"color1\":\"15\",\"color2\":\"15\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"32\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"名前(制御文字不可)\",\"memoNum\":\"8\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左下\",\"px\":\"6\",\"py\":\"-16\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"center\",\"width\":\"-6\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"四角描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"30\",\"color2\":\"15\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"83\",\"height\":\"30\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"HP値\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"-1\",\"py\":\"-2\",\"color1\":\"17\",\"color2\":\"0\",\"fontSize\":\"26\",\"align\":\"center\",\"width\":\"85\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"円描画\",\"memoNum\":\"0\",\"noDispTime\":\"MPがゼロ時\",\"opacity\":\"254\",\"startPoint\":\"右上\",\"px\":\"0\",\"py\":\"16\",\"color1\":\"12\",\"color2\":\"0\",\"fontSize\":\"18\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"MP値\",\"memoNum\":\"0\",\"noDispTime\":\"MPがゼロ時\",\"opacity\":\"254\",\"startPoint\":\"右上\",\"px\":\"-17\",\"py\":\"-1\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"24\",\"align\":\"center\",\"width\":\"32\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"自由文字(制御文字可)\",\"memoNum\":\"1\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"-1\",\"py\":\"27\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"24\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}"]
 * 
 * @param enemyMag
 * @parent enemyOn
 * @text 敵画像倍率％
 * @desc メイン画指定がない時の敵画像表示の自動スケーリング後の修正倍率％（デフォルト：60）（0 の時は敵画像表示なし）
 * @type number
 * @default 60
 * 
 * @param enemyCardMag
 * @parent enemyOn
 * @text 敵カード化倍率％
 * @desc (ウインドウ内でなく）敵画像本体を置換したカード画の倍率％(デフォルト：80)（0だと置換せず。<nxmag>で個別設定可)
 * @type number
 * @default 80
 * 
 * @param actorOn
 * @text ◆◆アクターで適用◆◆
 * @desc 戦闘(アクター)ステータスウインドウでカード画表示を適用（デフォルト：OFF）(OFFでもSVアクター倍率%や中央寄せは設定可)
 * @type boolean
 * @default false
 * 
 * @param actorCols
 * @parent actorOn
 * @text アクター項目の列数
 * @desc アクター項目の列数（ツクールデフォ：4）（少ないとメンバーが表示外になったり、多いとゲージがはみ出したりします）
 * @type number
 * @default 4
 * 
 * @param actorLayout
 * @parent actorOn
 * @text アクター･レイアウト
 * @desc アクター項目のレイアウト（上から順に描画されるため（下の行ほど前面）、文字・数値を図形・画像の下に配置するのがコツ)
 * @type struct<Elayout>[]
 * @default ["{\"type\":\"四角描画\",\"memoNum\":\"9\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"6\",\"color2\":\"20\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"メモ指定メイン画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"細枠描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"8\",\"py\":\"8\",\"color1\":\"15\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"-8\",\"height\":\"-8\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"円描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"14\",\"py\":\"46\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"16\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"レベル(アクターのみ)\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"-2\",\"py\":\"30\",\"color1\":\"27\",\"color2\":\"0\",\"fontSize\":\"24\",\"align\":\"center\",\"width\":\"32\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"四角描画\",\"memoNum\":\"0\",\"noDispTime\":\"常に描画する\",\"opacity\":\"195\",\"startPoint\":\"左上\",\"px\":\"0\",\"py\":\"0\",\"color1\":\"15\",\"color2\":\"15\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"32\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"名前(制御文字不可)\",\"memoNum\":\"8\",\"noDispTime\":\"常に描画する\",\"opacity\":\"255\",\"startPoint\":\"左上\",\"px\":\"4\",\"py\":\"1\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"20\",\"align\":\"center\",\"width\":\"-34\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"四角描画\",\"memoNum\":\"0\",\"noDispTime\":\"ウインドウ以外\",\"opacity\":\"100\",\"startPoint\":\"左下\",\"px\":\"0\",\"py\":\"-61\",\"color1\":\"15\",\"color2\":\"15\",\"fontSize\":\"20\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}","{\"type\":\"自由文字(制御文字可)\",\"memoNum\":\"1\",\"noDispTime\":\"メモ<ctxt1>の指定なし\",\"opacity\":\"254\",\"startPoint\":\"左上\",\"px\":\"6\",\"py\":\"30\",\"color1\":\"0\",\"color2\":\"0\",\"fontSize\":\"28\",\"align\":\"left\",\"width\":\"0\",\"height\":\"0\",\"comText\":\"\",\"autoScale\":\"2\",\"layerFile\":\"\",\"script\":\"\"}"]
 * 
 * @param actorMag
 * @parent actorOn
 * @text アクター倍率％
 * @desc メイン画指定がない時のSVアクター画の自動スケーリング後の修正倍率％（デフォルト：60）（0 の時はSV画像表示なし）
 * @type number
 * @default 60
 * 
 * @param gaugeAdd
 * @parent actorOn
 * @text ゲージ追加
 * @desc 戦闘ステータスでHP･MPゲージを追加表示（デフォルト：ON）（TPゲージ有無はシステム1で設定。SVカード化には追加不可)
 * @type boolean
 * @default true
 * 
 * @param actorCentering
 * @parent actorOn
 * @text アクター中央寄せ
 * @desc 戦闘ステータスでアクター数に応じて中央寄せ表示　　　　　　（デフォルト：ON）(「アクターで適用」OFFでも設定可）
 * @type boolean
 * @default true
 * 
 * @param actorCardMag
 * @parent actorOn
 * @text SVカード化倍率％
 * @desc (ステータス内でなく）SVアクター本体を置換したカード画倍率％（デフォルト：0)（0だと置換せず。<nxmag>で個別設定可)
 * @type number
 * @default 0
 * 
 * @param others
 * @text ◆◆その他の設定◆◆
 * 
 * @param colSpacing
 * @parent others
 * @text 項目の列間
 * @desc アイテム･スキル･エネミー･アクターのウインドウ内での列間　（デフォルト：4、ツクールデフォ：16）
 * @type number
 * @default 4
 * 
 * @param reverseComFile
 * @parent others
 * @text 共通裏面画ファイル
 * @desc 指定がない場合の裏面画（カードと同サイズの1枚絵）ファイル（アクター死亡時・MZ用カードゲームプラグインでも利用)
 * @type file
 * @dir img/pictures
 * 
 * @param rAutoScale
 * @parent reverseComFile
 * @text 共通裏面画の自動拡縮
 * @desc 共通裏面画の自動スケーリング　　　　　　　　　　　　　　　　（デフォルト：4：縦横比を無視して最大に自動拡縮）
 * @type select
 * @option 1：原寸大（自動拡縮しない）
 * @value 1
 * @option 2：縦横比を維持して縦尺に合わせ自動拡縮
 * @value 2
 * @option 3：縦横比を維持して横尺に合わせ自動拡縮
 * @value 3
 * @option 4：縦横比を無視して最大に自動拡縮
 * @value 4
 * @default 4
 * 
 * @param successSwId
 * @parent others
 * @text ピクチャ成功スイッチID
 * @desc カード（裏面画は除く）の合成ピクチャ生成に成功した時にONになるスイッチID（成否を知りたい時のみ設定して下さい）
 * @type switch
 * @default 0
 * 
 * @param developerConsole
 * @parent others
 * @text デベロッパツール表示
 * @desc カード画像の実際のサイズをデベロッパツールのConsoleに表示（デフォルト：ON）（括弧内はピクチャサイズ）
 * @type boolean
 * @default true
 * 
 * 
 * @noteParam CIPic
 * @noteDir img/pictures/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWPic
 * @noteDir img/pictures/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMPic
 * @noteDir img/pictures/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSPic
 * @noteDir img/pictures/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CEPic
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CIEne
 * @noteDir img/enemies/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWEne
 * @noteDir img/enemies/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMEne
 * @noteDir img/enemies/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSEne
 * @noteDir img/enemies/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CEEne
 * @noteDir img/enemies/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CISve
 * @noteDir img/sv_enemies/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWSve
 * @noteDir img/sv_enemies/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMSve
 * @noteDir img/sv_enemies/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSSve
 * @noteDir img/sv_enemies/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CESve
 * @noteDir img/sv_enemies/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CICha
 * @noteDir img/characters/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWCha
 * @noteDir img/characters/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMCha
 * @noteDir img/characters/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSCha
 * @noteDir img/characters/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CECha
 * @noteDir img/characters/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CIFac
 * @noteDir img/faces/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWFac
 * @noteDir img/faces/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMFac
 * @noteDir img/faces/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSFac
 * @noteDir img/faces/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CEFac
 * @noteDir img/faces/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CISva
 * @noteDir img/sv_actors/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWSva
 * @noteDir img/sv_actors/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMSva
 * @noteDir img/sv_actors/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSSva
 * @noteDir img/sv_actors/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CESva
 * @noteDir img/sv_actors/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CIAni
 * @noteDir img/animations/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWAni
 * @noteDir img/animations/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMAni
 * @noteDir img/animations/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSAni
 * @noteDir img/animations/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CEAni
 * @noteDir img/animations/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam CITil
 * @noteDir img/tilesets/
 * @noteType file
 * @noteData items
 * 
 * @noteParam CWTil
 * @noteDir img/tilesets/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam CMTil
 * @noteDir img/tilesets/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam CSTil
 * @noteDir img/tilesets/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam CETil
 * @noteDir img/tilesets/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam LIPic1
 * @noteDir img/pictures/
 * @noteType file
 * @noteData items
 * 
 * @noteParam LWPic1
 * @noteDir img/pictures/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam LMPic1
 * @noteDir img/pictures/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam LSPic1
 * @noteDir img/pictures/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam LEPic1
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam LAPic1
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam LIPic2
 * @noteDir img/pictures/
 * @noteType file
 * @noteData items
 * 
 * @noteParam LWPic2
 * @noteDir img/pictures/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam LMPic2
 * @noteDir img/pictures/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam LSPic2
 * @noteDir img/pictures/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam LEPic2
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam LAPic2
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam LIPic3
 * @noteDir img/pictures/
 * @noteType file
 * @noteData items
 * 
 * @noteParam LWPic3
 * @noteDir img/pictures/
 * @noteType file
 * @noteData weapons
 * 
 * @noteParam LMPic3
 * @noteDir img/pictures/
 * @noteType file
 * @noteData armors
 * 
 * @noteParam LSPic3
 * @noteDir img/pictures/
 * @noteType file
 * @noteData skills
 * 
 * @noteParam LEPic3
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * @noteParam LAPic3
 * @noteDir img/pictures/
 * @noteType file
 * @noteData enemies
 * 
 * 
 * @help
 * 
 * 【RPGツクールMZ専用プラグイン】
 * アイテム・スキルなどの項目欄をカード風の見た目にレイアウトします
 * 　パラメータの「レイアウト」項目（画像・文字・四角形・円など）を順番に合成
 * して描画することで、画像ツールがなくても、カード画をデザインできるという
 * 新感覚のプラグインです！
 * 　また、エネミー本体・SVアクターをカード化することや、プラグインコマンドで
 * カード画を合成ピクチャとして設置することも可能です
 * 
 * 【メモ欄でのメイン画の指定方法】(レイアウト内に「メモ指定メイン画」が必須)
 * 　　アイテムの場合　　<CIPic:ファイル名>
 * 　　スキルの場合　　　<CSPic:ファイル名>
 * 　　武器の場合　　　　<CWPic:ファイル名>
 * 　　防具の場合　　　　<CMPic:ファイル名>
 * 　　エネミーの場合　　<CEPic:ファイル名>
 * 　　アクターの場合　　<CAPic:ファイル名>　　をメモ欄に書くことで画像を指定
 *　　　　　例) 　<CIPic:Actor1_6>　　　　　　（ファイル名に「.png」は不要）
 * 　メモ指定がない場合、アイコン画などを拡大表示することもできます
 * 
 * 　少し複雑ですが、pictures以外のフォルダ指定や画像補足情報の追記もできます
 * 　補足情報 <cadd:> は省略することも可（省略時、倍率と連結数は1、その他の値0)
 * （X,Y座標はゼロから数えはじめる、連結数はX,Y軸上で連続するタイル数）
 * 　 複数画像が並ぶ例　①②③④　　  ③は 　X座標2、Y座標0　と数える
 * 　　　　　　　　　　 ⑤⑥⑦⑧　　  ⑥⑦は X座標1、Y座標1、X連結数2、Y連結数1
 * 
 * 　enemiesフォルダ　　<CIEne:ファイル名> <cadd:倍率,X補正,Y補正>
 * 　sv_enemiesフォルダ <CISve:ファイル名> <cadd:倍率,X補正,Y補正>
 * 　picturesフォルダ 　<CIPic:ファイル名> <cadd:倍率,X補正,Y補正>
 * 　charactersフォルダ <CICha:ファイル名> <cadd:X座標,Y座標,倍率,X補正,Y補正>
 * 　facesフォルダ　　　<CIFac:ファイル名> <cadd:X座標,Y座標,倍率,X補正,Y補正>
 * 　sv_actorsフォルダ　<CISva:ファイル名> <cadd:X座標,Y座標,倍率,X補正,Y補正>
 * 　systemフォルダ　　 <CISys:ファイル名> <cadd:X座標,Y座標,倍率,X補正,Y補正>
 * 　　　　　　　　　　 <CISys:IconSet>    <cadd:アイコンID, 倍率,X補正,Y補正>
 * 　　（※ ファイル名が Baloon, States, Weapons1-3, IconSet のみ対応）
 *   animationsフォルダ <CIAni:ファイル名> <cadd:X座標,Y座標,倍率,X補正,Y補正>
 * 　　（※ imgフォルダ下にanimationsフォルダを作成後,MV規格アニメを入れた場合)
 * 　tilesetsフォルダ　 <CITil:ファイル名>
 * 　　　　　　　　　　 <cadd:X座標,Y座標,X連結数,Y連結数,倍率,X補正,Y補正>
 * 
 * 　※ スキルメモの場合は「CS～」,武器メモの場合は「CW～」,防具メモの場合は
 * 　　「CM～」,エネミーメモの場合は「CE～」,アクターメモの場合は「CA～」に置換
 * 
 *   例)　<CEEne:Goblin>  <cadd:1.2, 0,-10>　　<CSCha:Actor1>   <cadd:10,4>
 * 　　 　<CWSys:IconSet> <cadd:64, 0.6>　 　　<CMTil:Inside_B> <cadd:13,9,3,2>
 * 
 * 【メモ欄でのレイアウトの個別置換・消去】
 * 　（レイヤー番号(1-3),メモ置換番号(1-9)はレイアウト内での指定と一致させる）
 * 
 * 　<LIPicレイヤー番号:ファイル名>　：　アイテムメモでレイヤーを指定画像に置換
 * 　<LSPicレイヤー番号:ファイル名>　：　スキルのメモでレイヤーを指定画像に置換
 * 　<LWPicレイヤー番号:ファイル名>　：　武器のメモで、レイヤーを指定画像に置換
 * 　<LMPicレイヤー番号:ファイル名>　：　防具のメモで、レイヤーを指定画像に置換
 * 　<LEPicレイヤー番号:ファイル名>　：　エネミーメモでレイヤーを指定画像に置換
 * 　<LAPicレイヤー番号:ファイル名>　：　アクターメモでレイヤーを指定画像に置換
 * 　　例)　<LIPic2:Actor1_2>　　　　　 （レイヤーはpicturesフォルダのみ指定可)
 * 
 * 　<ctxtメモ置換番号:文章>　　　　 ： 「自由文字」を記述文章に置換
 * 　　例)　<ctxt6:デッキ計\v[31]枚>　　　　　（名前・説明文は置換不可）
 * 　<ccolorメモ置換番号:色番号>　 ：　文字・数値・図形の色1を変更(色番号:0-32)
 * 　　例)　<ccolor4:17>　　　  　 　　　　　 （色2は変更不可）
 * 　<vcolorメモ置換番号:変数ID>　 ：　指定した変数値が色1の色番号と置換
 * 　　例)　<vcolor3:41>
 * 　<NoLayout:レイアウト番号をカンマで区切って羅列>
 * 　　　　　　　　　　　　　　　　羅列したレイアウト番号の描画が消去される
 * 　　例)　<NoLayout:2,3,5>　　（レイアウト番号はレイアウト項目の上からの順番)
 * 　<nxmag:倍率(%)>　(エネミー･アクターメモ欄のみ) ： カード化倍率を個別に変更
 * 　　例)　<nxmag:150>　　　　　　　　　　　　　 （0 にすると置換されなくなる)
 * 
 * 【注意】
 * 　・ メモ欄記述（ファイル名含め）は大文字・小文字が識別されるので,書き間違い
 * 　　によるエラーに注意して下さい
 * 　・ 画像サイズが大きい場合やレイアウトが多すぎる場合、画像描画に失敗や遅延
 * 　　が発生することがある点は、ご了承ください（特にブラウザプレイ時）
 * 　・ 画像は拡大縮小処理の際、画質劣化や線が残る場合があります
 * 　・ 変数やスクリプトによる値が変化しても設置済ピクチャには反映されないので,
 * 　　反映したい時はプラグインコマンド「ピクチャ画像更新」をご利用ください
 * 　・ エネミーレイアウトにて、色相が無視（敵カード化ではレイアウト全体に反映)
 * 　　される点、HP･MP･TP値の変動がピクチャ化できない点は、仕様です
 * 【補足】
 * 　・ プラグインコマンドで設置したピクチャは不透明度0(透明)のため「ピクチャの
 * 　  移動」で不透明度を上げて下さい（拡大率100％で実寸の2倍サイズとなります)
 * 　・ パラメータのレイアウト各行はダブルクリックで入力し,下から上へのドラッグ
 * 　　右クリックでのコピー・貼り付け等が利用可能です
 * 　・ パラメータ「◆◆～で適用◆◆」がOFFでも、レイアウト項目はピクチャ生成や
 * 　　敵画像・SVアクターのカード化に反映されます
 * 　・ メイン画や同一のレイヤー画はレイアウト内に複数作成してもファイルや自動
 * 　　拡縮が一番下行にある設定に統一されます（座標や不透明度は個別に設定可）
 * 　・ アイテムの合成ピクチャ生成時は強制的に「個数が非表示」状態になります
 * 　・「NLM_CardGameMZ.js」プラグインがなくても、<TPcost:値> <MPcost:値> が
 * 　　アイテムメモ欄にあるとコスト値を表示できますが、同プラグインがないと、
 * 　　コスト消費の動作は行なわれません
 * 　・ カードの画像サイズはウインドウ幅とパラメータ値から自動計算されますが、
 * 　　デベロッパツールのConsoleにてドット数を確認表示できます
 * 　・ メモ欄に <CIPic:> 等でファイル名の記載があれば、そのファイルは「未使用
 * 　　ファイル削除」の対象外になります
 * 　・ 3年前に作成した「NLM_CardItemSelectMZ.js」の改良・発展型になります
 * 【おまけ機能】（サンプルプロジェクトのために用意したので利用しなくてもOK）
 * 　・「用語」の HP(略)、MP(略)、TP(略)で \i[数値] 記入でアイコンが表示可
 * 　・「文章の表示」において 一瞬表示の制御文字 \> が 次行も継続実行される
 * 　・「スクリプト」内において、変数値は v[] で省略記入が可能（v[11]など）
 * 
 * 利用規約はMITライセンスの通りです。CGの著作権は遵守して下さい
 * 　私個人の趣味で作成し、無償で提供しているものですので、このプラグインで
 * 生じた問題・不備に対し、制作者が責任を負う義務はないことをご理解ください
 */

/*~struct~Layout:
 * 
 * @param type
 * @text タイプ
 * @desc レイアウト･タイプ　　　　　　　　　　　　　　　　　　　　（「メモ指定メイン画」を必ず1つは入れて下さい）
 * @type select
 * @option メモ指定メイン画
 * @option レイヤー画1
 * @option レイヤー画2
 * @option レイヤー画3
 * @option 四角描画
 * @option 円描画
 * @option 細枠描画
 * @option 自由文字(制御文字可)
 * @option 自由文字(制御文字不可)
 * @option 名前(制御文字不可)
 * @option アイコン
 * @option 個数(スキル以外)
 * @option MPコスト値
 * @option TPコスト値
 * @option 説明文(制御文字可)
 * @option スクリプト値(上級者向け)
 * @default メモ指定メイン画
 * 
 * @param memoNum
 * @parent type
 * @text メモ置換番号
 * @desc 自由文字・色1をメモ欄で置換設定できる番号(1-9)　　　　　　（0だと変更不可(非表示は可)だが、いくつでも設定できる)
 * @type number
 * @max 9
 * @default 0
 * 
 * @param noDispTime
 * @parent type
 * @text 特定状況で非表示
 * @desc 特定の状況で、このレイアウトのみ非表示にする
 * @type select
 * @option 常に描画する
 * @option 個数が非表示時
 * @option 個数が1または非表示時
 * @option 大事なものの時
 * @option 武器・防具の時
 * @option 通常アイテム以外
 * @option MPコストがゼロ時
 * @option TPコストがゼロ時
 * @option MP･TPコストが共にゼロ時
 * @option 合成ピクチャ時
 * @option 合成ピクチャ以外
 * @option メモ<ctxt1>の指定なし
 * @option メモ<ctxt2>の指定なし
 * @option メモ<ctxt3>の指定なし
 * @option メモ<ctxt4>の指定なし
 * @option メモ<ctxt5>の指定なし
 * @option スクリプト値がゼロ時
 * @default 常に描画する
 * 
 * @param opacity
 * @parent type
 * @text 不透明度
 * @desc 文字・数値・図形・画像の不透明度（0で透明、255で不透過。255の場合のみ使用不可時で暗転化する）
 * @type number
 * @max 255
 * @default 255
 * 
 * @param startPoint
 * @text 座標始点
 * @desc 座標の始まりの点
 * @type select
 * @option 左上
 * @option 左下
 * @option 右上
 * @option 右下
 * @option 中央
 * @default 左上
 * 
 * @param px
 * @parent startPoint
 * @text X座標補正
 * @desc 始点からのX座標補正（左へ補正したい場合はマイナス値入力）
 * @type number
 * @min -99999
 * @default 0
 *
 * @param py
 * @parent startPoint
 * @text Y座標補正
 * @desc 始点からのY座標補正（上へ補正したい場合はマイナス値入力）
 * @type number
 * @min -99999
 * @default 0
 *
 * @param color1
 * @text 色1
 * @desc 文字・数値・図形の色（フォントカラー指定(0-32)。メモ欄で　置換可。スキルコストのツクールデフォはMP：23、TP：29）
 * @type number
 * @max 32
 * @default 0
 * 
 * @param color2
 * @parent color1
 * @text 色2
 * @desc 四角描画時のみ,色2(グラデーション)を指定（マイナスを付けると水平グラデーションになる。色1と同値でグラデーションなし)
 * @type number
 * @max 32
 * @min -32
 * @default 0
 * 
 * @param fontSize
 * @text フォントサイズ･円径
 * @desc 文字・数値のフォントサイズ、アイコンドット数、円描画の半径（ツクールデフォはフォント：26、アイコン：32）
 * @type number
 * @default 20
 * 
 * @param align
 * @parent fontSize
 * @text 数値・文章の揃え
 * @desc 数値(個数･コスト値)・名前・自由文字(制御文字不可のみ)を　揃える方法(次項目で横幅を指定)(制御文字可のものは設定不可)
 * @type select
 * @option 左揃え
 * @value left
 * @option 中央揃え
 * @value center
 * @option 右揃え
 * @value right
 * @default left
 * 
 * @param width
 * @text 四角形・文章の横幅
 * @desc 四角･細枠描画,文章,数値の横幅ドット（0で最大幅、マイナス値で最大幅からの減少値となる) (制御文字可の文章は設定不可)
 * @type number
 * @min -9999
 * @default 0
 * 
 * @param height
 * @parent width
 * @text 四角形の高さ
 * @desc 四角・細枠描画の高さドット（0で最大高、マイナス値で最大高からの減少値となる）
 * @type number
 * @min -9999
 * @default 0
 * 
 * @param comText
 * @text 自由文字
 * @desc タイプ「自由文字」で共通表示する文章（メモ置換番号1以上の際はメモ欄指定で置き換え可。制御文字の可否はタイプで指定）
 * @type string
 * 
 * @param autoScale
 * @text 画像の自動拡縮
 * @desc メモ指定メイン画、レイヤー画の自動スケーリング（メイン画とレイヤー画1-3それぞれにつき1種類ずつしか設定できません）
 * @type select
 * @option 1：原寸大（自動拡縮しない）
 * @value 1
 * @option 2：縦横比を維持して縦尺に合わせ自動拡縮
 * @value 2
 * @option 3：縦横比を維持して横尺に合わせ自動拡縮
 * @value 3
 * @option 4：縦横比を無視して最大に自動拡縮
 * @value 4
 * @default 2
 * 
 * @param layerFile
 * @parent autoScale
 * @text レイヤーファイル
 * @desc タイプ「レイヤー画」での共通ファイル指定　　　　　　　　　（メモ欄指定で置き換え可。picturesフォルダのみ利用可）
 * @type file
 * @dir img/pictures
 * 
 * @param script
 * @text スクリプト(上級者向け)
 * @desc タイプ「スクリプト値」でのみ表示。それ以外では直前計算のみ実行（アイテム･スキルIDは cId, 変数値は v[] で置換される）
 * @type multiline_string
 * 
 */

/*~struct~Elayout:
 * 
 * @param type
 * @text タイプ
 * @desc レイアウト･タイプ　　　　　　　　　　　　　　　　　　　　（「メモ指定メイン画」を必ず1つは入れて下さい）
 * @type select
 * @option メモ指定メイン画
 * @option レイヤー画1
 * @option レイヤー画2
 * @option レイヤー画3
 * @option 四角描画
 * @option 円描画
 * @option 細枠描画
 * @option 自由文字(制御文字可)
 * @option 自由文字(制御文字不可)
 * @option 名前(制御文字不可)
 * @option HP値
 * @option MP値
 * @option TP値
 * @option 最大HP値
 * @option 最大MP値
 * @option 攻撃力値
 * @option 防御力値
 * @option 魔法力値
 * @option 魔法防御値
 * @option 敏捷性値
 * @option 運値
 * @option レベル(アクターのみ)
 * @option 経験値
 * @option 所持金
 * @option プロフィール(アクターのみ)
 * @option スクリプト値(上級者向け)
 * @default メモ指定メイン画
 * 
 * @param memoNum
 * @parent type
 * @text メモ置換番号
 * @desc 自由文字・色1をメモ欄で置換設定できる番号(1-9)　　　　　　（0だと変更不可(非表示は可)だが、いくつでも設定できる)
 * @type number
 * @max 9
 * @default 0
 * 
 * @param noDispTime
 * @parent type
 * @text 特定状況で非表示
 * @desc 特定の状況で、このレイアウトのみ非表示にする
 * @type select
 * @option 常に描画する
 * @option MPがゼロ時
 * @option TPがゼロ時
 * @option MP･TPが共にゼロ時
 * @option MPがゼロかピクチャ時
 * @option TPがゼロかピクチャ時
 * @option MP･TPが共にゼロかピクチャ時
 * @option ウインドウ表示時
 * @option ウインドウとピクチャ時
 * @option ウインドウ以外
 * @option ウインドウ以外(ピクチャ許容)
 * @option 合成ピクチャ時
 * @option 合成ピクチャ以外
 * @option メモ<ctxt1>の指定なし
 * @option メモ<ctxt2>の指定なし
 * @option メモ<ctxt3>の指定なし
 * @option メモ<ctxt4>の指定なし
 * @option メモ<ctxt5>の指定なし
 * @option スクリプト値がゼロ時
 * @default 常に描画する
 * 
 * @param opacity
 * @parent type
 * @text 不透明度
 * @desc 文字・数値・図形・画像の不透明度（0で透明、255で不透過。255の場合のみ使用不可時で暗転化する）
 * @type number
 * @max 255
 * @default 255
 * 
 * @param startPoint
 * @text 座標始点
 * @desc 座標の始まりの点
 * @type select
 * @option 左上
 * @option 左下
 * @option 右上
 * @option 右下
 * @option 中央
 * @default 左上
 * 
 * @param px
 * @parent startPoint
 * @text X座標補正
 * @desc 始点からのX座標補正（左へ補正したい場合はマイナス値入力）
 * @type number
 * @min -99999
 * @default 0
 *
 * @param py
 * @parent startPoint
 * @text Y座標補正
 * @desc 始点からのY座標補正（上へ補正したい場合はマイナス値入力）
 * @type number
 * @min -99999
 * @default 0
 *
 * @param color1
 * @text 色1
 * @desc 文字・数値・図形の色（フォントカラー指定(0-32)。メモ欄で　置換可）
 * @type number
 * @max 32
 * @default 0
 * 
 * @param color2
 * @parent color1
 * @text 色2
 * @desc 四角描画時のみ,色2(グラデーション)を指定（マイナスを付けると水平グラデーションになる。色1と同値でグラデーションなし)
 * @type number
 * @max 32
 * @min -32
 * @default 0
 * 
 * @param fontSize
 * @text フォントサイズ･円径
 * @desc 文字・数値のフォントサイズ、円描画の半径（ツクールデフォはフォント：26）
 * @type number
 * @default 20
 * 
 * @param align
 * @parent fontSize
 * @text 数値・文章の揃え
 * @desc 数値・名前・自由文字(制御文字不可のみ)を揃える方法(次項目で横幅を指定)(制御文字可のものは設定不可)
 * @type select
 * @option 左揃え
 * @value left
 * @option 中央揃え
 * @value center
 * @option 右揃え
 * @value right
 * @default left
 * 
 * @param width
 * @text 四角形・文章の横幅
 * @desc 四角･細枠描画,文章,数値の横幅ドット（0で最大幅、マイナス値で最大幅からの減少値となる) (制御文字可の文章は設定不可)
 * @type number
 * @min -9999
 * @default 0
 * 
 * @param height
 * @parent width
 * @text 四角形の高さ
 * @desc 四角・細枠描画の高さドット（0で最大高、マイナス値で最大高からの減少値となる）
 * @type number
 * @min -9999
 * @default 0
 * 
 * @param comText
 * @text 自由文字
 * @desc タイプ「自由文字」で共通表示する文章（メモ置換番号1以上の際はメモ欄指定で置き換え可。制御文字の可否はタイプで指定）
 * @type string
 * 
 * @param autoScale
 * @text 画像の自動拡縮
 * @desc メモ指定メイン画、レイヤー画の自動スケーリング（メイン画とレイヤー画1-3それぞれにつき1種類ずつしか設定できません）
 * @type select
 * @option 1：原寸大（自動拡縮しない）
 * @value 1
 * @option 2：縦横比を維持して縦尺に合わせ自動拡縮
 * @value 2
 * @option 3：縦横比を維持して横尺に合わせ自動拡縮
 * @value 3
 * @option 4：縦横比を無視して最大に自動拡縮
 * @value 4
 * @default 2
 * 
 * @param layerFile
 * @parent autoScale
 * @text レイヤーファイル
 * @desc タイプ「レイヤー画」での共通ファイル指定　　　　　　　　　（メモ欄指定で置き換え可。picturesフォルダのみ利用可）
 * @type file
 * @dir img/pictures
 * 
 * @param script
 * @text スクリプト(上級者向け)
 * @desc タイプ「スクリプト値」でのみ表示。それ以外では直前計算のみ実行（a が利用可、b は利用不可。変数値は v[]で置換される）
 * @type multiline_string
 * 
 */

(() => {
  "use strict";

  const pluginName = "NLM_CardLayoutMZ";
  const NLCLparam = PluginManager.parameters(pluginName);
  NLCLparam.itemCols     = parseInt(NLCLparam.itemCols)         || 2;
  NLCLparam.skillCols    = parseInt(NLCLparam.skillCols)        || 2;
  NLCLparam.enemyCols    = parseInt(NLCLparam.enemyCols)        || 2;
  NLCLparam.actorCols    = parseInt(NLCLparam.actorCols)        || 4;
  NLCLparam.itemIconMag  = Number(NLCLparam.itemIconMag)  / 100 || 0;
  NLCLparam.skillIconMag = Number(NLCLparam.skillIconMag) / 100 || 0;
  NLCLparam.shopMag      = Number(NLCLparam.shopMag)      / 100 || 0;
  NLCLparam.equipMag     = Number(NLCLparam.equipMag)     / 100 || 0;
  NLCLparam.enemyMag     = Number(NLCLparam.enemyMag)     / 100 || 0;
  NLCLparam.actorMag     = Number(NLCLparam.actorMag)     / 100 || 0;
  NLCLparam.colSpacing   = Number(NLCLparam.colSpacing)         || 0;
  NLCLparam.rAutoScale   = Number(NLCLparam.rAutoScale)         || 4;

  const NLMGparam = PluginManager.parameters("NLM_CardGameMZ"); // パラメータ引継ぎ

  let NLCLitemMaxNum = 0;
  let NLCLfirstBoot  = true;
  let NLCLitemLayout  = [];
  let NLCLskillLayout = [];
  let NLCLenemyLayout = [];
  let NLCLactorLayout = [];
  let NLCLitemMainScale  = 2;
  let NLCLskillMainScale = 2;
  let NLCLenemyMainScale = 2;
  let NLCLactorMainScale = 2;
  let NLCLbitmap   = null;
  let $gameEnemies = null;

  // 隠しパラメータ
  DataManager._NLCLitemHeight      = 176; // アイテム高さ（戦闘ウインドウに合わせて 176 を推奨）
  DataManager._NLCLskillHeight     = 176; // スキル高さ
  DataManager._NLCLenemyHeight     = 176; // エネミー高さ
  DataManager._NLCLactorHeight     = 194; // アクター高さ（戦闘ステータスに合わせて 194 を推奨）
  DataManager._NLCLitemColSpacing  = -1;  // アイテム列間（-1の場合、パラメータ「項目の列間」の値となる）
  DataManager._NLCLskillColSpacing = -1;  // スキル列間
  DataManager._NLCLenemyColSpacing = -1;  // エネミー列間
  DataManager._NLCLactorColSpacing = -1;  // アクター(戦闘ステータス)列間
  DataManager._NLCLpreload  = true;       // 各Window起動時に画像プリロード
  DataManager._NLCLctxt     = "ctxt";
  DataManager._NLCLccolor   = "ccolor";
  DataManager._NLCLvcolor   = "vcolor";
  DataManager._NLCLnoLayout = "NoLayout";
  DataManager._NLCLnxmag    = "nxmag";
  DataManager._NLCLshopPx   = 0; // ショップでのカード画の補正X座標
  DataManager._NLCLshopPy   = 0; // ショップでのカード画の補正Y座標
  DataManager._NLCLequipPy  = 0; // 装備slotでのカード画の補正Y座標
  DataManager._NLCLshopWeaponPic = false; // ショップでの武器・防具のカード画描画
  DataManager._NLCLequipItemNum  = false; // 装備slotでの個数表示
  DataManager._NLCLequipStatusX  = -1;    // 装備パラメータX座標（0でデフォルト値、-1で3/5値）
  DataManager._NLCLenemyStateX   = 0; // エネミーステートアイコン補正X座標
  DataManager._NLCLenemyStateY   = 0; // エネミーステートアイコン補正Y座標
  DataManager._NLCLgaugeX   = 0; // 戦闘ステータスのゲージ補正X座標
  DataManager._NLCLgaugeY   = 0; // 戦闘ステータスのゲージ補正Y座標
  DataManager._NLCLeventItemRow  = 8; // イベントアイテム選択での表示行数（NLM_CardGameMZ.js併用時は必ず8に）
  DataManager._NLCLdeleteItemBack  = true; // アイテム背部黒スプライト消去
  DataManager._NLCLdeleteSkillBack = true; // スキルの背部黒スプライト消去
  DataManager._NLCLdeleteEnemyBack = true; // エネミー背部黒スプライト消去
  DataManager._NLCLdeleteActorBack = true; // アクター背部黒スプライト消去
  DataManager._NLCLgaugeLabelIcon  = true; // ゲージラベルのアイコン化を許可
  DataManager._NLCLmessageFast     = true; // 文章表示で次行も一瞬表示を継続
  DataManager._NLCLscriptV         = true; // スクリプトにて変数値をv[]で置換
  DataManager._NLCLstartTurnUpdate = true; // 戦闘ターン開始時に画像更新
  DataManager._NLCLendTurnUpdate   = true; // 戦闘ターン終了時に画像更
  DataManager._NLCLstatusCursorAlpha = 0.7;// 戦闘ステータスのカーソル濃度
  DataManager._NLCLweaponDraw   = false; // SVアクターカード化で武器アニメを描画するか
  DataManager._NLCLweaponFront  = false; // 武器をSVアクターの前面で描画（全員カード化以外では非推奨）
  DataManager._NLCLnoReverse    = false; // アクター死亡時に裏面画を使用せず、そのままにする
  DataManager._NLCLdeathNoGauge = true;  // アクター死亡裏面時にゲージを表示しない
  DataManager._NLCLdeathNoIcon  = false; // アクター死亡裏面時にステートアイコンを表示しない
  DataManager._NLCLmpDamage     = false; // カード化アクターがMPダメージでも後退する
  DataManager._NLCLcostRate     = true;  // 戦闘アクション中もMP・TP消費率を推測して表示

  const _DM_createGameObjects = DataManager.createGameObjects;
  DataManager.createGameObjects = function() {
    _DM_createGameObjects.apply(this, arguments);
    $gameEnemies = new Game_Enemies(); // 新設
  };

  const _DM_makeSaveContents = DataManager.makeSaveContents;
  DataManager.makeSaveContents = function() {
    const contents = _DM_makeSaveContents.apply(this, arguments);
    contents.enemies = $gameEnemies;
    return contents;
  };

  const _DM_extractSaveContents = DataManager.extractSaveContents;
  DataManager.extractSaveContents = function(contents) {
    _DM_extractSaveContents.apply(this, arguments);
    $gameEnemies = contents.enemies;
  };

  DataManager.NLMstruct = function(param) { // 構造体変換
    if (!param.length) return param;
    const str = JSON.parse(param);
    return str.map(str => JSON.parse(str));
  };

  DataManager.NLCLtr = function(item) {
    if (this.isWeapon(item)) return 2;
    if (this.isArmor(item))  return 3;
    return 1;
  };

  DataManager.NLCLprefix = function(tr) {
    return tr === 1 ? "CI" : tr === 2 ? "CW" : tr === 3 ? "CM" : 
           tr === 4 ? "CE" : tr === 5 ? "CA" : "CS";
  };

  DataManager.NLCLfolder = function(item, tr) {
    const pre = this.NLCLprefix(tr);
    const arr = ["Pic", "Ene", "Sve", "Cha", "Fac", "Sva", "Ani", "Sys", "Til"];
    for (const elm of arr) {
      if (item.meta[pre + elm]) return elm;
    }
    if (tr < 4 && this.NLCLnoPicIcon(item, tr)) return "Sys";
    if (tr === 4 && NLCLparam.enemyMag) return $dataSystem.optSideView ? "Sve" : "Ene";
    if (tr === 5) return "Sva";
    return null;
  };

  DataManager.NLCLfile = function(item, tr, folder) {
    const pre  = this.NLCLprefix(tr);
    const file = folder ? item.meta[pre + folder] : null;
    if (!file && folder === "Sys") {
      return "IconSet";
    } else if (!file && (folder === "Ene" || folder === "Sve" || folder === "Sva")) {
      return item.battlerName;
    } else if (typeof file !== "string" || file === "ファイル名") { // メモ欄サンプル対策
      return null;
    } else {
      return file;
    }
  };

  DataManager.NLCLnoPicIcon = function(item, tr) {
    const npIcon = tr ? NLCLparam.itemIconMag : NLCLparam.skillIconMag;
    return npIcon && item.iconIndex;
  };

  DataManager.NLCLheight = function(tr) { // 高さ
    return tr === 0 ? this._NLCLskillHeight :
           tr === 4 ? this._NLCLenemyHeight :
           tr === 5 ? this._NLCLactorHeight :
           this._NLCLitemHeight;
  };

  DataManager.NLCLcols = function(tr) { // 列数
    return tr === 0 ? NLCLparam.skillCols :
           tr === 4 ? NLCLparam.enemyCols :
           tr === 5 ? NLCLparam.actorCols :
           NLCLparam.itemCols;
  };

  DataManager.NLCLcolSpacing = function(tr) { // 列間
    const sp = tr === 0 ? this._NLCLskillColSpacing :
               tr === 4 ? this._NLCLenemyColSpacing :
               tr === 5 ? this._NLCLactorColSpacing :
               this._NLCLitemColSpacing;
    return sp === -1 ? NLCLparam.colSpacing : sp;
  };

  DataManager.NLCLitemWidth = function(tr) {
    const gW = $dataSystem.advanced.uiAreaWidth - (tr === 5 ? 192 : 8);
    const cl = this.NLCLcols(tr);
    const cS = this.NLCLcolSpacing(tr);
    const width = (gW - 24) / cl - 5 - cS; // カーソルサイズに合わせて補正
    return Math.round(width);
  };

  DataManager.NLCLitemHeight = function(tr) {
    return this.NLCLheight(tr) - (tr === 5 ? 4 : 8);
  };

  DataManager.NLCLscaleM = function(tr) {
    return tr === 0 ? NLCLskillMainScale :
           tr === 4 ? NLCLenemyMainScale :
           tr === 5 ? NLCLactorMainScale :
           NLCLitemMainScale;
  };

  DataManager.NLCLlayout = function(tr) {
    return tr === 0 ? NLCLskillLayout :
           tr === 4 ? NLCLenemyLayout :
           tr === 5 ? NLCLactorLayout :
           NLCLitemLayout;
  };

  DataManager.NLCLenemyCardMag = function(enemy) { // エネミーのカード化判定
    const meta = enemy.enemy().meta[DataManager._NLCLnxmag];
    if (meta === "0") return 0;
    return Number(meta || NLCLparam.enemyCardMag || 0) / 100;
  };

  DataManager.NLCLactorCardMag = function(actor) { // SVアクターのカード化判定
    const meta = actor.actor().meta[DataManager._NLCLnxmag];
    if (meta === "0") return 0;
    return Number(meta || NLCLparam.actorCardMag || 0) / 100;
  };

  DataManager.NLCLcategolize = function(item, tr, preload) {
    if (!item || item.NLCLfolder !== undefined) return;
    const folder = this.NLCLfolder(item, tr);
    const fileM  = this.NLCLfile(item, tr, folder);
    const width  = this.NLCLitemWidth(tr);
    const height = this.NLCLitemHeight(tr);
    item.NLCLfolder = folder;
    item.NLCLfileM  = fileM;
    if (preload) {
      const scaleM  = this.NLCLscaleM(tr);
      const bitmapM = ImageManager.NLCLload(item, tr);
      bitmapM.addLoadListener(function() {
        const div = ImageManager.NLCLdivMake(item, fileM, bitmapM, folder, tr);
        item.NLCLdiv  = div;
        item.NLCLcalM = ImageManager.NLCLcalc(div, width, height, scaleM);
      }.bind(this));
    }
    const layout = this.NLCLlayout(tr);
    for (const obj of layout) {
      if (obj.type.slice(0,5) === "レイヤー画") {
        const num  = obj.type.slice(5);
        const pre  = tr === 1 ? "LI" : tr === 2 ? "LW" : tr === 3 ? "LM" :
                     tr === 4 ? "LE" : tr === 5 ? "LA" : "LS";
        const file = item.meta[pre + "Pic" + num] || obj.layerFile;
        item["NLCLfile" + num] = file;
        if (preload) {
          const bitmap = ImageManager.loadPicture(file);
          bitmap.addLoadListener(function() {
            const div0  = [0, 0, bitmap.width, bitmap.height, 1, 0, 0];
            const scale = obj.autoScale || 4;
            item["NLCLcal" + num] = ImageManager.NLCLcalc(div0, width, height, scale);
          }.bind(this));
        }
      }
    }
  };

  DataManager.NLCLitemsCategolize = function(items, tr) {
    items.forEach(item => this.NLCLcategolize(item, tr, 1));
  };

  DataManager.NLCLpreLoad = function(tr) {
    if (this._NLCLpreload) {
      switch(tr) {
        case 1:
          this.NLCLitemsCategolize($dataItems,   1);
          this.NLCLitemsCategolize($dataWeapons, 2);
          this.NLCLitemsCategolize($dataArmors,  3);
          break;
        case 4:
          this.NLCLitemsCategolize($dataEnemies, 4);
          break;
        case 5:
          this.NLCLitemsCategolize($dataActors,  5);
          break;
        default:
          this.NLCLitemsCategolize($dataSkills,  0);
          break;
      }
    }
  };

  DataManager.NLCLdeveloperConsole = function() {
    if (NLCLparam.developerConsole === "true") {
      const io = NLCLparam.itemOn  === "true" ? "on " : "off";
      const so = NLCLparam.skillOn === "true" ? "on " : "off";
      const eo = NLCLparam.enemyOn === "true" ? "on " : "off";
      const ao = NLCLparam.actorOn === "true" ? "on " : "off";
      const iw = this.NLCLitemWidth(1);
      const ih = this.NLCLitemHeight(1);
      const sw = this.NLCLitemWidth(0);
      const sh = this.NLCLitemHeight(0);
      const ew = this.NLCLitemWidth(4);
      const eh = this.NLCLitemHeight(4);
      const aw = this.NLCLitemWidth(5);
      const ah = this.NLCLitemHeight(5);
      console.log("itemCardSize (", io, "):", iw, "x", ih, " (", iw*2, "x", ih*2, ")");
      console.log("skillCardSize(", so, "):", sw, "x", sh, " (", sw*2, "x", sh*2, ")");
      console.log("enemyCardSize(", eo, "):", ew, "x", eh, " (", ew*2, "x", eh*2, ")");
      console.log("actorCardSize(", ao, "):", aw, "x", ah, " (", aw*2, "x", ah*2, ")");
    }
  };

// ImageManager関係
  ImageManager.NLCLcalc = function(div, itemWidth, itemHeight, autoScale) { // 座標スケーリング計算
    let shiftX = 0, shiftY = 0, plusX = 0, plusY = 0, iWidth = itemWidth, iHeight = itemHeight;
    let width  = div[2];
    let height = div[3];
    let wmag = div[4] || 1;
    let hmag = div[4] || 1;
    if (autoScale === 2) { // 縦横比を維持して縦尺に合わせ自動拡縮
      wmag *= iHeight / height;
      hmag = wmag;
    }
    if (autoScale === 3) { // 縦横比を維持して横尺に合わせ自動拡縮
      wmag *= iWidth / width;
      hmag = wmag;
    }
    if (autoScale === 4) { // 縦横比を無視して最大に自動拡縮
      wmag *= iWidth  / width;
      hmag *= iHeight / height;
    }
    const mshiftX = (width  * wmag - iWidth)  / 2;
    const mshiftY = (height * hmag - iHeight) / 2;
    if (mshiftX <= 0 && mshiftY <= 0) {
      plusX   = -mshiftX;
      plusY   = -mshiftY;
      iWidth  = width  * wmag;
      iHeight = height * hmag;
    } else if (mshiftX >= 0 && mshiftY <= 0) {
      shiftX  = mshiftX / wmag;
      width   = iWidth  / wmag;
      plusY   = -mshiftY;
      iHeight = height * hmag;
    } else if (mshiftX <= 0 && mshiftY >= 0) {
      plusX   = -mshiftX;
      iWidth  = width * wmag;
      shiftY  = mshiftY / hmag;
      height  = iHeight / hmag;
    } else {
      shiftX  = mshiftX / wmag;
      shiftY  = mshiftY / hmag;
      width   = iWidth  / wmag;
      height  = iHeight / hmag;
    }
    shiftX += div[0];
    shiftY += div[1];
    const arr = [shiftX, shiftY, width, height, plusX, plusY, iWidth, iHeight];
    return arr.map((elm) => Math.round(elm));
  };

  ImageManager.NLCLdivMake = function(item, file, bitmap, folder, tr) {
    const width  = bitmap.width;
    const height = bitmap.height;
    if (!file || !folder) return [0, 0, width, height, 1, 0, 0];
    const add = this.NLCLaddData(item);
    let horDiv = 0, verDiv = 0, blockW = 1, blockH = 1, m = 1, xp = 0, yp = 0;
    let chara = 0, face = 0;
    switch (folder) {
      case "Ene":
      case "Sve":
        if (!add[0] && NLCLparam.enemyMag) {
          add[0] = NLCLparam.enemyMag;
        }
        return [0, 0, width, height, add[0], add[1], add[2]];
      case "Cha":
        const dollar = this.isBigCharacter(file);
        horDiv = dollar ? 3 : 12;
        verDiv = dollar ? 4 :  8;
        m  = add[2];
        xp = add[3];
        yp = add[4];
        chara  = 1;
        break;
      case "Fac":
        horDiv = 4;
        verDiv = 2;
        m  = add[2];
        xp = add[3];
        yp = add[4];
        face   = 1;
        break;
      case "Sva":
        horDiv = 9;
        verDiv = 6;
        m  = !add[0] ? NLCLparam.actorMag : add[2];
        xp = add[3];
        yp = add[4];
        chara  = 1;
        break;
      case "Ani":
        horDiv = width  / 192;
        verDiv = height / 192;
        m  = add[2];
        xp = add[3];
        yp = add[4];
        face   = 1;
        chara  = 1;
        break;
      case "Sys":
        switch (file) {
          case "IconSet":
            if (!add[0] && DataManager.NLCLnoPicIcon(item, tr)) {
              add[0] = item.iconIndex;
              if (!add[1]) {
                add[1] = tr ? NLCLparam.itemIconMag : NLCLparam.skillIconMag;
              }
            }
            horDiv = 16;
            verDiv = height / this.iconHeight;
            m = add[1];
            const index = add[0];
            add[0] = index % 16;
            add[1] = Math.floor(index / 16);
            xp = add[2];
            yp = add[3];
            break;
          case "Balloon":
            horDiv = 8;
            verDiv = 15;
            m  = add[2];
            xp = add[3];
            yp = add[4];
            break;
          case "States":
            horDiv = 8;
            verDiv = 10;
            m  = add[2];
            xp = add[3];
            yp = add[4];
            break;
          case "Weapons1":
          case "Weapons2":
          case "Weapons3":
            horDiv = width  / 96;
            verDiv = height / 64;
            m  = add[2];
            xp = add[3];
            yp = add[4];
            break;
          default:
            return [0, 0, width, height, add[0], add[1], add[2]];
        }
        break;
      case "Til":
        const tSize = $dataSystem.tileSize || 48;
        horDiv = width  / tSize;
        verDiv = height / tSize;
        blockW = add[2] || 1;
        blockH = add[3] || 1;
        m  = add[4];
        xp = add[5];
        yp = add[6];
        face   = 1;
        chara  = 1;
        break;
      default:
        return [0, 0, width, height, add[0], add[1], add[2]];
    }
    if (add[0] >= horDiv) {add[0] = horDiv - 1;}
    if (add[1] >= verDiv) {add[1] = verDiv - 1;}
    const x  = add[0] * width  / horDiv + face;
    const y  = add[1] * height / verDiv + chara;
    const dw = width  / horDiv * blockW - face  * 2;
    const dh = height / verDiv * blockH - chara * 2;
    return [x, y, dw, dh, m, xp, yp];
  };

  ImageManager.NLCLaddData = function(item) {
    if (item) {
      const add = item.meta["cadd"];
      if (add) {
        const arr = add.split(",");
        for (let i=0; i < 7; i++) {
          arr[i] = Number(arr[i]) || 0;
        }
        return arr;
      }
    }
    return [0,0,0,0,0,0,0];
  };

  ImageManager.NLCLload = function(item, tr) {
    const file = item.NLCLfileM;
    if (file) {
      switch (item.NLCLfolder) {
        case "Pic":
          return this.loadPicture(file);
        case "Ene":
          return this.loadEnemy(file);
        case "Sve":
          return this.loadSvEnemy(file);
        case "Cha":
          return this.loadCharacter(file);
        case "Fac":
          return this.loadFace(file);
        case "Sva":
          return this.loadSvActor(file);
        case "Ani":
          return this.loadAnimation(file);
        case "Sys":
          return this.loadSystem(file);
        case "Til":
          return this.loadTileset(file);
      }
    }
    return this._emptyBitmap;
  };

// BattleManager関係（戦闘中の画像定期更新）
  const _BattleManager_startTurn = BattleManager.startTurn;
  BattleManager.startTurn = function() { // ターン開始時
    _BattleManager_startTurn.apply(this, arguments);
    if (DataManager._NLCLstartTurnUpdate) {
      $gameTemp.updateBattlerCard();
    }
  };

  const _BattleManager_endTurn = BattleManager.endTurn;
  BattleManager.endTurn = function() { // ターン終了時
    _BattleManager_endTurn.apply(this, arguments);
    if (DataManager._NLCLendTurnUpdate) {
      $gameTemp.updateBattlerCard();
    }
  };

  const _BattleManager_gainRewards = BattleManager.gainRewards;
  BattleManager.gainRewards = function() { // 戦闘勝利時
    _BattleManager_gainRewards.apply(this, arguments)
    $gameTemp.updateBattlerCard();
  };

// PluginManager関係
  PluginManager.NLCLvariables = function(varId, constant) {
    const vId = Number(varId);
    return Number(vId ? $gameVariables.value(vId) : constant) || 0;
  };

  PluginManager.NLCLpictureSet = function(items, itemId, idVar, picId, picVar) {
    const cId = this.NLCLvariables(idVar, itemId); 
    const pId = this.NLCLvariables(picVar, picId);
    $gameScreen.cardPictureSet(items[cId], pId);
  };

  PluginManager.registerCommand(pluginName, "itemPictureSet", args => { // アイテム画ピクチャ設置
    PluginManager.NLCLpictureSet($dataItems, args.itemId, args.idVar, args.picId, args.picVar);
  });

  PluginManager.registerCommand(pluginName, "skillPictureSet", args => { // スキル画ピクチャ設置
    PluginManager.NLCLpictureSet($dataSkills, args.itemId, args.idVar, args.picId, args.picVar);
  });

  PluginManager.registerCommand(pluginName, "enemyPictureSet", args => { // エネミー画ピクチャ設置
    PluginManager.NLCLpictureSet($dataEnemies, args.itemId, args.idVar, args.picId, args.picVar);
  });

  PluginManager.registerCommand(pluginName, "actorPictureSet", args => { // アクター画ピクチャ設置
    PluginManager.NLCLpictureSet($dataActors, args.itemId, args.idVar, args.picId, args.picVar);
  });

  PluginManager.registerCommand(pluginName, "weaponPictureSet", args => { // 武器画ピクチャ設置
    PluginManager.NLCLpictureSet($dataWeapons, args.itemId, args.idVar, args.picId, args.picVar);
  });

  PluginManager.registerCommand(pluginName, "armorPictureSet", args => { // 防具画ピクチャ設置
    PluginManager.NLCLpictureSet($dataArmors, args.itemId, args.idVar, args.picId, args.picVar);
  });

  PluginManager.registerCommand(pluginName, "reverseSet", args => { // 裏面画ピクチャ設置
    const file  = args.reverseFile || NLCLparam.reverseComFile;
    const scale = Number(args.rAutoScale) || NLCLparam.rAutoScale;
    const tr    = Number(args.reverseType)  || 1;
    const pId   = Number(args.reversePicId) || 0;
    $gameScreen.reversePictureSet(file, pId, scale, tr);
  });

  PluginManager.registerCommand(pluginName, "pictureCopy", args => { // ピクチャコピー
    const oId = PluginManager.NLCLvariables(args.originVarId, args.originId); 
    const cId = PluginManager.NLCLvariables(args.copyVarId,   args.copyId);
    $gameScreen.NLCLcopyPicture(oId, cId);
  });

  PluginManager.registerCommand(pluginName, "picturesErase", args => { // ピクチャまとめて消去
    const fId = Number(args.fromId) || 0; 
    const tId = Number(args.toId)   || 0;
    $gameScreen.NLCLerasePictures(fId, tId);
  });

  PluginManager.registerCommand(pluginName, "pictureRotationStop", args => { // ピクチャ回転停止
    const pId = PluginManager.NLCLvariables(args.picVariable, args.pictureId);
    const ang = PluginManager.NLCLvariables(args.angVariable, args.angle);
    const spd = PluginManager.NLCLvariables(args.spdVariable, args.speed);
    $gameScreen.NLCLrotatePicture(pId, ang, spd);
  });

  PluginManager.registerCommand(pluginName, "pictureUpdate", args => { // ピクチャ画像更新
    const fId = Number(args.fromId) || 0; 
    const tId = Number(args.toId)   || 0;
    const vId = PluginManager.NLCLvariables(args.varId, 0);
    const pId = vId ? vId : !tId ? fId : 0;
    if (pId) {
      $gameScreen.updateCardPicture(pId);
    } else if (fId && fId <= tId) {
      for (let i = fId; i <= tId; i++) {
        $gameScreen.updateCardPicture(i);
      }
    }
  });

  PluginManager.registerCommand(pluginName, "cardUpdate", args => { // カード化画像更新
    $gameTemp.updateBattlerCard();
  });

// Game_Temp関係（独自関数の設定）
  // メモ欄の<ctxt>を文字列として取得（存在しない時は半角スペースを返す）
  Game_Temp.prototype.getctxt = function(memoNum, id, isSkill) {  // メモ置換番号, ID, スキルか(true or false)
    const item = this.NLCLdataType(isSkill)[0][id];
    const ctxt = DataManager._NLCLctxt + memoNum;
    return item ? (item.meta[ctxt] || " ") : " ";
  };

  // メモ欄の<ctxt>を数値として取得
  Game_Temp.prototype.getNctxt = function(memoNum, id, isSkill) { // メモ置換番号, ID, スキルか(true or false)
    return Number(this.getctxt(memoNum, id, isSkill)) || 0;
  };

  // レイアウト番号のスクリプト値を計算（IDを入力しないと 0 になる）
  Game_Temp.prototype.getLayoutScript = function(layoutNum, id, isSkill) { // レイアウト番号, ID, スキルか(true or false)
    const layout = this.NLCLlayoutType(isSkill)[layoutNum - 1];
    const data   = this.NLCLdataType(isSkill);
    const tr     = data[1];
    const item   = tr === 4 ? $gameEnemies.enemy(id) :
                   tr === 5 ? $gameActors.actor(id)  :
                   data[0][id];
    return this.NLCLevalFormula(layout.script, item, true, tr);
  };

  Game_Temp.prototype.NLCLdataType = function(isSkill) {
    switch (isSkill) {
      case "weapon":
        return [$dataWeapons, 2];
      case "armor":
        return [$dataArmors,  3];
      case "enemy":
        return [$dataEnemies, 4];
      case "actor":
        return [$dataActors,  5];
      case true:
        return [$dataSkills,  0];
      default:
        return [$dataItems,   1];
    }
  };

  Game_Temp.prototype.NLCLlayoutType = function(isSkill) {
    switch (isSkill) {
      case "weapon":
      case "armor":
        return NLCLitemLayout;
      case "enemy":
        return NLCLenemyLayout;
      case "actor":
        return NLCLactorLayout;
      case true:
        return NLCLskillLayout;
      default:
        return NLCLitemLayout;
    }
  };

  // カード化バトラーの画像更新
  Game_Temp.prototype.updateBattlerCard = function(battler) {
    if (!$gameParty.inBattle()) return;
    if (!battler) {
      for (const actor of $gameParty.battleMembers()) {
        actor._NLCLchangeActor  = true;
        actor._NLCLchangeStatus = true;
      }
      for (const enemy of $gameTroop.members()) {
        enemy._NLCLchangeEnemy  = true;
      }
    } else if (battler.isActor()) {
      battler._NLCLchangeActor  = true;
      battler._NLCLchangeStatus = true;
    } else if (battler.isEnemy()) {
      battler._NLCLchangeEnemy  = true;
    }
  };

// MZ用カードゲームプラグイン(NLM_CardGameMZ.js)との併用対策
  Game_Temp.prototype.NLCLitemTpCost = function(item) {
    if (!item) return 0;
    return this.NLCLevalFormula(item.meta["TPcost"], item, false, 1);
  };

  Game_Temp.prototype.NLCLitemMpCost = function(item) {
    if (!item) return 0;
    return this.NLCLevalFormula(item.meta["MPcost"], item, false, 1);
  };

  Game_Temp.prototype.NLCLevalFormula = function(formula, item, tR, tr) {
    if (!formula) return 0;
    try {
      const v = $gameVariables._data; // 変数値に置き換え
      const V = $gameVariables._data;
      const a = item;
      const cId = tr === 1 ? this.NLCLiTypeExchange(item.id, "<", item.itypeId) :
                  tr === 4 ? item.index() : tr === 5 ? item.actorId() : item.id;
      const evF = eval(formula);
      return tR ? (evF === undefined ? 0 : evF) : isNaN(evF) ? 0 : Math.max(evF, 0);
    } catch (e) {
      return 0;
    }
  };

  Game_Temp.prototype.NLCLiTypeExchange = function(id, arrow, iType) {
    if (!id) return 0;
    const it = $dataItems[id].itypeId;
    if ((arrow === ">" && it > 1) || (arrow === "<" && (it < 5 || it !== iType)))
      {return id;}
    const max  = NLCLitemMaxNum; // NLM_CardGameMZ.jsとの違い
    const sign = arrow === "<" ? -1 : 1;
    let itId = id;
    switch (iType) {
      case 5: // デッキ（山札）
        itId += max * sign;
        break;
      case 6: // 手札
        itId += 2 * max * sign;
        break;
      case 7: // 捨札
        itId += 3 * max * sign;
        break;
      case 8: // 場札
        itId += 4 * max * sign;
        break;
    }
    return itId;
  };

  Game_System.prototype.NLCLtcrEx = function() { // TPチャージ率をTP消費率に変換するか
    const ex = DataManager._NLMGtcrEx;
    return (ex === 1 && NLMGparam.damageTP === "0") || ex === 2;
  };

  Game_Party.prototype.NLCLnumItemsForShow = function (item) { // 見せかけの個数
    const num  = this.numItems(item);
    if (BattleManager.isInputting()) {
      return num - BattleManager.NLCLnumConsumedItems(item);
    }
    return num;
  };

  const _BattleManager_initMembers = BattleManager.initMembers;
  BattleManager.initMembers = function() {
    _BattleManager_initMembers.apply(this, arguments);
    this._NLMGconsumedItems = [];
  };

  BattleManager.NLCLnumConsumedItems = function (item) {
    let   cNum  = 0;
    this._NLMGconsumedItems.forEach((cItem) => {
      if (cItem.id === item.id) cNum++;
    });
    return cNum
  };

// Game_System関係（置換前のレイアウト取得など）
  const _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function() {
    _Game_System_initialize.apply(this, arguments);
    this._isNLMcardLayout = true;
  };

  Game_System.prototype.itemLayout = function(layoutNum) { // レイアウト番号を省略すると全レイアウトを返す
    if (layoutNum && layoutNum > 0) {
      return NLCLitemLayout[layoutNum - 1];
    }
    return NLCLitemLayout;
  };

  Game_System.prototype.skillLayout = function(layoutNum) {
    if (layoutNum && layoutNum > 0) {
      return NLCLskillLayout[layoutNum - 1];
    }
    return NLCLskillLayout;
  };

  Game_System.prototype.enemyLayout = function(layoutNum) {
    if (layoutNum && layoutNum > 0) {
      return NLCLenemyLayout[layoutNum - 1];
    }
    return NLCLenemyLayout;
  };

  Game_System.prototype.actorLayout = function(layoutNum) {
    if (layoutNum && layoutNum > 0) {
      return NLCLactorLayout[layoutNum - 1];
    }
    return NLCLactorLayout;
  };

// Game_Screen関係（ピクチャ設置など）
  Game_Screen.prototype.cardPictureSet = function(item, pId) { // カードピクチャ設置
    const sym = this.NLCLsymbol(item);
    const tr  = sym === "S" ? 0 : sym === "E" ? 4: sym ==="A" ? 5 : 1;
    const lay = DataManager.NLCLlayout(tr);
    const wId = NLCLparam.successSwId;
    if (item && sym && pId && lay.length) {
      const sId = sym + item.id;
      const x = Graphics.width / 2;
      this.showPicture(pId, "NLCLpicSet" + sId, 1, x, 0, 50, 50, 0, 0);
      $gameSwitches.setValue(wId, true);
    } else {
      $gameSwitches.setValue(wId, false);
    }
  };

  Game_Screen.prototype.NLCLsymbol = function(item) {
    if (DataManager.isItem(item))    return "I";
    if (DataManager.isWeapon(item))  return "W";
    if (DataManager.isArmor(item))   return "M";
    if (DataManager.isSkill(item))   return "S";
    if ($dataEnemies.includes(item)) return "E";
    if ($dataActors.includes(item))  return "A";
    return null;
  };

  Game_Screen.prototype.reversePictureSet = function(file, pId, scale, tr) { // 裏面画ピクチャ設置
    if (file && pId && scale) {
      const sym = tr ? "I" : "S";
      const fil = sym + scale + file;
      const x = Graphics.width / 2;
      this.showPicture(pId, "NLCLrevers" + fil, 1, x, 0, 50, 50, 0, 0);
    }
  };

  Game_Screen.prototype.updateCardPicture = function(pId) { // ピクチャ更新
    const picture = this.picture(pId);
    if (picture) {
      picture._NLCLupdate = true;
    }
  };

  Game_Screen.prototype.NLCLerasePictures = function(fromId, toId) { // ピクチャまとめて消去
    if (fromId && toId && fromId <= toId) {
      for (let i = fromId; i <= toId; i++) {
        this.erasePicture(i);
      }
    }
  };

  Game_Screen.prototype.NLCLcopyPicture = function(originId, copyId) { // ピクチャコピー
    const realOriginId  = this.realPictureId(originId);
    const originPicture = this._pictures[realOriginId];
    if (copyId && originPicture) {
      const realCopyId  = this.realPictureId(copyId);
      const copyPicture = new Game_Picture();
      for (const [key, value] of Object.entries(originPicture)) {
        copyPicture[key] = value;
      }
      this._pictures[realCopyId] = copyPicture;
    }
  };

  Game_Screen.prototype.NLCLrotatePicture = function(pictureId, angle, speed) { // ピクチャ回転と停止
    const picture = this.picture(pictureId);
    if (picture && speed) {
      picture.NLCLrotate(angle, speed);
    }
  };

// Game_Picture関係（ピクチャ回転と停止）
  Game_Picture.prototype.NLCLrotate = function(angle, speed) {
    const start = this.NLCLfixAngle(this._angle);
    const plus = speed > 0;
    const rot  = angle >= 360 || angle <= -360;
    angle = rot && plus ? 360 : rot && !plus ? -360 : angle;
    this._NLCLstop = angle;
    if ( plus && start > angle) this._NLCLstop += 360;
    if (!plus && start < angle) this._NLCLstop -= 360;
    this._angle = start;
    this._rotationSpeed = speed;
  };

  const _GP_updateRotation = Game_Picture.prototype.updateRotation;
  Game_Picture.prototype.updateRotation = function() {
    _GP_updateRotation.apply(this, arguments);
    const speed = this._rotationSpeed;
    if (speed && this._NLCLstop !== undefined) {
      const plus = speed > 0;
      const angl = this._angle;
      const stop = this._NLCLstop;
      const pass = (plus && angl >= stop) || (!plus && angl <= stop); // 停止位置を過ぎたか
      if (pass) { // 回転停止
        this._angle = stop;
        this._rotationSpeed = 0;
        this._NLCLstop = undefined;
      }
    }
  };

  Game_Picture.prototype.NLCLfixAngle = function(angle) {
    const ang360 = angle % 360;
    return angle >= 0 ? ang360 : ang360 === -0 ? 0 : ang360 + 360;
  };

// Game_Battler関係（スキル消費の小変更）
  Game_Battler.prototype.gainSilentMp = function(value) { // 新設
    this.setMp(this.mp + value);
  };

  Game_Battler.prototype.paySkillCost = function(skill) {
    this.gainSilentMp(-this.skillMpCost(skill));
    this.gainSilentTp(-this.skillTpCost(skill));
  };

// Game_Actor関係（HP・MP・TPの変動を知らせる）
  const _Game_Actor_setHp = Game_Actor.prototype.setHp;
  Game_Actor.prototype.setHp = function(hp) {
    _Game_Actor_setHp.apply(this, arguments);
    this._NLCLchangeActor  = true;
    this._NLCLchangeStatus = true;
  };

  const _Game_Actor_setMp = Game_Actor.prototype.setMp;
  Game_Actor.prototype.setMp = function(Mp) {
    _Game_Actor_setMp.apply(this, arguments);
    this._NLCLchangeActor  = true;
    this._NLCLchangeStatus = true;
  };

  const _Game_Actor_setTp = Game_Actor.prototype.setTp;
  Game_Actor.prototype.setTp = function(tp) {
    _Game_Actor_setTp.apply(this, arguments);
    this._NLCLchangeActor  = true;
    this._NLCLchangeStatus = true;
  };

  const _Game_Actor_recoverAll = Game_Actor.prototype.recoverAll;
  Game_Actor.prototype.recoverAll = function() {
    _Game_Actor_recoverAll.apply(this, arguments);
    this._NLCLchangeActor  = true;
    this._NLCLchangeStatus = true;
  };

// Game_Enemy関係（HP・MP・TPの変動を知らせる）
  const _Game_Enemy_setHp = Game_Enemy.prototype.setHp;
  Game_Enemy.prototype.setHp = function(hp) {
    _Game_Enemy_setHp.apply(this, arguments);
    this._NLCLchangeEnemy = true;
  };

  const _Game_Enemy_setMp = Game_Enemy.prototype.setMp;
  Game_Enemy.prototype.setMp = function(Mp) {
    _Game_Enemy_setMp.apply(this, arguments);
    this._NLCLchangeEnemy = true;
  };

  const _Game_Enemy_setTp = Game_Enemy.prototype.setTp;
  Game_Enemy.prototype.setTp = function(tp) {
    _Game_Enemy_setTp.apply(this, arguments);
    this._NLCLchangeEnemy = true;
  };

  const _Game_Enemy_recoverAll = Game_Enemy.prototype.recoverAll;
  Game_Enemy.prototype.recoverAll = function() {
    _Game_Enemy_recoverAll.apply(this, arguments);
    this._NLCLchangeEnemy = true;
  };

// Game_Enemies関係（新設、ピクチャ生成用）
  function Game_Enemies() {
    this.initialize(...arguments);
  }

  Game_Enemies.prototype.initialize = function() {
    this._data = [];
  };

  Game_Enemies.prototype.enemy = function(enemyId) {
    if ($dataEnemies[enemyId]) {
        if (!this._data[enemyId]) {
            this._data[enemyId] = new Game_Enemy(enemyId);
        }
        return this._data[enemyId];
    }
    return null;
  };

// Game_Interpreter関係など（スクリプトで変数値をv[xx]置換など）
  const _Game_Interpreter_command111 = Game_Interpreter.prototype.command111;
  Game_Interpreter.prototype.command111 = function(params) { // Conditional Branch
    if (DataManager._NLCLscriptV && params[0] === 12) {
      const v = $gameVariables._data; // 変数値に置き換え
      const V = $gameVariables._data;
      this._branch[this._indent] = !!eval(params[1]);
      if (this._branch[this._indent] === false) {
        this.skipBranch();
      }
      return true;
    } else {
      return _Game_Interpreter_command111.apply(this, arguments);
    }
  };

  const _Game_Interpreter_command122 = Game_Interpreter.prototype.command122;
  Game_Interpreter.prototype.command122 = function(params) { // Control Variables
    if (DataManager._NLCLscriptV && params[3] === 4) {
      const v = $gameVariables._data; // 変数値に置き換え
      const V = $gameVariables._data;
      const value = eval(params[4]);
      for (let i = params[0]; i <= params[1]; i++) {
        this.operateVariable(i, params[2], value);
      }
      return true;
    } else {
      return _Game_Interpreter_command122.apply(this, arguments);
    }
  };

  const _Game_Interpreter_command355 = Game_Interpreter.prototype.command355;
  Game_Interpreter.prototype.command355 = function() { // Script
    if (DataManager._NLCLscriptV) {
      let script = this.currentCommand().parameters[0] + "\n";
      while (this.nextEventCode() === 655) {
        this._index++;
        script += this.currentCommand().parameters[0] + "\n";
      }
      const v = $gameVariables._data; // 変数値に置き換え
      const V = $gameVariables._data;
      eval(script);
      return true;
    } else {
      return _Game_Interpreter_command355.apply(this, arguments);
    }
  };

  const _GC_processMoveCommand = Game_Character.prototype.processMoveCommand;
  Game_Character.prototype.processMoveCommand = function(command) { // Set Movement Route
    const gc = Game_Character;
    if (DataManager._NLCLscriptV && command.code === gc.ROUTE_SCRIPT) {
      const v = $gameVariables._data; // 変数値に置き換え
      const V = $gameVariables._data;
      eval(command.parameters[0]);
    } else {
      _GC_processMoveCommand.apply(this, arguments);
    }
  };

// Scene_Boot関係（起動時にメモ欄データの取り込み）
  const _SB_onDatabaseLoaded = Scene_Boot.prototype.onDatabaseLoaded;
  Scene_Boot.prototype.onDatabaseLoaded = function() {
    _SB_onDatabaseLoaded.apply(this, arguments);
    if (NLCLfirstBoot) {
      NLCLitemMaxNum = $dataItems.length - 1; // データベース上のアイテム最大数取得
      NLCLfirstBoot  = false;
    }
    this.NLCLlayoutLoad();
  };

  Scene_Boot.prototype.NLCLlayoutLoad = function() {
    NLCLitemLayout  = DataManager.NLMstruct(NLCLparam.itemLayout);
    NLCLskillLayout = DataManager.NLMstruct(NLCLparam.skillLayout);
    NLCLenemyLayout = DataManager.NLMstruct(NLCLparam.enemyLayout);
    NLCLactorLayout = DataManager.NLMstruct(NLCLparam.actorLayout);
    this.NLCLfixLayout(NLCLitemLayout,  1);
    this.NLCLfixLayout(NLCLskillLayout, 0);
    this.NLCLfixLayout(NLCLenemyLayout, 4);
    this.NLCLfixLayout(NLCLactorLayout, 5);
    DataManager.NLCLdeveloperConsole();
  };

  Scene_Boot.prototype.NLCLfixLayout = function(layout, tr) {
    for (let obj of layout) {
      for (const key in obj) {
        switch (key) {
          case "type":
            if (obj[key] === "メモ指定メイン画") {
              const autoScale = Number(obj["autoScale"]) || 2;
              if (tr === 1) NLCLitemMainScale  = autoScale;
              if (tr === 0) NLCLskillMainScale = autoScale;
              if (tr === 4) NLCLenemyMainScale = autoScale;
              if (tr === 5) NLCLactorMainScale = autoScale;
            }
          case "align":
          case "comText":
          case "layerFile":
          case "startPoint":
          case "noDispTime":
          case "script":
            break;
          default:
            obj[key] = Number(obj[key]) || 0;
        }
      }
    }
  };

// Bitmap関係
  const _Bitmap_drawText = Bitmap.prototype.drawText;
  Bitmap.prototype.drawText = function(text, x, y, maxWidth, lineHeight, align) {
    const context = this.context;
    context.save();
    if (this.fontSize <= 20) context.rotate(0.0008); //(0.0005);
    _Bitmap_drawText.apply(this, arguments);
    context.restore();
  };

// Window_Base関係
  // drawTextEx改造
  Window_Base.prototype.NLCLtextWidth = function(text) {
    return NLCLbitmap.measureTextWidth(text);
  };

  Window_Base.prototype.NLCLdrawTextEx = function(text, x, y, width) {
    const textState = this.NLCLcreateTextState(text, x, y, width);
    this.processAllText(textState);
    return textState.outputWidth;
  };

  Window_Base.prototype.NLCLcreateTextState = function(text, x, y, width) {
    const rtl = Utils.containsArabic(text);
    const textState = {};
    textState.text = this.convertEscapeCharacters(text);
    textState.index = 0;
    textState.x = rtl ? x + width : x;
    textState.y = y;
    textState.width = width;
    textState.height = this.NLCLcalcTextHeight(textState); // 書き換え
    textState.startX = textState.x;
    textState.startY = textState.y;
    textState.rtl = rtl;
    textState.buffer = this.createTextBuffer(rtl);
    textState.drawing = true;
    textState.outputWidth = 0;
    textState.outputHeight = 0;
    return textState;
  };

  const _WB_flushTextState = Window_Base.prototype.flushTextState;
  Window_Base.prototype.flushTextState = function(textState) {
    if (NLCLbitmap) {
      this.NLCLflushTextState(textState);
    } else {
      _WB_flushTextState.apply(this, arguments);
    }
  };

  Window_Base.prototype.NLCLflushTextState = function(textState) {
    const text = textState.buffer;
    const rtl = textState.rtl;
    const width = this.NLCLtextWidth(text);
    const height = textState.height;
    const x = rtl ? textState.x - width : textState.x;
    const y = textState.y;
    if (textState.drawing) {
        NLCLbitmap.drawText(text, x, y, width, height); // 書き換え
    }
    textState.x += rtl ? -width : width;
    textState.buffer = this.createTextBuffer(rtl);
    const outputWidth = Math.abs(textState.x - textState.startX);
    if (textState.outputWidth < outputWidth) {
        textState.outputWidth = outputWidth;
    }
    textState.outputHeight = y - textState.startY + height;
  };

  const _WB_convertEscapeCharacters = Window_Base.prototype.convertEscapeCharacters;
  Window_Base.prototype.convertEscapeCharacters = function(text) { // 変数内に説明文を入れた際に正しく表示
    text = text.replace(/\\/g, "\x1b");
    text = text.replace(/\x1b\x1b/g, "\\");
    text = text.replace(/\x1bV\[(\d+)\]/gi, (_, p1) =>
      $gameVariables.value(parseInt(p1))
    );
    return _WB_convertEscapeCharacters.call(this, text);
  };

  const _WB_processEscapeCharacter = Window_Base.prototype.processEscapeCharacter;
  Window_Base.prototype.processEscapeCharacter = function(code, textState) {
    if (NLCLbitmap) {
      this.NLCLprocessEscapeCharacter(code, textState);
    } else {
      _WB_processEscapeCharacter.apply(this, arguments);
    }
  };

  Window_Base.prototype.NLCLprocessEscapeCharacter = function(code, textState) {
    const val = this.obtainEscapeParam(textState);
    const fs  = NLCLbitmap.fontSize;
    switch (code) {
      case "C":
        NLCLbitmap.textColor = ColorManager.textColor(val);
        break;
      case "I":
        if (textState.drawing) {
          const y = textState.y + (fs < 35 ? 2 : 7);
          this.NLCLdrawIcon(NLCLbitmap, val, textState.x + 2, y, fs + 6);
        }
        textState.x += fs + 6 + 4;
        break;
      case "PX":
        textState.x = val * 2;
        break;
      case "PY":
        textState.y = val * 2;
        break;
      case "FS":
        NLCLbitmap.fontSize = val * 2;
        break;
      case "{":
        this.NLCLmakeFontBigger();
        break;
      case "}":
        this.NLCLmakeFontSmaller();
        break;
    }
  };

  Window_Base.prototype.NLCLmakeFontBigger = function() {
    if (NLCLbitmap.fontSize <= 192) {
      NLCLbitmap.fontSize += 12;
    }
  };

  Window_Base.prototype.NLCLmakeFontSmaller = function() {
    if (NLCLbitmap.fontSize >= 24) {
      NLCLbitmap.fontSize -= 12;
    }
  };

  Window_Base.prototype.NLCLcalcTextHeight = function(textState) {
    const lineSpacing = this.lineHeight() - $gameSystem.mainFontSize();
    const lastFontSize = NLCLbitmap.fontSize;
    const mag = lastFontSize < 35 ? 1 : 2
    const lines = textState.text.slice(textState.index).split("\n");
    const textHeight = this.NLCLmaxFontSizeInLine(lines[0]) + lineSpacing * mag;
    NLCLbitmap.fontSize = lastFontSize;
    return textHeight;
  };

  Window_Base.prototype.NLCLmaxFontSizeInLine = function(line) {
    let maxFontSize = NLCLbitmap.fontSize;
    const regExp = /\x1b({|}|FS)(\[(\d+)])?/gi;
    for (;;) {
      const array = regExp.exec(line);
      if (!array) {
        break;
      }
      const code = String(array[1]).toUpperCase();
      if (code === "{") {
        this.NLCLmakeFontBigger();
      } else if (code === "}") {
        this.NLCLmakeFontSmaller();
      } else if (code === "FS") {
        NLCLbitmap.fontSize = parseInt(array[3]) * 2;
      }
      if (NLCLbitmap.fontSize > maxFontSize) {
        maxFontSize = NLCLbitmap.fontSize;
      }
    }
    return maxFontSize;
  };

  const _WB_processNewLine = Window_Base.prototype.processNewLine;
  Window_Base.prototype.processNewLine = function(textState) {
    if (NLCLbitmap) {
      this.NLCLprocessNewLine(textState);
    } else {
      _WB_processNewLine.apply(this, arguments);
    }
  };

  Window_Base.prototype.NLCLprocessNewLine = function(textState) {
    textState.x = textState.startX;
    textState.y += textState.height;
    textState.height = this.NLCLcalcTextHeight(textState);
  };

  Window_Base.prototype.NLCLdrawIcon = function(bitmap, iconIndex, x, y, dot) {
    if (iconIndex) {
      const iBitmap = ImageManager.loadSystem("IconSet");
      const pw = ImageManager.iconWidth;
      const ph = ImageManager.iconHeight;
      const sx = (iconIndex % 16) * pw;
      const sy = Math.floor(iconIndex / 16) * ph;
      bitmap.context.drawImage(iBitmap.canvas, sx, sy, pw, ph, x, y, dot, dot);
    }
  };

  // レイアウトの実行
  Window_Base.prototype.drawCardItem = function(item, tr, org, rect) {
    if (!item) return;
    const itemD = tr === 4 ? item.enemy() : tr === 5 ? item.actor() : item;
    if (itemD.NLCLfolder === undefined) {
      DataManager.NLCLcategolize(itemD, tr, 0);
    }
    const bitmapM = ImageManager.NLCLload(itemD, tr);
    const bitmap1 = ImageManager.loadPicture(itemD.NLCLfile1);
    const bitmap2 = ImageManager.loadPicture(itemD.NLCLfile2);
    const bitmap3 = ImageManager.loadPicture(itemD.NLCLfile3);
    bitmapM.addLoadListener(function() {
      bitmap1.addLoadListener(function() {
        bitmap2.addLoadListener(function() {
          bitmap3.addLoadListener(function() {
            this.NLCLdrawLayout(item, tr, org, rect, [bitmapM, bitmap1, bitmap2, bitmap3]);
          }.bind(this));
        }.bind(this));
      }.bind(this));
    }.bind(this));
  };

  Window_Base.prototype.NLCLdrawLayout = function(item, tr, org, rect, bitmaps) {
    const layout  = DataManager.NLCLlayout(tr);
    if (!layout.length) return;
    const itemD = tr === 4 ? item.enemy() : tr === 5 ? item.actor() : item;
    const iWidth  = DataManager.NLCLitemWidth(tr);
    const iHeight = DataManager.NLCLitemHeight(tr);
    const lSpace  = this.lineHeight() - $gameSystem.mainFontSize();
    const weapon  = tr >= 2 && tr <= 3 && NLCLparam.weaponOpacity === "true";
    const enabled = ((org && org < 6) || weapon) ? true : this.isEnabled(item);
    const mp = tr < 4 ? 0 : item.mp;
    const tp = tr < 4 ? 0 : item.tp;
    const mpCost = tr > 3 ? 0 : tr ? this.NLCLitemMpCost(item) : this.NLCLskillMpCost(item);
    const tpCost = tr > 3 ? 0 : tr ? this.NLCLitemTpCost(item) : this.NLCLskillTpCost(item);
    const noLayout = this.NLCLnoLayout(itemD);
    let bitmap = new Bitmap(iWidth * 2, iHeight * 2);
    bitmap.fontFace = $gameSystem.mainFontFace();
    for (let i=0; i<layout.length; i++) {
      if (noLayout.includes(i+1)) continue;
      const obj = layout[i];
      const scr = $gameTemp.NLCLevalFormula(obj.script, item, true, tr);
      if (this.NLCLnoDispT(obj.noDispTime, itemD, tr, org, mp, tp, mpCost, tpCost, scr)) continue;
      const x0 = this.NLCLpX(obj.startPoint, obj.px, iWidth);
      const y0 = this.NLCLpY(obj.startPoint, obj.py, iHeight);
      const x  = x0 * 2;
      const y  = y0 * 2;
      const width  = (obj.width  <= 0 ? iWidth  - x0 + obj.width  : obj.width)  * 2;
      const height = (obj.height <= 0 ? iHeight - y0 + obj.height : obj.height) * 2;
      const align  = obj.align;
      const fSize  = obj.fontSize * 2;
      const lHeigt = (fSize < 35 ? 1 : 2) * lSpace + fSize;
      const memoNm = obj.memoNum;
      const ocolr1 = obj.color1;
      const ocolr2 = obj.color2;
      const ccolor = itemD.meta[DataManager._NLCLccolor + memoNm];
      const vcolor = itemD.meta[DataManager._NLCLvcolor + memoNm];
      const mcolr0 = ccolor ? (Number(ccolor) || 0) : ocolr1;
      const mcolr1 = vcolor ? (Number($gameVariables.value(vcolor)) || 0) : mcolr0;
      const mcolr2 = ocolr1 === ocolr2 ? mcolr1 : Math.abs(ocolr2);
      const color1 = ColorManager.textColor(mcolr1);
      const color2 = ColorManager.textColor(mcolr2);
      const horizo = ocolr2 < 0;
      const scale  = obj.autoScale;
      const opacty = obj.opacity < 255 ? obj.opacity : enabled ? 255 : this.translucentOpacity();
      const ctxt   = itemD.meta[DataManager._NLCLctxt + memoNm] || obj.comText;
      let val = undefined;
      bitmap.textColor = color1;
      bitmap.fontSize  = fSize;
      bitmap.paintOpacity = opacty;
      if (fSize < 30) bitmap.outlineWidth = 1;
      switch (obj.type) {
        case "名前(制御文字不可)":
          const name = (tr === 4 || tr === 5) ? item.name() : item.name;
          bitmap.drawText(name, x, y, width, lHeigt, align);
          break;
        case "アイコン":
          this.NLCLdrawIcon(bitmap, item.iconIndex, x, y, fSize);
          break;
        case "個数(スキル以外)":
          if (tr && this.needsNumber()) {
            const num = $gameParty.NLCLnumItemsForShow(item);
            bitmap.drawText(num, x, y, width, lHeigt, align);
          }
          break;
        case "MPコスト値":
          bitmap.drawText(mpCost, x, y, width, lHeigt, align);
          break;
        case "TPコスト値":
          bitmap.drawText(tpCost, x, y, width, lHeigt, align);
          break;
        case "説明文(制御文字可)":
        case "プロフィール(アクターのみ)":
          const dtxt = tr === 4 ? null : tr === 5 ? itemD.profile : item.description;
          if (dtxt) {
            NLCLbitmap = bitmap;
            this.NLCLdrawTextEx(dtxt, x, y, 0);
            bitmap = NLCLbitmap;
            NLCLbitmap = null;
          }
          break;
        case "HP値":
          val = item.hp;
        case "MP値":
          val = val === undefined ? item.mp  : val;
        case "TP値":
          val = val === undefined ? item.tp  : val;
        case "最大HP値":
          val = val === undefined ? item.mhp : val;
        case "最大MP値":
          val = val === undefined ? item.mmp : val;
        case "攻撃力値":
          val = val === undefined ? item.atk : val;
        case "防御力値":
          val = val === undefined ? item.def : val;
        case "魔法力値":
          val = val === undefined ? item.mat : val;
        case "魔法防御値":
          val = val === undefined ? item.mdf : val;
        case "敏捷性値":
          val = val === undefined ? item.agi : val;
        case "運値":
          val = val === undefined ? item.luk : val;
        case "レベル(アクターのみ)":
          val = val === undefined ? (tr === 4 ? 0 : item._level) : val;
        case "経験値":
          val = val === undefined ? (tr === 4 ? item.exp()  : item.currentExp()) : val;
        case "所持金":
          val = val === undefined ? (tr === 4 ? item.gold() : $gameParty.gold()) : val;
          bitmap.drawText(val, x, y, width, lHeigt, align);
          break;
        case "メモ指定メイン画":
          const folder = itemD.NLCLfolder;
          const fileM  = itemD.NLCLfileM;
          if (folder && fileM) {
            const div = itemD.NLCLdiv || ImageManager.NLCLdivMake(itemD, fileM, bitmaps[0], folder, tr);
            this.NLCLdrawBitmap(tr, bitmap, bitmaps[0], scale, x0, y0, itemD.NLCLcalM, div);
          }
          break;
        case "レイヤー画1":
          if (itemD.NLCLfile1) {
            this.NLCLdrawBitmap(tr, bitmap, bitmaps[1], scale, x0, y0, itemD.NLCLcal1);
          }
          break;
        case "レイヤー画2":
          if (itemD.NLCLfile2) {
            this.NLCLdrawBitmap(tr, bitmap, bitmaps[2], scale, x0, y0, itemD.NLCLcal2);
          }
          break;
        case "レイヤー画3":
          if (itemD.NLCLfile3) {
            this.NLCLdrawBitmap(tr, bitmap, bitmaps[3], scale, x0, y0, itemD.NLCLcal3);
          }
          break;
        case "自由文字(制御文字可)":
          if (ctxt) {
            NLCLbitmap = bitmap;
            this.NLCLdrawTextEx(ctxt, x, y, 0);
            bitmap = NLCLbitmap;
            NLCLbitmap = null;
          }
          break;
        case "自由文字(制御文字不可)":
          if (ctxt) {
            bitmap.drawText(ctxt, x, y, width, lHeigt, align);
          }
          break;
        case "四角描画":
          if (color1 === color2) {
            bitmap.fillRect(x, y, width, height, color1);
          } else {
            bitmap.gradientFillRect(x, y, width, height, color1, color2, !horizo);
          }
          break;
        case "円描画":
          bitmap.drawCircle(x, y, fSize, color1);
          break;
        case "細枠描画":
          bitmap.strokeRect(x, y, width, height, color1);
          break;
        case "スクリプト値(上級者向け)":
          bitmap.drawText(scr, x, y, width, lHeigt, align);
          break;
      }
    }
    this.NLCLdrawContents(bitmap, item, org, rect, iWidth, iHeight);
  };

  Window_Base.prototype.NLCLdrawContents = function(bitmap, item, org, rect, iWidth, iHeight) {
    const bWidth  = iWidth  * 2;
    const bHeight = iHeight * 2;
    let eMag = NLCLparam.equipMag;
    let mMag = org === 5 ? DataManager.NLCLactorCardMag(item) : 0;
    switch (org) {
      case 0: // アイテム・スキル・エネミー・戦闘ステータスのウインドウ
        const rx = rect.x + 2; // rect.x - 6;
        const ry = rect.y + 2; // rect.y - iHeight / 2 + 18;
        this.contents.blt(bitmap, 0, 0, bWidth, bHeight, rx, ry, iWidth, iHeight);
        break;
      case 1: // ショップ
        eMag = NLCLparam.shopMag;
      case 2: // 装備slot
        const ex = rect.x - iWidth  / 2 * eMag;
        const ey = rect.y - iHeight / 2 * eMag;
        const ew = iWidth  * eMag;
        const eh = iHeight * eMag
        this._statusWindow.contents.blt(bitmap, 0, 0, bWidth, bHeight, ex, ey, ew, eh);
        break;
      case 3: // 合成ピクチャ
        this.contents.blt(bitmap, 0, 0, bWidth, bHeight, 0, 0);
        break;
      case 4: // 敵画像置換
        mMag = DataManager.NLCLenemyCardMag(item);
      case 5: // SVアクター画像置換
        const mw = iWidth  * mMag;
        const mh = iHeight * mMag;
        this.contents.blt(bitmap, 0, 0, bWidth, bHeight, 0, 0, mw, mh);
        break;
      case 6: // 任意のWindow（org === 6）
        const c1 = iHeight / iWidth;
        const c2 = rect.height / rect.width;
        const nw = c2 > c1 ? rect.width : iWidth * rect.height / iHeight;
        const nh = c2 > c1 ? iHeight * rect.width / iWidth : rect.height;
        const nx = c2 < c1 ? (rect.width  - nw) / 2 : 0;
        const ny = c2 > c1 ? (rect.height - nh) / 2 : 0;
        this.contents.blt(bitmap, 0, 0, bWidth, bHeight, rect.x + nx, rect.y + ny, nw, nh);
        break;
    }
  };

  Window_Base.prototype.NLCLnoLayout = function(item) {
    const meta = item.meta["NoLayout"];
    if (!meta) return [];
    const arr = meta.split(",");
    for (let i=0; i < arr.length; i++) {
      arr[i] = parseInt(arr[i]) || 0;
    };
    return arr;
  };

  Window_Base.prototype.NLCLnoDispT = function(time, item, tr, org, mp, tp, mpCost, tpCost, scr) {
    switch (time) {
      case "個数が非表示時":
        return tr ? !this.needsNumber() : true;
      case "個数が1または非表示時":
        return tr ? !this.needsNumber() || $gameParty.NLCLnumItemsForShow(item) === 1 : true;
      case "大事なものの時":
        return tr === 1 && item.itypeId === 2;
      case "武器・防具の時":
        return tr > 1;
      case "通常アイテム以外":
        return !tr || tr > 1 || (item.itypeId > 1 && item.itypeId < 5);
      case "MPコストがゼロ時":
        return !mpCost;
      case "TPコストがゼロ時":
        return !tpCost;
      case "MP･TPコストが共にゼロ時":
        return !mpCost && !tpCost;
      case "MPがゼロ時":
        return !mp;
      case "TPがゼロ時":
        return !tp;
      case "MP･TPが共にゼロ時":
        return !mp && !tp;
      case "MPがゼロかピクチャ時":
        return !mp || org === 3 || org === 6;
      case "TPがゼロかピクチャ時":
        return !tp || org === 3 || org === 6;
      case "MP･TPが共にゼロかピクチャ時":
        return (!mp && !mp) || org === 3 || org ===6;
      case "ウインドウ表示時":
        return org === 0;
      case "ウインドウとピクチャ時":
        return org === 0 || org === 3 || org === 6;
      case "ウインドウ以外":
        return org !== 0;
      case "ウインドウ以外(ピクチャ許容)":
        return org !== 0 && org !== 3 && org !== 6;
      case "合成ピクチャ時":
        return org === 3 || org === 6;
      case "合成ピクチャ以外":
        return org !== 3 && org !== 6;
      case "メモ<ctxt1>の指定なし":
      case "メモ<ctxt2>の指定なし":
      case "メモ<ctxt3>の指定なし":
      case "メモ<ctxt4>の指定なし":
      case "メモ<ctxt5>の指定なし":
        const memoNum = time.slice(7,8);
        return !item.meta[DataManager._NLCLctxt + memoNum];
      case "スクリプト値がゼロ時":
        return !scr;
      default:
        return false;
    }
  };

  Window_Base.prototype.NLCLpX = function(startPoint, px, width) {
    let x = px;
    switch (startPoint) {
      case "右上":
      case "右下":
        x = width - 17 + px;
        break;
      case "中央":
        x = Math.round(width / 2 + px);
    }
    return x;
  };

  Window_Base.prototype.NLCLpY = function(startPoint, py, height) {
    let y = py;
    switch (startPoint) {
      case "左下":
      case "右下":
        y = height - 16 + py;
        break;
      case "中央":
        y = Math.round(height / 2 + py);
    }
    return y;
  };

  Window_Base.prototype.NLCLdrawBitmap = function(tr, bitmap, aBitmap, scale, x, y, cal, div) {
    if (!div) div = [0, 0, aBitmap.width, aBitmap.height, 1, 0, 0];
    if (!cal) {
      const iWidth  = DataManager.NLCLitemWidth(tr);
      const iHeight = DataManager.NLCLitemHeight(tr);
      cal = ImageManager.NLCLcalc(div, iWidth, iHeight, scale);
    }
    const sx = cal[0];
    const sy = cal[1];
    const sw = cal[2];
    const sh = cal[3];
    const dx = (cal[4] + div[5] + x) * 2;
    const dy = (cal[5] + div[6] + y) * 2;
    const dw = cal[6] * 2;
    const dh = cal[7] * 2;
    bitmap.context.drawImage(aBitmap.canvas, sx, sy, sw, sh, dx, dy, dw, dh);
  };

  Window_Base.prototype.NLCLskillMpCost = function(skill) {
    const actor = this.NLCLcrActor();
    const mcr = actor ? actor.mcr : 1;
    return Math.floor(skill.mpCost * mcr);
  };

  Window_Base.prototype.NLCLskillTpCost = function(skill) {
    const actor = this.NLCLcrActor();
    const tcr  = actor && $gameSystem.NLCLtcrEx() ? actor.tcr : 1;
    const cost = skill.tpCost * tcr;
    return DataManager._NLMGtcrRound ? Math.round(cost) : Math.floor(cost);
  };

  Window_Base.prototype.NLCLitemMpCost = function(item) {
    const actor = this.NLCLcrActor();
    const cost = $gameTemp.NLCLitemMpCost(item);
    const mcr  = actor ? actor.mcr : 1;
    return Math.floor(cost * mcr);
  };

  Window_Base.prototype.NLCLitemTpCost = function(item) {
    const actor = this.NLCLcrActor();
    const tcr  = actor && $gameSystem.NLCLtcrEx() ? actor.tcr : 1;
    const cost = $gameTemp.NLCLitemTpCost(item) * tcr;
    return DataManager._NLMGtcrRound ? Math.round(cost) : Math.floor(cost);
  };

  Window_Base.prototype.NLCLcrActor = function() {
    const bActor = DataManager._NLCLcostRate ? BattleManager._subject : null;
    return this._actor || bActor;
  };

  Window_Base.prototype.needsNumber = function() {
    return false;
  };

  Window_Base.prototype.isEnabled = function(item) {
    return true;
  };

  Window_Base.prototype.NLCLupdateHelp = function(item, org) { // 装備・店でのカード描画
    const statusW = this._statusWindow;
    const tr = DataManager.NLCLtr(item);
    const exc = org === 1 && tr > 1 && !DataManager._NLCLshopWeaponPic;
    if (item && !exc) {
      const width  = statusW.innerWidth;
      const height = statusW.innerHeight;
      const sx = width  / 2 + DataManager._NLCLshopPx;
      const sy = height / 2 + DataManager._NLCLshopPy + 18;
      const ex = 260 + Number(NLCLparam.equipPx) || 0;
      const ey = 100 + DataManager._NLCLequipPy;
      const rect = org === 2 ? new Rectangle(ex, ey, width, height)
                             : new Rectangle(sx, sy, width, height);
      this.drawCardItem(item, tr, org, rect);
    } else {
      statusW.refresh();
    }
  };

// アイテムで適用（Window_ItemList関係など）
  const _Window_ItemList_initialize = Window_ItemList.prototype.initialize;
  Window_ItemList.prototype.initialize = function() {
    _Window_ItemList_initialize.apply(this, arguments);
    DataManager.NLCLpreLoad(1); // 画像プリロード
    if (NLCLparam.itemOn === "true" && DataManager._NLCLdeleteItemBack) {
      this._contentsBackSprite.alpha = 0; // 背部黒スプライトを消す
    }
  };

  if (NLCLparam.itemOn === "true") {
    Window_ItemList.prototype.itemHeight = function() {
      return DataManager.NLCLheight(1); // アイテム項目の高さ変更
    };

    Window_ItemList.prototype.maxCols = function() {
      return NLCLparam.itemCols; // アイテム項目の列数変更
    };

    Window_ItemList.prototype.colSpacing = function() {
      return DataManager.NLCLcolSpacing(1); // アイテム項目の列間距離変更
    };

    Window_ItemList.prototype.drawItem = function(index) { // カード画描画
      const item = this.itemAt(index);
      if (item) {
        const ct = this._category;
        const tr = ct === "weapon" ? 2 : ct === "armor" ? 3 :
                   ct === "none" ? DataManager.NLCLtr(item) : 1;
        const enabled = this.isEnabled(item) ||
                        (tr >= 2 && NLCLparam.weaponOpacity === "true");
        const rect = this.itemRect(index);
        this.drawCardItem(item, tr, 0, rect);
        this._clientArea.addChild(this._cursorSprite); // カーソル再描画
      }
    };

    // 装備画面のアイテム欄の幅調整
    Scene_Equip.prototype.statusWidth = function() {
      const iCol = NLCLparam.itemCols;
      const eCol = Window_EquipItem.prototype.maxCols();
      const gbW  = Graphics.boxWidth;
      return gbW - gbW / iCol * eCol - 12;
    };

    const _Window_EquipStatus_paramX = Window_EquipStatus.prototype.paramX
    Window_EquipStatus.prototype.paramX = function() {
      const paramX = _Window_EquipStatus_paramX.call(this);
      const pX35   = Math.floor(paramX / 5 * 3);
      const nlclX  = DataManager._NLCLequipStatusX;
      return nlclX ? (nlclX < 0 ? pX35 : nlclX) : paramX;
    };

    Window_EquipItem.prototype.maxCols = function() {
      return Math.ceil(NLCLparam.itemCols / 2);
    };

    Window_EquipItem.prototype.colSpacing = function() {
      return DataManager.NLCLcolSpacing(1);
    };

    // イベントアイテム選択での表示拡張
    const _SM_eventItemWindowRect = Scene_Message.prototype.eventItemWindowRect;
    Scene_Message.prototype.eventItemWindowRect = function() {
      const rect  = _SM_eventItemWindowRect.call(this);
      const row   = DataManager._NLCLeventItemRow || 8;
      rect.height = this.calcWindowHeight(row, true); // 4行から8行に変更
      return rect; 
    };
  }

  // 装備Slotのカード画を描画
  if (NLCLparam.equipMag) {
    const _Window_EquipSlot_updateHelp = Window_EquipSlot.prototype.updateHelp;
    Window_EquipSlot.prototype.updateHelp = function() {
      _Window_EquipSlot_updateHelp.apply(this, arguments);
      this.NLCLupdateHelp(this.item(), 2);
    };

    const _Window_EquipItem_updateHelp = Window_EquipItem.prototype.updateHelp;
    Window_EquipItem.prototype.updateHelp = function() {
      _Window_EquipItem_updateHelp.apply(this, arguments);
      this.NLCLupdateHelp(this.item(), 2);
    };

    Window_EquipItem.prototype.needsNumber = function() {
      return DataManager._NLCLequipItemNum;
    };

    const _Scene_Equip_onSlotCancel = Scene_Equip.prototype.onSlotCancel;
    Scene_Equip.prototype.onSlotCancel = function() {
      _Scene_Equip_onSlotCancel.apply(this, arguments);
      this._statusWindow.refresh();
    };

    Scene_Equip.prototype.onItemOk = function() { // ステータスウインドウをrefreshしない
      SoundManager.playEquip();
      this.executeEquipChange();
      this.hideItemWindow();
      this._slotWindow.refresh();
      this._itemWindow.refresh();
    };
  }

  // 店で購入時にカード画を描画
  if (NLCLparam.shopMag) {
    const _Window_ShopBuy_updateHelp = Window_ShopBuy.prototype.updateHelp;
    Window_ShopBuy.prototype.updateHelp = function() {
      _Window_ShopBuy_updateHelp.apply(this, arguments);
      this.NLCLupdateHelp(this.item(), 1);
    };
  }

// スキルで適用（Window_SkillList関係）
  const _Window_SkillList_initialize = Window_SkillList.prototype.initialize;
  Window_SkillList.prototype.initialize = function() {
    _Window_SkillList_initialize.apply(this, arguments);
    DataManager.NLCLpreLoad(0); // 画像プリロード
    if (NLCLparam.skillOn === "true" && DataManager._NLCLdeleteSkillBack) {
      this._contentsBackSprite.alpha = 0; // 背部黒スプライトを消す
    }
  };

  if (NLCLparam.skillOn === "true") {
    Window_SkillList.prototype.itemHeight = function() {
      return DataManager.NLCLheight(0); // スキル項目の高さ変更
    };

    Window_SkillList.prototype.maxCols = function() {
      return NLCLparam.skillCols; // スキル項目の列数変更
    };

    Window_SkillList.prototype.colSpacing = function() {
      return DataManager.NLCLcolSpacing(0); // スキル項目の列間距離変更
    };

    Window_SkillList.prototype.drawItem = function(index) { // カード画描画
      const skill = this.itemAt(index);
      if (skill) {
        const rect = this.itemRect(index);
        this.drawCardItem(skill, 0, 0, rect);
        this._clientArea.addChild(this._cursorSprite); // カーソル再描画
      }
    };
  }

// Window_Message関係（次行も一瞬表示を継続）
  const _Window_Message_clearFlags = Window_Message.prototype.clearFlags;
  Window_Message.prototype.clearFlags = function() {
    _Window_Message_clearFlags.apply(this, arguments);
    this._NLCLpreviousFast = false;
  };

  const _WM_processNewLine = Window_Message.prototype.processNewLine;
  Window_Message.prototype.processNewLine = function(textState) {
    if (DataManager._NLCLmessageFast && this._NLCLpreviousFast) {
      this._lineShowFast = true; // 次行も一瞬表示を継続
      Window_Base.prototype.processNewLine.call(this, textState);
      if (this.needsNewPage(textState)) this.startPause();
    } else {
      _WM_processNewLine.apply(this, arguments);
    }
  };

  const _WM_processEscapeCharacter = Window_Message.prototype.processEscapeCharacter;
  Window_Message.prototype.processEscapeCharacter = function(code, textState) {
    _WM_processEscapeCharacter.apply(this, arguments);
    if (code === ">") this._NLCLpreviousFast = true;
    if (code === "<") this._NLCLpreviousFast = false;
  };

// エネミーで適用（Window_BattleEnemy関係など）
  const _Window_BattleEnemy_initialize = Window_BattleEnemy.prototype.initialize;
  Window_BattleEnemy.prototype.initialize = function() {
    _Window_BattleEnemy_initialize.apply(this, arguments);
    DataManager.NLCLpreLoad(4); // 画像プリロード
    if (NLCLparam.enemyOn === "true" && DataManager._NLCLdeleteEnemyBack) {
      this._contentsBackSprite.alpha = 0; // 背部黒スプライトを消す
    }
  };

  if (NLCLparam.enemyOn === "true") {
    Window_BattleEnemy.prototype.itemHeight = function() {
      return DataManager.NLCLheight(4); // エネミー項目の高さ変更
    };

    Window_BattleEnemy.prototype.maxCols = function() {
      return NLCLparam.enemyCols; // エネミー項目の列数変更
    };

    Window_BattleEnemy.prototype.colSpacing = function() {
      return DataManager.NLCLcolSpacing(4); // エネミー項目の列間距離変更
    };

    Window_BattleEnemy.prototype.drawItem = function(index) { // カード画描画
      const enemy = this._enemies[index];
      if (enemy) {
        const rect = this.itemRect(index);
        this.drawCardItem(enemy, 4, 0, rect);
        this._clientArea.addChild(this._cursorSprite); // カーソル再描画
      }
    };

    Scene_Battle.prototype.enemyWindowRect = function() { // エネミーウインドウを拡大
      return this.skillWindowRect();
    };
  }

// アクター(戦闘ステータス)で適用（Window_BattleStatus関係など）
  const _Window_MenuStatus_initialize = Window_MenuStatus.prototype.initialize;
  Window_MenuStatus.prototype.initialize = function(rect) {
    _Window_MenuStatus_initialize.apply(this, arguments);
    DataManager.NLCLpreLoad(5); // 画像プリロード（NLM_WideScreenMZ.js対策）
  };

  const _Window_BattleStatus_initialize = Window_BattleStatus.prototype.initialize;
  Window_BattleStatus.prototype.initialize = function() {
    _Window_BattleStatus_initialize.apply(this, arguments);
    DataManager.NLCLpreLoad(5); // 画像プリロード
    this._NLCLgaugesX = this.NLCLgaugesX();
    if (NLCLparam.actorOn === "true" && DataManager._NLCLdeleteActorBack) {
      this._contentsBackSprite.alpha = 0; // 背部黒スプライトを消す
    }
  };

  Window_BattleStatus.prototype.NLCLgaugesX = function() {
    const iWidth = DataManager.NLCLitemWidth(5);
    const gWidth = 13 + Sprite_Gauge.prototype.bitmapWidth.call(this);
    return Math.floor((iWidth - gWidth) / 2);
  };

  if (NLCLparam.actorOn === "true") {
    Window_BattleStatus.prototype._makeCursorAlpha = function() {
      return DataManager._NLCLstatusCursorAlpha; // カーソル濃度
    };

    Window_BattleStatus.prototype.itemHeight = function() {
      return DataManager.NLCLheight(5); // アクター項目の高さ変更
    };

    Window_BattleStatus.prototype.maxCols = function() {
      return NLCLparam.actorCols; // アクター項目の列数変更
    };

    Window_BattleStatus.prototype.colSpacing = function() {
      return DataManager.NLCLcolSpacing(5); // アクター項目の列間距離変更
    };

    Window_BattleStatus.prototype.drawItem = function(index) {
      const actor = this.actor(index);
      actor._NLCLdeathStatusFix = actor.isDead() && NLCLparam.reverseComFile
                                  && !DataManager._NLCLnoReverse;
      this.NLCLdrawActor(index);
      this.NLCLdrawItemStatus(index);
      this._clientArea.addChild(this._cursorSprite); // カーソル再描画
    };

    Window_BattleStatus.prototype.NLCLdrawActor = function(index) {
      const actor = this.actor(index);
      if (actor._NLCLdeathStatusFix) {
        this.NLCLmakeReverse(index);
      } else {
        const rect = this.itemRect(index);
        this.drawCardItem(actor, 5, 0, rect);
      }
    };

    Window_BattleStatus.prototype.NLCLdrawItemStatus = function(index) {
      const actor = this.actor(index);
      const rect  = this.itemRectWithPadding(index);
      if (!(actor._NLCLdeathStatusFix && DataManager._NLCLdeathNoIcon)) {
        const stateIconX = this.stateIconX(rect);
        const stateIconY = this.stateIconY(rect);
        this.placeStateIcon(actor, stateIconX, stateIconY);
      }
      if (NLCLparam.gaugeAdd === "true" &&
          !(actor._NLCLdeathStatusFix && DataManager._NLCLdeathNoGauge)) {
        const basicGaugesX = this._NLCLgaugesX + rect.x + DataManager._NLCLgaugeX;
        const basicGaugesY = this.basicGaugesY(rect)    + DataManager._NLCLgaugeY;
        this.placeBasicGauges(actor, basicGaugesX, basicGaugesY);
      }
    };

    Window_BattleStatus.prototype.NLCLmakeReverse = function(index) {
      const file   = NLCLparam.reverseComFile;
      const scale  = NLCLparam.rAutoScale;
      const bitmap = ImageManager.loadPicture(file);
      bitmap.addLoadListener(function() {
        this.NLCLdrawReverse(bitmap, scale, index); // 裏面画の描画
      }.bind(this));
    };

    Window_BattleStatus.prototype.NLCLdrawReverse = function(bitmap, scale, index) {
      const div = [0, 0, bitmap.width, bitmap.height, 1, 0, 0];
      const iWidth  = DataManager.NLCLitemWidth(5);
      const iHeight = DataManager.NLCLitemHeight(5);
      const rect    = this.itemRect(index);
      const cal = ImageManager.NLCLcalc(div, iWidth, iHeight, scale);
      const sx = cal[0];
      const sy = cal[1];
      const sw = cal[2];
      const sh = cal[3];
      const rx = rect.x + 2;
      const ry = rect.y + 2;
      this.contents.blt(bitmap, sx, sy, sw, sh, rx, ry, iWidth, iHeight);
    };

    Window_BattleStatus.prototype.NLCLredrawItem = function() {
      const members = $gameParty.battleMembers();
      for (const actor of members) {
        if (actor._NLCLchangeStatus) { // 値変動時に画像更新
          actor._NLCLchangeStatus = false;
          if (actor.isDead() && NLCLparam.reverseComFile
               && !DataManager._NLCLnoReverse) {
            if (actor._NLCLdeathStatusFix) continue;
            this.refresh();
            break;
          } else if (actor.isAlive() && actor._NLCLdeathStatusFix) {
            this.refresh();
            break;
          } else {
            const rect = this.itemRect(members.indexOf(actor));
            this.drawCardItem(actor, 5, 0, rect);
          }
        }
      }
    };

    const _Window_BattleStatus_update = Window_BattleStatus.prototype.update;
    Window_BattleStatus.prototype.update = function() {
      _Window_BattleStatus_update.apply(this, arguments);
      this.NLCLredrawItem();
    };

    const _WBS_preparePartyRefresh = Window_BattleStatus.prototype.preparePartyRefresh;
    Window_BattleStatus.prototype.preparePartyRefresh = function() {
      _WBS_preparePartyRefresh.apply(this, arguments);
      this.refresh();
    };

    const _Window_BattleStatus_show = Window_BattleStatus.prototype.show;
    Window_BattleStatus.prototype.show = function() {
      _Window_BattleStatus_show.apply(this, arguments);
      this.refresh();
    };

    const _SB_selectPreviousCommand = Scene_Battle.prototype.selectPreviousCommand;
    Scene_Battle.prototype.selectPreviousCommand = function() {
      _SB_selectPreviousCommand.apply(this, arguments);
      this._statusWindow.refresh(); // MZ用カードゲームプラグイン対策
    };
  }

  if (NLCLparam.actorCentering === "true") { // 戦闘ステータス中央寄せ
    const _WBS_itemRect = Window_BattleStatus.prototype.itemRect;
    Window_BattleStatus.prototype.itemRect = function(index) {
      const rect = _WBS_itemRect.apply(this, arguments);
      const iW   = this.innerWidth;
      const col  = this.maxCols();
      const len  = $gameParty.members().length;
      if (len < col) {
        rect.x += Math.floor((iW - iW / col * len) / 2);
      }
      return rect;
    };
  }

// Sprite_Clickable関係（カードのスプライト描画）
  Sprite_Clickable.prototype.NLCLmakeBitmap = function(item, tr, org) { // 表面画
    if (!item) return;
    const itemD = tr === 4 ? item.enemy() : tr === 5 ? item.actor() : item;
    if (itemD.NLCLfolder === undefined) {
      DataManager.NLCLcategolize(itemD, tr, 0);
    }
    const bitmapM = ImageManager.NLCLload(itemD, tr);
    const bitmap1 = ImageManager.loadPicture(itemD.NLCLfile1);
    const bitmap2 = ImageManager.loadPicture(itemD.NLCLfile2);
    const bitmap3 = ImageManager.loadPicture(itemD.NLCLfile3);
    bitmapM.addLoadListener(function() {
      bitmap1.addLoadListener(function() {
        bitmap2.addLoadListener(function() {
          bitmap3.addLoadListener(function() {
            this.bitmap = NLCLcreateBitmap(item, tr, org, [bitmapM, bitmap1, bitmap2, bitmap3]);
          }.bind(this));
        }.bind(this));
      }.bind(this));
    }.bind(this));
  };

  function NLCLcreateBitmap(item, tr, org, bitmaps) {
    const tempWindow1 = new Window_Base(new Rectangle());
    const mag = org === 4 ? DataManager.NLCLenemyCardMag(item) :
                org === 5 ? DataManager.NLCLactorCardMag(item) : 2;
    const width  = DataManager.NLCLitemWidth(tr)  * mag;
    const height = DataManager.NLCLitemHeight(tr) * mag;
    tempWindow1.padding = 0;
    tempWindow1.move(0, 0, width, height);
    tempWindow1.createContents();
    tempWindow1.NLCLdrawLayout(item, tr, org, null, bitmaps);
    const bitmap = tempWindow1.contents;
    tempWindow1.contents = null;
    tempWindow1.destroy();
    return bitmap;
  };

  Sprite_Clickable.prototype.NLCLcreateReverse = function(aBitmap, scale, tr, mag) { // 裏面画
    const div = [0, 0, aBitmap.width, aBitmap.height, 1, 0, 0];
    const iWidth  = DataManager.NLCLitemWidth(tr);
    const iHeight = DataManager.NLCLitemHeight(tr);
    const cal = ImageManager.NLCLcalc(div, iWidth, iHeight, scale);
    let bitmap = new Bitmap(iWidth * mag, iHeight * mag);
    const sx = cal[0];
    const sy = cal[1];
    const sw = cal[2];
    const sh = cal[3];
    const dx = cal[4] * mag;
    const dy = cal[5] * mag;
    const dw = cal[6] * mag;
    const dh = cal[7] * mag;
    bitmap.context.drawImage(aBitmap.canvas, sx, sy, sw, sh, dx, dy, dw, dh);
    return bitmap;
  };

// Sprite_Battler関係
  Sprite_Battler.prototype.NLCLbeforeUpdate = function() {
    // Sprite_Clickable.prototype.update.call(this);を入れると武器アニメが合わなくなる
    if (this._battler && this._battler.isSpriteVisible()) {
      this.updateBitmap();
    }
  };

  Sprite_Battler.prototype.NLCLdamaged = function() { // 攻撃された時に後退するかを返す
    const result = this._battler.result();
    const damage = result.hpDamage > 0 || (DataManager._NLCLmpDamage
                                            && result.mpDamage > 0);
    const missed = result.missed || result.evaded;
    return this._NLCLcardImageOn && (damage || missed);
  };

// Sprite_Actor関係（SVアクターのカード化）
  const _Sprite_Actor_initMembers = Sprite_Actor.prototype.initMembers;
  Sprite_Actor.prototype.initMembers = function() {
    _Sprite_Actor_initMembers.apply(this, arguments);
    this._NLCLcardImageOn = false;
    if (DataManager._NLCLweaponFront) { // SVアクター前面に武器を描画
      this.createWeaponSprite();
    }
  };

  const _Sprite_Actor_update = Sprite_Actor.prototype.update;
  Sprite_Actor.prototype.update = function() {
    this.NLCLbeforeUpdate();
    if (ImageManager.isReady()) { // 画像読み込みの時間稼ぎ
      _Sprite_Actor_update.apply(this, arguments);
    }
  };

  const _Sprite_Actor_updateShadow = Sprite_Actor.prototype.updateShadow;
  Sprite_Actor.prototype.updateShadow = function() {
    if (this._NLCLcardImageOn) { // 影を非描画
      this._shadowSprite.visible = false;
    } else {
      _Sprite_Actor_updateShadow.apply(this, arguments);
    }
  };

  const _SA_setupWeaponAnimation = Sprite_Actor.prototype.setupWeaponAnimation;
  Sprite_Actor.prototype.setupWeaponAnimation = function() { // 武器アニメの描画の有無
    if (!this._NLCLcardImageOn || DataManager._NLCLweaponDraw) {
      _SA_setupWeaponAnimation.apply(this, arguments);
    }
  };

  const _SA_updateBitmap = Sprite_Actor.prototype.updateBitmap;
  Sprite_Actor.prototype.updateBitmap = function() {
    if (DataManager.NLCLactorCardMag(this._actor)) {
      this.NLCLupdateBitmap();
    } else {
      _SA_updateBitmap.apply(this, arguments);
    }
  };

  Sprite_Actor.prototype.NLCLupdateBitmap = function() { // SVアクターをカード化
    Sprite_Battler.prototype.updateBitmap.call(this);
    const actor = this._actor;
    const name  = actor.battlerName();
    if ((this._battlerName !== name || !name) && !this._NLCLcardImageOn) { // 名前がない場合も一応対処
      this._battlerName = name;
      this._NLCLcardImageOn  = true;
      this.NLCLmakeBitmap(actor);
    } else if (this._NLCLcardImageOn && actor._NLCLchangeActor) { // 値変動時の再描画
      actor._NLCLchangeActor = false;
      if (actor.isDead() && !DataManager._NLCLnoReverse) {
        if (actor._NLCLdeathSVfix) return;
        actor._NLCLdeathSVfix = true;
        this.NLCLmakeReverse(actor);
      } else {
        this.NLCLmakeBitmap(actor);
      }
    }
  };

  Sprite_Actor.prototype.NLCLmakeBitmap = function(item) { // SVアクターのカード描画
    const itemD = item.actor();
    if (itemD.NLCLfolder === undefined) {
      DataManager.NLCLcategolize(itemD, 5, 0);
    }
    const bitmapM = ImageManager.NLCLload(itemD, 5);
    const bitmap1 = ImageManager.loadPicture(itemD.NLCLfile1);
    const bitmap2 = ImageManager.loadPicture(itemD.NLCLfile2);
    const bitmap3 = ImageManager.loadPicture(itemD.NLCLfile3);
    bitmapM.addLoadListener(function() {
      bitmap1.addLoadListener(function() {
        bitmap2.addLoadListener(function() {
          bitmap3.addLoadListener(function() {
            this._mainSprite.bitmap = NLCLcreateBitmap(item, 5, 5, [bitmapM, bitmap1, bitmap2, bitmap3]);
          }.bind(this));
        }.bind(this));
      }.bind(this));
    }.bind(this));
  };

  Sprite_Actor.prototype.NLCLmakeReverse = function(actor) { // 裏面画の描画
    const file   = NLCLparam.reverseComFile;
    const scale  = NLCLparam.rAutoScale;
    const mag    = DataManager.NLCLactorCardMag(actor);
    const bitmap = ImageManager.loadPicture(file);
    bitmap.addLoadListener(function() {
      this._mainSprite.bitmap = this.NLCLcreateReverse(bitmap, scale, 5, mag);
    }.bind(this));
  };

  const _Sprite_Actor_updateFrame = Sprite_Actor.prototype.updateFrame;
  Sprite_Actor.prototype.updateFrame = function() {
    if (!this._NLCLcardImageOn) {
      _Sprite_Actor_updateFrame.apply(this, arguments);
    }
  };

  const _Sprite_Actor_updateMove = Sprite_Actor.prototype.updateMove;
  Sprite_Actor.prototype.updateMove = function() {
    if (ImageManager.isReady()) { // 画像ロード中は動きを止める（開始時アクター同士の歩幅を合わせる）
      _Sprite_Actor_updateMove.apply(this, arguments);
    }
  };

  const _SA_createDamageSprite = Sprite_Actor.prototype.createDamageSprite;
  Sprite_Actor.prototype.createDamageSprite = function() {
    _SA_createDamageSprite.apply(this, arguments);
    if (this.NLCLdamaged()) this.NLCLdamagedBack(); // ダメージ時に後退
  };

  Sprite_Actor.prototype.NLCLdamagedBack = function() {
    this.startMove(12,0,6);
  };

// Sprite_Enemy関係（敵画像のカード化）
  const _Sprite_Enemy_setBattler = Sprite_Enemy.prototype.setBattler;
  Sprite_Enemy.prototype.setBattler = function(battler) { // ステート位置変更
    _Sprite_Enemy_setBattler.apply(this, arguments);
    this._stateIconSprite.x += DataManager._NLCLenemyStateX || 0;
    this._stateIconSprite.y += DataManager._NLCLenemyStateY || 0;
  };

  const _Sprite_Enemy_update = Sprite_Enemy.prototype.update;
  Sprite_Enemy.prototype.update = function() {
    this.NLCLbeforeUpdate();
    if (ImageManager.isReady()) { // 画像読み込みの時間稼ぎ（読み込みエラー対策）
      _Sprite_Enemy_update.apply(this, arguments);
    }
  };

  const _SE_updateBitmap = Sprite_Enemy.prototype.updateBitmap;
  Sprite_Enemy.prototype.updateBitmap = function() {
    _SE_updateBitmap.apply(this, arguments);
    const enemy = this._enemy
    if (this._NLCLcardImageOn && enemy._NLCLchangeEnemy) { // 値変動時の再描画
      enemy._NLCLchangeEnemy = false;
      this.NLCLmakeBitmap(enemy, 4, 4);
    }
  };

  const _Sprite_Enemy_loadBitmap = Sprite_Enemy.prototype.loadBitmap;
  Sprite_Enemy.prototype.loadBitmap = function(name) {
    const enemy = this._enemy;
    if (DataManager.NLCLenemyCardMag(enemy)) { // 敵本体のカード化
      this._NLCLcardImageOn = true;
      this.NLCLmakeBitmap(enemy, 4, 4);
    } else {
      this._NLCLcardImageOn = false;
      _Sprite_Enemy_loadBitmap.apply(this, arguments);
    }
  };

// Sprite_Gauge関係（ゲージラベルのアイコン化）
  const _Sprite_Gauge_drawLabel = Sprite_Gauge.prototype.drawLabel;
  Sprite_Gauge.prototype.drawLabel = function() {
    const label = this.label();
    if (DataManager._NLCLgaugeLabelIcon && this.NLCLiconLabel(label)) {
      const index = parseInt(label.substr(3)) || 0;
      this.NLCLdrawIcon(index);
    } else {
      _Sprite_Gauge_drawLabel.apply(this, arguments);
    }
  };

  Sprite_Gauge.prototype.NLCLiconLabel = function(text) {
    const subs = text.substr(0,3);
    return subs === "\\i[" || subs === "\\I[";
  };

  Sprite_Gauge.prototype.NLCLdrawIcon = function(index) {
    const x = this.labelOutlineWidth() / 2;
    const y = this.labelY();
    const dot = this.textHeight();
    this.bitmap.paintOpacity = this.labelOpacity();
    Window_Base.prototype.NLCLdrawIcon(this.bitmap, index, x, y, dot);
    this.bitmap.paintOpacity = 255;
  };

  const _SG_measureLabelWidth = Sprite_Gauge.prototype.measureLabelWidth;
  Sprite_Gauge.prototype.measureLabelWidth = function() {
    if (DataManager._NLCLgaugeLabelIcon) {
      this.setupLabelFont();
      const labels = [TextManager.hpA, TextManager.mpA, TextManager.tpA];
      const widths = labels.map(str => this.NLCLmeasureTextWidth(str));
      return Math.ceil(Math.max(...widths));
    } else {
      return _SG_measureLabelWidth.apply(this, arguments);
    }
  };

  Sprite_Gauge.prototype.NLCLmeasureTextWidth = function(str) {
    if (this.NLCLiconLabel(str)) {
      return this.textHeight();
    } else {
      return this.bitmap.measureTextWidth(str);
    }
  };

// Sprite_Picture関係（ピクチャ描画）
  const _Sprite_Picture_updateBitmap = Sprite_Picture.prototype.updateBitmap;
  Sprite_Picture.prototype.updateBitmap = function() {
    _Sprite_Picture_updateBitmap.apply(this, arguments);
    const picture = this.picture();
    if (picture && picture._NLCLupdate) {
      picture._NLCLupdate = false;
      this.loadBitmap(); // 再描画
    }
  };

  Sprite_Picture.prototype.NLCLpictureSym = function(name) {
    const subs = name.substr(0,10);
    if (subs === "NLCLpicSet" || subs === "NLCLrevers") {
      return name.slice(10,11);
    }
    return null
  }

  Sprite_Picture.prototype.NLCLpictureItem = function(name) {
    const id = Number(name.slice(11)) || 0;
    switch (name.slice(10,11)) {
      case "I":
        return $dataItems[id];
      case "W":
        return $dataWeapons[id];
      case "M":
        return $dataArmors[id];
      case "S":
        return $dataSkills[id];
      case "E":
        return $gameEnemies.enemy(id);
      case "A":
        return $gameActors.actor(id);
    }
  };

  const _Sprite_Picture_loadBitmap = Sprite_Picture.prototype.loadBitmap;
  Sprite_Picture.prototype.loadBitmap = function() {
    const name = this._pictureName;
    const sym  = this.NLCLpictureSym(name)
    if (sym) {
      const tr = sym === "I" ? 1 : sym === "W" ? 2 : sym === "M" ? 3 :
                 sym === "E" ? 4 : sym === "A" ? 5 : 0;
      if (name.slice(0,10) === "NLCLrevers") { // 裏面画
        const scale = Number(name.slice(11,12));
        const file  = name.slice(12);
        this.NLCLmakeReverse(file, scale, tr);
      } else {
        const item = this.NLCLpictureItem(name); // 表面画
        this.NLCLmakeBitmap(item, tr, 3);
      }
    } else {
      _Sprite_Picture_loadBitmap.apply(this, arguments);
    }
  };

  Sprite_Picture.prototype.NLCLmakeReverse = function(file, scale, tr) { // 裏面画の描画
    if (!file) return;
    const bitmap = ImageManager.loadPicture(file);
    bitmap.addLoadListener(function() {
      this.bitmap = this.NLCLcreateReverse(bitmap, scale, tr, 2);
    }.bind(this));
  };
})();
