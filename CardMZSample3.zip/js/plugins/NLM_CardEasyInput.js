﻿/*==========================================================================
 NLM_CardEasyInput.js
----------------------------------------------------------------------------
 (C)2026 NoLimits
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
----------------------------------------------------------------------------
 Version
 1.0.0 2026/04/06 初版
============================================================================*/

/*:
 * @target MZ
 * @plugindesc カード簡易入力プラグイン (v1.0.0)
 * @author ノリミツ (NoLimits)
 * @url https://github.com/nolimits-tukool
 * 
 * @param overwrite
 * @text 読み取り優先順
 * @desc メモ欄とプラグインの両方で同じ項目を入力時の読み取り優先順　（デフォルト：プラグイン入力を優先）
 * @type select
 * @option プラグイン入力を優先
 * @option メモ欄記載を優先
 * @option メモを無効化しプラグイン入力のみ
 * @default プラグイン入力を優先
 * 
 * @param itemInput
 * @text アイテムメモ入力
 * @desc アイテムの「メモ」を入力（全てを記入する必要はありません）　（ダブルクリックで入力。IDは順不同で構いません）
 * @type struct<Iinput>[]
 * 
 * @param skillInput
 * @text スキルメモ入力
 * @desc スキルの「メモ」を入力（全てを記入する必要はありません）　（ダブルクリックで入力。IDは順不同で構いません）
 * @type struct<Sinput>[]
 * 
 * @param enemyInput
 * @text エネミーメモ入力
 * @desc エネミーの「メモ」を入力（全てを記入する必要はありません）　（ダブルクリックで入力。IDは順不同で構いません）
 * @type struct<Einput>[]
 *
 * @param actorInput
 * @text アクターメモ入力
 * @desc アクターの「メモ」を入力（全てを記入する必要はありません）　（ダブルクリックで入力。IDは順不同で構いません）
 * @type struct<Ainput>[]
 * 
 * @param weaponInput
 * @text 武器メモ入力
 * @desc 武器の「メモ」を入力（全てを記入する必要はありません）　（ダブルクリックで入力。IDは順不同で構いません）
 * @type struct<Winput>[]
 *
 * @param armorInput
 * @text 防具メモ入力
 * @desc 防具の「メモ」を入力（全てを記入する必要はありません）　（ダブルクリックで入力。IDは順不同で構いません）
 * @type struct<Minput>[]
 * 
 * @param classInput
 * @text 職業メモ入力
 * @desc 職業の「メモ」を入力（NLM_CardGameMZ.js併用時で、戦闘コマンド生成<nxcommand>を指定したい時のみ記入）
 * @type struct<Cinput>[]
 * 
 * @param backupFile
 * @text バックアップ出力
 * @desc 上記メモ入力のテキストデータファイルをゲーム開始時にsaveフォルダに出力（作成中はONにして、ゲーム公開時にOFF推奨)
 * @type boolean
 * @default false
 * 
 * 
 * @help
 * 
 * 【RPGツクールMZ専用プラグイン】
 *  本プラグインは NLM_CardLayoutMZ.js, NLM_CardGameMZ.js, NLM_ItemToSummon.js
 * のメモ欄入力を補助・代行するプラグインです
 * （上記プラグインの少なくとも1つ以上併用が必須となります）
 * （NLM_CardGameMZ.js は v1.2 以降でないと本プラグインが正常に動作しません）
 * 
 * 　上記プラグインを使う際に、データベース上の「メモ」欄を多数記入する必要が
 *  ありますが、本プラグインのパラメータを入力するだけで、メモ欄記入の代用が
 *  できます（利用する際は本プラグインをONにして下さい）
 * 
 * 　パラメータへ全て入力することで,メモ欄が白紙状態でもゲームを作成できますが
 *  メモ欄に記載の方が見直しやすい項目もあるので、「読み取り優先順」を設定して
 *  メモ欄記入と併用してゲームを作成していくことをお勧めします
 * （画像ファイル入力は、パラメータ入力の方が圧倒的に容易のため、画像ファイル
 *  　の入力だけでも本プラグインを利用してみるとよいでしょう）
 * 
 * 【読み取り優先順について】（メモ欄とパラメータの両方で同じ項目を入力した時)
 *  「プラグイン入力を優先」：
 * 　　パラメータ入力を優先し、パラメータ記載のない項目はメモ欄を参照します
 * 　　（メモ欄を追記しても、パラメータ入力があるとそちらを優先してしまうため
 * 　　　 不要なパラメータは「削除」「クリア」して下さい）
 *  「メモ欄記載を優先」:
 * 　　メモ欄の記載内容を優先し、メモ記入のない項目はパラメータを参照します
 * 　　（パラメータを追記しても、メモに記載があるとそちらを優先してしまうため
 * 　　　 不要なメモは消去して下さい）
 *  「メモを無効化しプラグイン入力のみ」:
 * 　　メモ記載があっても無記入扱いとし、パラメータ記入のみを参照します
 * 　　（NLM_CardLayoutMZ.js, NLM_CardGameMZ.js, NLM_ItemToSummon.jsに関する
 * 　　　メモのみ無効化し、他のプラグイン用のメモには影響がありません）
 *  ※ プラグイン入力を無効化し、メモ記載のみで起動したい際は本プラグイン自体
 * 　 をOFFにして下さい
 * 
 * 【補足】
 * 　・ データベースの「メモ」の記載自体が消えたり、上書きされたりはしません！
 * 　　　あくまで、ゲーム起動時の読み取りをパラメータと交換させているだけです
 * 　・ パラメータ入力時は右クリックで「コピー」「貼り付け」「クリア」「削除」
 * 　　　等が可能のほか、複数項目記入時の下から上へのドラッグもできます
 * 　・ 本プラグイン単独では、メモ入力操作以外のゲーム機能はありません
 * 　・ プラグインリストから削除すると、全入力データが初期化されるため、入力量
 * 　　　が多い場合は「バックアップ出力」をONにしておくと安全です
 * 
 * 【バックアップ出力からの復帰法】
 * 　 パラメータ「バックアップ出力」をONにするとゲーム起動時にsaveフォルダ下に
 * 　　Card_xxxInput.txt が出力されます。これをメモ帳などのエディタで開き、
 * 　　すべて選択・コピーし、パラメータ該当欄（「アイテムメモ入力」など）上で
 * 　　右クリック「テキストとして編集」でペーストし、OKすると復帰できます
 * 
 * プラグインコマンドはありません
 * 利用規約はMITライセンスの通りです
 */

/*~struct~Iinput:
 * 
 * @param id
 * @text アイテムID
 * @desc アイテムID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type item
 * @default 0
 * 
 * @param file
 * @text 画像ファイル
 * @desc カードのメイン画のファイル名入力（<CIPic>などに自動選別)（battlebacks, parallaxes, titlesの各フォルダは利用不可）
 * @type file
 * @dir img
 * @default pictures
 * 
 * @param cadd
 * @text 画像補足<cadd>
 * @desc カードのメイン画の補足情報<cadd>を入力（必要な所のみ記入)（画像ファイルが未入力だと、上記入力値は無効になります)
 * @type struct<Cadd>
 * 
 * @param ncard
 * @text カード情報<ncard>
 * @desc カード情報<ncard>を入力（NLM_CardGameMZ.js併用時に必要なもののみ記入。「大事なもの」は1-2番目のみ有効）
 * @type struct<Incard>
 * 
 * @param TPcost
 * @text TPコスト
 * @desc TPコスト値<TPcost>を入力（数字のほか,スクリプトを利用可。変数値はv[],アイテムIDはcIdで置換される)
 * @type multiline_string
 * 
 * @param MPcost
 * @text MPコスト
 * @desc MPコスト値<MPcost>を入力（数字のほか,スクリプトを利用可。変数値はv[],アイテムIDはcIdで置換される)
 * @type multiline_string
 * 
 * @param excLayout
 * @text レイアウト置換
 * @desc レイアウト個別置換<ctxt> <ccolor> <vcolor>を必要なだけ入力（後で頻繁に見直す場合はメモ欄記載の方がいいかも）
 * @type struct<Layout>[]
 * 
 * @param NoLayout
 * @text レイアウト消去
 * @desc レイアウトの個別消去<NoLayout>で消去したいレイアウト番号（レイアウト項目の上からの順番）をすべて記入
 * @type number[]
 * @min 1
 * 
 * @param operateCard
 * @text カード操作関連
 * @desc NLM_CardGameMZ.jsとNLM_ItemToSummon.jsの操作関連のメモ入力（影響が大きいので不要分は右クリック「クリア」しておく)
 * @type struct<Operate>
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Sinput:
 * 
 * @param id
 * @text スキルID
 * @desc スキルID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type skill
 * @default 0
 * 
 * @param file
 * @text 画像ファイル
 * @desc カードのメイン画のファイル名入力（<CSPic>などに自動選別)（battlebacks, parallaxes, titlesの各フォルダは利用不可）
 * @type file
 * @dir img
 * @default pictures
 * 
 * @param cadd
 * @text 画像補足<cadd>
 * @desc カードのメイン画の補足情報<cadd>を入力（必要な所のみ記入)（画像ファイルが未入力だと、上記入力値は無効になります)
 * @type struct<Cadd>
 * 
 * @param excLayout
 * @text レイアウト置換
 * @desc レイアウト個別置換<ctxt> <ccolor> <vcolor>を必要なだけ入力（後で頻繁に見直す場合はメモ欄記載の方がいいかも）
 * @type struct<Layout>[]
 * 
 * @param NoLayout
 * @text レイアウト消去
 * @desc レイアウトの個別消去<NoLayout>で消去したいレイアウト番号（レイアウト項目の上からの順番）をすべて記入
 * @type number[]
 * @min 1
 * 
 * @param nskill
 * @text スキル情報<nskill>
 * @desc スキル情報<nskill>を入力（NLM_CardGameMZ.js併用時に必要なもののみ記入）
 * @type struct<Sncard>

 * @param nxcond
 * @text <nxcond>
 * @desc 条件によるダメージ変化<nxcond>入力　　　　　　　　　　　（NLM_CardGameMZ.js併用時）
 * @type struct<Nxcond>
 * 
 * @param mpPene
 * @text <MPpenetrate>
 * @desc MPシールドを無視してHPのみにダメージを与える<MPpenetrate>を入力するか（NLM_CardLayoutMZ.js併用時）
 * @type select
 * @option noSelect
 * @option ON
 * @option OFF
 * @default noSelect
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Einput:
 * 
 * @param id
 * @text エネミーID
 * @desc エネミーID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type enemy
 * @default 0
 * 
 * @param file
 * @text 画像ファイル
 * @desc カードのメイン画のファイル名入力（<CESve>などに自動選別)（battlebacks, parallaxes, titlesの各フォルダは利用不可）
 * @type file
 * @dir img
 * @default sv_enemies
 * 
 * @param cadd
 * @text 画像補足<cadd>
 * @desc カードのメイン画の補足情報<cadd>を入力（必要な所のみ記入)（画像ファイルが未入力だと、上記入力値は無効になります)
 * @type struct<Cadd>
 * 
 * @param excLayout
 * @text レイアウト置換
 * @desc レイアウト個別置換<ctxt> <ccolor> <vcolor>を必要なだけ入力（後で頻繁に見直す場合はメモ欄記載の方がいいかも）
 * @type struct<Layout>[]
 * 
 * @param NoLayout
 * @text レイアウト消去
 * @desc レイアウトの個別消去<NoLayout>で消去したいレイアウト番号（レイアウト項目の上からの順番）をすべて記入
 * @type number[]
 * @min 1
 * 
 * @param nxmag
 * @text カード化倍率％
 * @desc カード化倍率を個別に変更する<nxmag>を％で入力　　　　　　（-1で無記入扱い、0で置換されなくなる）
 * @type number
 * @min -1
 * @default -1
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Ainput:
 * 
 * @param id
 * @text アクターID
 * @desc アクターID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type actor
 * @default 0
 * 
 * @param file
 * @text 画像ファイル
 * @desc カードのメイン画のファイル名入力（<CEPic>などに自動選別)（battlebacks, parallaxes, titlesの各フォルダは利用不可）
 * @type file
 * @dir img
 * @default pictures
 * 
 * @param cadd
 * @text 画像補足<cadd>
 * @desc カードのメイン画の補足情報<cadd>を入力（必要な所のみ記入)（画像ファイルが未入力だと、上記入力値は無効になります)
 * @type struct<Cadd>
 * 
 * @param excLayout
 * @text レイアウト置換
 * @desc レイアウト個別置換<ctxt> <ccolor> <vcolor>を必要なだけ入力（後で頻繁に見直す場合はメモ欄記載の方がいいかも）
 * @type struct<Layout>[]
 * 
 * @param NoLayout
 * @text レイアウト消去
 * @desc レイアウトの個別消去<NoLayout>で消去したいレイアウト番号（レイアウト項目の上からの順番）をすべて記入
 * @type number[]
 * @min 1
 * 
 * @param nxmag
 * @text カード化倍率％
 * @desc カード化倍率を個別に変更する<nxmag>を％で入力　　　　　　（-1で無記入扱い、0で置換されなくなる）
 * @type number
 * @min -1
 * @default -1
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Winput:
 * 
 * @param id
 * @text 武器ID
 * @desc 武器ID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type weapon
 * @default 0
 * 
 * @param file
 * @text 画像ファイル
 * @desc カードのメイン画のファイル名入力（<CWPic>などに自動選別)（battlebacks, parallaxes, titlesの各フォルダは利用不可）
 * @type file
 * @dir img
 * @default pictures
 * 
 * @param cadd
 * @text 画像補足<cadd>
 * @desc カードのメイン画の補足情報<cadd>を入力（必要な所のみ記入)（画像ファイルが未入力だと、上記入力値は無効になります)
 * @type struct<Cadd>
 * 
 * @param excLayout
 * @text レイアウト置換
 * @desc レイアウト個別置換<ctxt> <ccolor> <vcolor>を必要なだけ入力（後で頻繁に見直す場合はメモ欄記載の方がいいかも）
 * @type struct<Layout>[]
 * 
 * @param NoLayout
 * @text レイアウト消去
 * @desc レイアウトの個別消去<NoLayout>で消去したいレイアウト番号（レイアウト項目の上からの順番）をすべて記入
 * @type number[]
 * @min 1
 * 
 * @param ncard
 * @text カード情報<ncard>
 * @desc カード情報<ncard>を入力（NLM_CardGameMZ.js併用時で、ガチャ対象にしたい場合のみ記入）
 * @type struct<Wncard>
 * 
 * @param TPcost
 * @text TPコスト
 * @desc TPコスト値<TPcost>を入力（数字のほか,スクリプトを利用可。武器では利用できないので表示のみ)
 * @type multiline_string
 * 
 * @param MPcost
 * @text MPコスト
 * @desc MPコスト値<MPcost>を入力（数字のほか,スクリプトを利用可。武器では利用できないので表示のみ)
 * @type multiline_string
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Minput:
 * 
 * @param id
 * @text 防具ID
 * @desc 防具ID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type armor
 * @default 0
 * 
 * @param file
 * @text 画像ファイル
 * @desc カードのメイン画のファイル名入力（<CMPic>などに自動選別)（battlebacks, parallaxes, titlesの各フォルダは利用不可）
 * @type file
 * @dir img
 * @default pictures
 * 
 * @param cadd
 * @text 画像補足<cadd>
 * @desc カードのメイン画の補足情報<cadd>を入力（必要な所のみ記入)（画像ファイルが未入力だと、上記入力値は無効になります)
 * @type struct<Cadd>
 * 
 * @param excLayout
 * @text レイアウト置換
 * @desc レイアウト個別置換<ctxt> <ccolor> <vcolor>を必要なだけ入力（後で頻繁に見直す場合はメモ欄記載の方がいいかも）
 * @type struct<Layout>[]
 * 
 * @param NoLayout
 * @text レイアウト消去
 * @desc レイアウトの個別消去<NoLayout>で消去したいレイアウト番号（レイアウト項目の上からの順番）をすべて記入
 * @type number[]
 * @min 1
 * 
 * @param ncard
 * @text カード情報<ncard>
 * @desc カード情報<ncard>を入力（NLM_CardGameMZ.js併用時で、ガチャ対象にしたい場合のみ記入）
 * @type struct<Wncard>
 * 
 * @param TPcost
 * @text TPコスト
 * @desc TPコスト値<TPcost>を入力（数字のほか,スクリプトを利用可。防具では利用できないので表示のみ)
 * @type multiline_string
 * 
 * @param MPcost
 * @text MPコスト
 * @desc MPコスト値<MPcost>を入力（数字のほか,スクリプトを利用可。防具では利用できないので表示のみ)
 * @type multiline_string
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Cinput:
 *
 * @param id
 * @text 職業ID
 * @desc 職業ID番号（メモ欄のみで指定したい時はIDを「なし」にすれば、以下の記入が無効になる）
 * @type class
 * @default 0
 * 
 * @param nxcommand
 * @text 戦闘コマンド
 * @desc 戦闘アクターコマンドを生成する<nxcommand>を配列順に入力（全省略時は <nxcommand:i,a,s,g> になる）
 * @type select[]
 * @option a：攻撃(attack)
 * @value a
 * @option s：スキル(skill)
 * @value s
 * @option g：防御(guard)
 * @value g
 * @option i：アイテム(item)
 * @value i
 * 
 * @param developerConsole
 * @text デベロッパツール表示
 * @desc 最終的に読み取られたメモ情報をデベロッパツールのConsoleに確認表示するか（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default false
 */

/*~struct~Cadd:
 *
 * @param cmag
 * @text 画像倍率％
 * @desc 画像倍率を％で入力（デフォルト：100）　　　　　　　　　　（メモ欄では小数点記入ですが、本プラグインでは％で入力）
 * @type number
 * @min -9999999
 * @default 100
 * 
 * @param cx
 * @text X座標
 * @desc 1枚に複数画像がある場合（顔画像やSVアクターなど）のみ有効のX座標を指定（一番左をゼロとして数え始める）
 * @type number
 * @default 0
 * 
 * @param cy
 * @text Y座標
 * @desc 1枚に複数画像がある場合（顔画像やSVアクターなど）のみ有効のY座標を指定（一番上をゼロとして数え始める）
 * @type number
 * @default 0
 * 
 * @param px
 * @text 補正X座標
 * @desc 画像位置をずらしたい時の補正X座標　　　　　　　　　　　　（左にずらしたい時はマイナス値入力）
 * @type number
 * @min -9999
 * @default 0
 *
 * @param py
 * @text 補正Y座標
 * @desc 画像位置をずらしたい時の補正Y座標　　　　　　　　　　　　（上にずらしたい時はマイナス値入力）
 * @type number
 * @min -9999
 * @default 0
 *
 * @param icon
 * @text アイコン番号
 * @desc 画像ファイルを「system」フォルダ下の「IconSet」に指定した時のみ有効のアイコン番号
 * @type icon
 * @default 0
 * 
 * @param ccx
 * @text X連結数
 * @desc 「tilesets」フォルダを指定した時のみ有効のX連結数　　　　（横に連結するタイル数）
 * @type number
 * @min 1
 * @default 1
 * 
 * @param ccy
 * @text Y連結数
 * @desc 「tilesets」フォルダを指定した時のみ有効のY連結数　　　　（縦に連結するタイル数）
 * @type number
 * @min 1
 * @default 1
 */

/*~struct~Incard:
 * 
 * @param group
 * @text グループ番号
 * @desc ガチャの対象設定で必要となる「グループ番号」　　　　　　　（1以上でガチャ対象となる）
 * @type number
 * @default 0
 * 
 * @param rare
 * @text レア値
 * @desc ガチャ当選で利用される「レア値」
 * @type number
 * @default 0
 * 
 * @param sameMax
 * @text 最大枚数
 * @desc デッキでの最大枚数（0 の際はNLM_CardGameMZ.js「同一カード最大数」パラメータ値となる）
 * @type number
 * @default 0
 * 
 * @param commonId
 * @text コモンイベントID
 * @desc カード使用直前に実行されるコモンイベントID　　　　　　　　(「なし」だと代わりに「使用直前共通イベント」が実行される)
 * @type common_event
 * @default 0
 * 
 * @param weaponType
 * @text 武器タイプ
 * @desc 使用時の武器アニメ。データベース→タイプ→武器タイプの値で素手は 0、装備武器は -1 と入力。サイドビュー時のみ有効
 * @type number
 * @min -1
 * @default 0
 *
 * @param motion
 * @text モーション
 * @desc 使用時のモーション。武器タイプが 0 の時のみ有効で、noSelect時はitemとなる。サイドビュー時のみ有効
 * @type select
 * @option noSelect
 * @option wait
 * @option walk
 * @option chant
 * @option guard
 * @option damage
 * @option evade
 * @option thrust
 * @option swing
 * @option missile
 * @option skill
 * @option spell
 * @option item
 * @option escape
 * @option victory
 * @option dying
 * @option abnormal
 * @option sleep
 * @option dead
 * @default noSelect
 */

/*~struct~Sncard:
 * 
 * @param commonId
 * @text コモンイベントID
 * @desc スキル使用直前に実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param weaponType
 * @text 武器タイプ
 * @desc 使用時の武器アニメ。データベース→タイプ→武器タイプの値で素手は 0、装備武器は -1 と入力。サイドビュー時のみ有効
 * @type number
 * @min -1
 * @default 0
 *
 * @param motion
 * @text モーション
 * @desc 使用時のモーション。武器タイプが 0 の時のみ有効で、noSelect時はskillかspellとなる。サイドビュー時のみ有効
 * @type select
 * @option noSelect
 * @option wait
 * @option walk
 * @option chant
 * @option guard
 * @option damage
 * @option evade
 * @option thrust
 * @option swing
 * @option missile
 * @option skill
 * @option spell
 * @option item
 * @option escape
 * @option victory
 * @option dying
 * @option abnormal
 * @option sleep
 * @option dead
 * @default noSelect
 */

/*~struct~Wncard:
 * 
 * @param group
 * @text グループ番号
 * @desc ガチャの対象設定で必要となる「グループ番号」　　　　　　（1以上でガチャ対象となる）
 * @type number
 * @default 0
 * 
 * @param rare
 * @text レア値
 * @desc ガチャ当選で利用される「レア値」
 * @type number
 * @default 0
 */

/*~struct~Layout:
 * 
 * @param lType
 * @text 置換タイプ
 * @desc 置換タイプ
 * @type select
 * @option 自由文字置換 <ctxt>
 * @value ctxt
 * @option 色1置換 <ccolor>
 * @value ccolor
 * @option 色1変数置換 <vcolor>
 * @value vcolor
 * @option レイヤー置換（<LIPic> <LSPic>など)
 * @value LXPic
 * @default ctxt
 *
 * @param memoId
 * @text メモ置換番号
 * @desc <ctxt> <ccolor> <vcolor>で置換したいメモ置換番号(1-9)　（NLM_CardLayoutMZ.js内での指定と一致させる）
 * @type number
 * @min 1
 * @max 9
 * @default 1
 * 
 * @param ctxt
 * @text 置換文章
 * @desc <ctxt>のみ有効で、置換したい文章
 * @type string
 * 
 * @param ccolor
 * @text 色番号
 * @desc <ccolor>のみ有効で、変更したい色番号
 * @type color
 * @default 0
 * 
 * @param vcolor
 * @text 変数番号
 * @desc <vcolor>のみ有効で、指定したい変数ID
 * @type variable
 * @default 0
 * 
 * @param layerId
 * @text レイヤー番号
 * @desc レイヤー置換のみ有効で、置換したいレイヤー番号(1-3)（NLM_CardLayoutMZ.js内での指定と一致させる）
 * @type number
 * @min 1
 * @max 3
 * @default 1
 * 
 * @param layerFile
 * @text ファイル名
 * @desc レイヤー置換のみ有効で、置換したいファイル名　　　　（picturesフォルダのみ指定可)
 * @type file
 * @dir img/pictures
 */

/*~struct~Operate:
 * 
 * @param nxcond
 * @text <nxcond>
 * @desc 条件によるダメージ変化<nxcond>入力
 * @type struct<Nxcond>
 * 
 * @param DeckUseSw
 * @text <DeckUseSw>
 * @desc 指定スイッチがON時のみ、デッキ交換ができる<DeckUseSw>のスイッチID
 * @type switch
 * 
 * @param HandUseSw
 * @text <HandUseSw>
 * @desc 指定スイッチがON時のみ、戦闘時などで使用できる<HandUseSw>のスイッチID
 * @type switch
 * 
 * @param HandState
 * @text <HandState>
 * @desc 手札入手時に味方全員そのステートにかかる<HandState>のステートID
 * @type state
 * 
 * @param BoardState
 * @text <BoardState>
 * @desc 場札移動時に味方全員そのステートにかかる<BoardState>のステートID
 * @type state
 * 
 * @param nxactor
 * @text <nxactor>
 * @desc 羅列アクターのみ使用可能になる<nxactor>のアクターIDを全て記入（1つでも記入すると記入外アクターでは使用不可になる）
 * @type actor[]
 * 
 * @param mpPene
 * @text <MPpenetrate>
 * @desc MPシールドを無視してHPのみにダメージを与える<MPpenetrate>を入力するか（noSelectだと無記入状態となる）
 * @type select
 * @option noSelect
 * @option ON
 * @option OFF
 * @default noSelect
 * 
 * @param isummon
 * @text <isummon>
 * @desc NLM_ItemToSummon.js併用時のみ有効の召喚<isummon>のメモ入力（必要な場合のみ入力)
 * @type struct<Isummon>
 */

/*~struct~Nxcond:
 * 
 * @param xObject
 * @text 対象
 * @desc <nxcond>の対象を設定
 * @type select
 * @option deck：  山札
 * @value deck
 * @option disc：  捨札
 * @value disc
 * @option board： 場札
 * @value board
 * @option hand：  手札（使用カードは条件に含めず)
 * @value hand
 * @option skill： 使用者の取得スキル
 * @value skill
 * @option class： 職業（使用者も所持すること）
 * @value class
 * @option member：戦闘メンバー（使用者も含めること)
 * @value member
 * @default deck
 *
 * @param xiIds
 * @text 対象カードID
 * @desc 対象が「山札・捨札・場札・手札」の際の対象IDをすべて記入
 * @type item[]
 * 
 * @param xsIds
 * @text 対象スキルID
 * @desc 対象が「使用者の取得スキル」の際の対象IDをすべて記入
 * @type skill[]
 *
 * @param xcIds
 * @text 対象職業ID
 * @desc 対象が「職業」の際の対象IDをすべて記入（使用者も所持すること）
 * @type class[]
 *
 * @param xaIds
 * @text 対象アクターID
 * @desc 対象が「戦闘メンバー」の際の対象アクターIDをすべて記入　　（使用者も含めること)
 * @type actor[]
 * 
 * @param xCond
 * @text 条件
 * @desc <nxcond>発動に必要な対象の条件
 * @type select
 * @option 1：すべて存在
 * @value 1
 * @option 2：どれか存在
 * @value 2
 * @option 3：存在数だけ倍率累乗
 * @value 3
 * @default 1
 *
 * @param xMag
 * @text 倍率％
 * @desc <nxcond>発動時に計算式ダメージに乗算される倍率％　　　　　（デフォルト：100）（プラグインでは％で入力）
 * @type number
 * @default 100
 */

/*~struct~Isummon:
 * 
 * @param actorId
 * @text アクターID
 * @desc <isummon>で指定するアクターID（指定されたアクターはアイテムによる召喚以外では「アクターを加える」ことができない！）
 * @type actor
 * @default 0
 *
 * @param motion
 * @text モーション
 * @desc <isummon>で指定する召喚モーション。noSelect時はvictoryとなる。サイドビュー時のみ有効
 * @type select
 * @option noSelect
 * @option wait
 * @option walk
 * @option chant
 * @option guard
 * @option damage
 * @option evade
 * @option thrust
 * @option swing
 * @option missile
 * @option skill
 * @option spell
 * @option item
 * @option escape
 * @option victory
 * @option dying
 * @option abnormal
 * @option sleep
 * @option dead
 * @default noSelect
 */


(() => {
  "use strict";

  const pluginName = "NLM_CardEasyInput";
  const NCEIparam = PluginManager.parameters(pluginName);

  let NCEIdraft = [];

  DataManager._NCEIpre  = ["Pic", "Ene", "Sve", "Cha", "Fac", "Sva", "Ani", "Sys", "Til"];
  DataManager._NCEImeta = ["ncard", "nskill", "TPcost", "MPcost", "NoLayout",
                           "nxcond", "DeckUseSw", "HandUseSw", "HandState",
                           "BoardState", "nxactor", "isummon", "nxmag"];
  DataManager._NCEIinp  = ["itemInput", "skillInput", "enemyInput", "actorInput",
                           "weaponInput", "armorInput", "classInput"];

  const _DataManager_onXhrLoad = DataManager.onXhrLoad;
  DataManager.onXhrLoad = function(xhr, name, src, url) {
    if (xhr.status < 400) {
      window[name] = JSON.parse(xhr.responseText);
      this.onLoad(window[name], name); // name追加
    } else {
      _DataManager_onXhrLoad.apply(this, arguments);
    }
  };

  const _DataManager_onLoad = DataManager.onLoad;
  DataManager.onLoad = function(object, name) { // name追加
    _DataManager_onLoad.apply(this, arguments);
    this.NCEIoverwriteArrayMetadata(object, name);
  };

  DataManager.NCEIoverwriteArrayMetadata = function(array, name) {
    switch(name) {
      case "$dataItems":
        this.NCEIoverwriteMetadata(array, 0, "I", "item");
        break;
      case "$dataSkills":
        this.NCEIoverwriteMetadata(array, 1, "S", "skill");
        break;
      case "$dataEnemies":
        this.NCEIoverwriteMetadata(array, 2, "E", "enemy");
        break;
      case "$dataActors":
        this.NCEIoverwriteMetadata(array, 3, "A", "actor");
        break;
      case "$dataWeapons":
        this.NCEIoverwriteMetadata(array, 4, "W", "weapon");
        break;
      case "$dataArmors":
        this.NCEIoverwriteMetadata(array, 5, "M", "armor");
        break;
      case "$dataClasses":
        this.NCEIoverwriteClassMeta(array);
        break;
    }
  };

  DataManager.NCEIoverwriteMetadata = function(array, draftId, pre, name) {
    const draft  = NCEIdraft[draftId];
    const oWrite = NCEIparam.overwrite;
    for (let id = 1; id < array.length; id++) {
      const meta  = array[id].meta;
      if (oWrite === 3) this.NCEIdeleteMeta(meta, pre);
      if (!draft) continue;
      const index = this.NCEIindexOfDraft(draft, id);
      if (index === -1) continue;
      const data = draft[index];
      this.NCEIoverwriteMeta(meta, data, pre, oWrite === 2);
      if (data.developerConsole === "true") {
        this.NCEIconsoleLogMeta(array, id, meta, name);
      }
    }
  };

  DataManager.NCEIoverwriteClassMeta = function(array) {
    const draft  = NCEIdraft[6];
    const oWrite = NCEIparam.overwrite;
    for (let id = 1; id < array.length; id++) {
      const meta  = array[id].meta;
      if (oWrite === 3) delete meta.nxcommand;
      if (!draft) continue;
      const index = this.NCEIindexOfDraft(draft, id);
      if (index === -1) continue;
      const data    = draft[index];
      const dNxcomm = data.nxcommand;
      const eva = oWrite === 2 && meta.nxcommand;
      if (dNxcomm && !eva) {
        meta.nxcommand = this.NCEIconnectElement(dNxcomm);
      }
      if (data.developerConsole === "true") {
        this.NCEIconsoleLogMeta(array, id, meta, "class");
      }
    }
  };

  DataManager.NCEIindexOfDraft = function(draft, id) {
    for (const data of draft) {
      if (data.id === id) return draft.indexOf(data);
    }
    return -1
  };

  DataManager.NCEIdeleteMeta = function(meta, pre) {
    this.NCEIdeleteFolder(meta, pre);
    delete meta.cadd;
    for (const key of this._NCEImeta) {
      delete meta[key];
    }
    this.NCEIdeleteExcLayout(meta, pre);
    delete meta.MPpenetrate;
  };

  DataManager.NCEIdeleteFolder = function(meta, pre) {
    for (const elm of this._NCEIpre) {
      delete meta["C" + pre + elm];
    }
  };

  DataManager.NCEIdeleteExcLayout = function(meta, pre) {
    const arr = ["ctxt", "ccolor", "vcolor", "L" + pre + "Pic"];
    for (const elm of arr) {
      for (let i=1; i<=9; i++) {
        delete meta[elm + i]
      }
    }
  };

  DataManager.NCEIconsoleLogMeta = function(array, id, meta, name) {
    const dName = "(" + array[id].name + ")";
    console.log(name + " ID:", id, dName, meta);
  };

  DataManager.NCEIoverwriteMeta = function(meta, data, pre, ow2) {
    const eva = ow2 ? !this.NCEIinvolveMetaFolder(pre, meta) : true;
    if (data.pFolder && eva) {
      this.NCEIdeleteFolder(meta, pre);
      meta["C" + pre + data.pFolder] = data.pFile;
      if (data.cadd) this.NCEIoverwriteCadd(meta, data);
    }
    for (const key of this._NCEImeta) { 
      if (!data[key] || (ow2 && meta[key])) continue;
      switch(key) {
        case "ncard":
          this.NCEIoverwriteNcard(meta, data.ncard);
          break;
        case "NoLayout":
          meta.NoLayout = this.NCEIconnectElement(data.NoLayout);
          break;
        case "nskill":
          this.NCEIoverwriteNskill(meta, data.nskill);
          break;
        case "nxcond":
          this.NCEIoverwriteNxcond(meta, data.nxcond);
          break;
        case "nxactor":
          meta.nxactor = this.NCEIconnectElement(data.nxactor);
          break;
        case "isummon":
          this.NCEIoverwriteIsummon(meta, data.isummon);
          break;
        case "nxmag":
          if (data.nxmag !== "-1") meta.nxmag = data.nxmag;
          break;
        default:
          meta[key] = data[key];
          break;
      }
    }
    this.NCEIoverwriteExcLayout(meta, data.excLayout, pre, ow2);
    this.NCEIoverwriteMPpenetrate(meta, data.mpPene, ow2);
  };

  DataManager.NCEIinvolveMetaFolder = function(pre, meta) {
    for (const elm of this._NCEIpre) {
      if (meta["C" + pre + elm]) return true;
    }
    return false;
  };

  DataManager.NCEIoverwriteCadd = function(meta, data) {
    const dCadd = data.cadd;
    const mCadd = [];
    switch(data.pFolder) {
      case "Pic":
      case "Ene":
      case "Sve":
        mCadd[0] = this.NCEIchangePercent(dCadd.cmag);
        mCadd[1] = dCadd.px;
        mCadd[2] = dCadd.py;
        break;
      case "Sys":
        if (data.pFile === "IconSet") {
          mCadd[0] = dCadd.icon
          mCadd[1] = this.NCEIchangePercent(dCadd.cmag);
          mCadd[2] = dCadd.px;
          mCadd[3] = dCadd.py;
          break;
        }
      case "Cha":
      case "Fac":
      case "Sva":
      case "Ani":
        mCadd[0] = dCadd.cx;
        mCadd[1] = dCadd.cy;
        mCadd[2] = this.NCEIchangePercent(dCadd.cmag);
        mCadd[3] = dCadd.px;
        mCadd[4] = dCadd.py;
        break;
      case "Til":
        mCadd[0] = dCadd.cx;
        mCadd[1] = dCadd.cy;
        mCadd[2] = dCadd.ccx;
        mCadd[3] = dCadd.ccy;
        mCadd[4] = this.NCEIchangePercent(dCadd.cmag);
        mCadd[5] = dCadd.px;
        mCadd[6] = dCadd.py;
        break;
    }
    meta.cadd = this.NCEIconnectElement(mCadd);
  };

  DataManager.NCEIchangePercent = function(str) {
    return String((parseInt(str) || 0) / 100);
  };

  DataManager.NCEIconnectElement = function(arr) {
    let str = "";
    for (let i=0; i < arr.length; i++) {
      if (arr[i]) {
        if (i > 0) str += ", ";
        str += arr[i];
      }
    }
    return str;
  };

  DataManager.NCEIconnectArr = function(data, arr) {
    let str = "";
    for (let i=0; i < arr.length; i++) {
      if (data[arr[i]]) {
        if (i > 0) str += ", ";
        str += data[arr[i]];
      }
    }
    return str;
  };

  DataManager.NCEIoverwriteNcard = function(meta, ncard) {
    const arr = ["group","rare","sameMax","commonId","weaponType"];
    let str = this.NCEIconnectArr(ncard, arr);
    const dN5  = ncard["motion"];
    if (dN5 && dN5 !=="noSelect") {
      str += ", " + dN5;
    }
    meta.ncard = str;
  };

  DataManager.NCEIoverwriteNskill = function(meta, nskill) {
    let str = nskill["commonId"] + ", " + nskill["weaponType"];
    const dN5 = nskill["motion"]
    if (dN5 && dN5 !== "noSelect") {
      str += ", " + dN5;
    }
    meta.nskill = str;
  };

  DataManager.NCEIoverwriteExcLayout = function(meta, excLayout, pre, ow2) {
    if (!excLayout) return;
    for (const layout of excLayout) {
      if (layout.lType === "LXPic") {
        const key  = "L" + pre + "Pic" + layout.layerId;
        const file = layout.layerFile;
        const eva  = ow2 ? !meta[key] : true;
        if (file && eva) meta[key] = file;
      } else {
        this.NCEIoverwriteCtxt(meta, layout, ow2);
      }
    }
  };

  DataManager.NCEIoverwriteCtxt = function(meta, layout, ow2) {
    const type = layout.lType;
    const key  = type + layout.memoId;
    if (!(ow2 && meta[key])) {
      meta[key] = layout[type];
    }
  };

  DataManager.NCEIoverwriteNxcond = function(meta, nxcond) {
    let arr = [], mNxcond = [];
    mNxcond[0] = nxcond.xObject;
    mNxcond[1] = nxcond.xCond;
    mNxcond[2] = this.NCEIchangePercent(nxcond.xMag);
    switch(nxcond.xObject) {
      case "deck":
      case "disc":
      case "board":
      case "hand":
        arr = nxcond.xiIds;
        break;
      case "skill":
        arr = nxcond.xsIds;
        break;
      case "class":
        arr = nxcond.xcIds;
        break;
      case "member":
        arr = nxcond.xaIds;
        break;
    }
    for (let i=0; i < arr.length; i++) {
      mNxcond[3+i] = arr[i];
    }
    meta.nxcond = this.NCEIconnectElement(mNxcond)
  };

  DataManager.NCEIoverwriteIsummon = function(meta, isummon) {
    let str = isummon.actorId;
    if (isummon.motion !== "noSelect") {
      str += ", " + isummon.motion;
    }
    meta.isummon = str;
  };

  DataManager.NCEIoverwriteMPpenetrate = function(meta, mpPene, ow2) {
    if (mpPene && mpPene !== "noSelect" && !(ow2 && meta.MPpenetrate)) {
      meta.MPpenetrate = mpPene === "ON";
    }
  };

  // Scene_Boot関係（起動時にプラグインパラメータを取り込み）
  const _Scene_Boot_initialize = Scene_Boot.prototype.initialize;
  Scene_Boot.prototype.initialize = function() {
    _Scene_Boot_initialize.apply(this, arguments);
    this.NCEIinputDraft();
  };

  Scene_Boot.prototype.NLMstruct = function(param) {
    if (param && param !== "[]") {
      const str = JSON.parse(param);
      return str.map(str => JSON.parse(str));
    }
    return false;
  };

  Scene_Boot.prototype.NLMstruct2 = function(param) {
    if (param && param !== "[]") {
      return JSON.parse(param);
    }
    return false;
  };

  Scene_Boot.prototype.NCEIexcStruct = function(param) {
    if (param) {
      for (const data of param) {
        data.id = Number(data.id) || 0;
        if (!data.id) continue;
        data.cadd   = this.NLMstruct2(data.cadd);
        data.ncard  = this.NLMstruct2(data.ncard);
        data.nskill = this.NLMstruct2(data.nskill);
        data.nxcond = this.NLMstruct2(data.nxcond)
        data.excLayout = this.NLMstruct(data.excLayout);
        data.NoLayout  = this.NLMstruct2(data.NoLayout);
        if (data.operateCard) {
          const opec = this.NLMstruct2(data.operateCard);
          data.nxcond     = this.NLMstruct2(opec.nxcond);
          data.DeckUseSw  = opec.DeckUseSw;
          data.HandUseSw  = opec.HandUseSw;
          data.HandState  = opec.HandState;
          data.BoardState = opec.BoardState;
          data.nxactor    = this.NLMstruct2(opec.nxactor);
          data.mpPene     = opec.mpPene;
          data.isummon    = this.NLMstruct2(opec.isummon);
        }
        this.NCEIstructNxcond(data.nxcond);
      }
    }
  };

  Scene_Boot.prototype.NCEIstructNxcond = function(nxcond) {
    if (nxcond) {
      nxcond.xiIds = this.NLMstruct2(nxcond.xiIds);
      nxcond.xsIds = this.NLMstruct2(nxcond.xsIds);
      nxcond.xcIds = this.NLMstruct2(nxcond.xcIds);
      nxcond.xaIds = this.NLMstruct2(nxcond.xaIds);
    }
  };

  Scene_Boot.prototype.NCEIclsStruct = function(param) {
    if (param) {
      for (const data of param) {
        data.id = Number(data.id) || 0;
        if (!data.id) continue;
        data.nxcommand = this.NLMstruct2(data.nxcommand);
      }
    }
  };

  Scene_Boot.prototype.NCEIinputDraft = function() {
    const arr = DataManager._NCEIinp;
    for (let i=0; i < 7; i++) {
      NCEIdraft[i] = this.NLMstruct(NCEIparam[arr[i]]);
    }
    this.NCEIoverwriteType();
    for (let j=0; j <= 5; j++) {
      this.NCEIexcStruct(NCEIdraft[j]);
      this.NCEIadaptFile(NCEIdraft[j]);
    }
    this.NCEIclsStruct(NCEIdraft[6]);
    if (NCEIparam.backupFile === "true") {
      StorageManager.NCEIbackupFile();
    }
  };

  Scene_Boot.prototype.NCEIoverwriteType = function() {
    NCEIparam.overwrite = NCEIparam.overwrite === "プラグイン入力を優先" ? 1 :
                          NCEIparam.overwrite === "メモ欄記載を優先" ? 2 : 3;
  };

  Scene_Boot.prototype.NCEIadaptFile = function(draft) {
    if (draft) {
      for (const data of draft) {
        if (!data.id) continue;
        const file   = data.file;
        const slash  = file.indexOf("/");
        const folder = slash ? file.slice(0, slash)  : false;
        const pFile  = slash ? file.slice(slash + 1) : false;
        data.pFolder = pFile ? this.NCEIadaptFolder(folder) : false;
        data.pFile   = data.pFolder ? pFile : false;
      }
    }
  };

  Scene_Boot.prototype.NCEIadaptFolder = function(folder) {
    switch(folder) {
      case "pictures":
        return "Pic";
      case "characters":
        return "Cha";
      case "faces":
        return "Fac";
      case "enemies":
        return "Ene";
      case "sv_actors":
        return "Sva";
      case "sv_enemies":
        return "Sve";
      case "system":
        return "Sys";
      case "animations":
        return "Ani";
      case "tilesets":
        return "Til";
      default:
        return false;
    }
  };

  StorageManager.NCEIbackupFile = function() {
    const arr  = DataManager._NCEIinp;
    const dir  = this.fileDirectoryPath();
    const path = dir + "Card_";
    try {
      this.fsMkdir(dir);
      for (const inp of arr) {
        const param = NCEIparam[inp];
        if (param && param !== "[]") {
          const file = path + inp + ".txt";
          this.fsWriteFile(file, param);
        }
      }
      console.log("NLM_CardEasyInputバックアップをsaveフォルダに保存しました");
    } catch (err) {
      console.error("バックアップ保存中にエラーが発生しました:", err);
    }
  };
})();
