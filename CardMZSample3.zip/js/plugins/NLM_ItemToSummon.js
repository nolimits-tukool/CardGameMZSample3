﻿/*==========================================================================
 NLM_ItemToSummon.js
----------------------------------------------------------------------------
 (C)2025 NoLimits
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
----------------------------------------------------------------------------
 Version
 1.0.0 2025/09/07 初版
============================================================================*/

/*:
 * @target MZ MV
 * @plugindesc 召喚アイテム・プラグイン (v1.0.0)
 * @author ノリミツ (NoLimits)
 * 
 * @orderAfter NLM_CardGameMZ
 * 
 * @param summonSingularly
 * @text 一体限定召喚か
 * @desc 一体限定の召喚か（OFFの場合は同名アクター複数召喚可）　　（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param displayStatus
 * @text ステータス表示
 * @desc メニューステータスに召喚アクターを表示（デフォルト：ON）　（召喚アイテム数がゼロになると表示されなくなる）
 * @type boolean 
 * @default true
 * 
 * @param sortSummon
 * @parent displayStatus
 * @text 召喚者ソート
 * @desc 召喚アクターを追加する度にID順にソートする　　　　　　　　（デフォルト：ON）（OFFだと最後尾に追加される）
 * @type boolean
 * @default true
 * 
 * @param followerAppear
 * @parent displayStatus
 * @text フォロワー追加
 * @desc 召喚アクターをフォロワーに追加するか（デフォルト：OFF）　（ステータス表示がON時のみ）
 * @type boolean
 * @default false
 * 
 * @param noChangeOpacity
 * @parent displayStatus
 * @text 暗転化しない
 * @desc ステータスで召喚アクターを暗転化しない（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param saveChara
 * @parent displayStatus
 * @text セーブ表示
 * @desc 召喚キャラをセーブファイルに表示する（デフォルト：ON）　　（ステータス表示がON時のみ。歩行キャラ画像の入力要）
 * @type boolean
 * @default true
 * 
 * @param deckOnly
 * @parent displayStatus
 * @text デッキのみ表示
 * @desc カードゲームプラグイン併用の際、デッキに入っている時のみ、ステータス表示（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param successMessage
 * @text 召喚成功メッセージ
 * @desc 戦闘ログの召喚成功メッセージ（%1は召喚されたアクター名）　（デフォルト：%1 が 召喚された！）
 * @type string
 * @default %1 が 召喚された！
 * 
 * @param appearAnime
 * @parent successMessage
 * @text 召喚成功SVアニメ
 * @desc 召喚成功時の召喚アクターのSVアニメーション　　　　　　　　（デフォルト：51）
 * @type animation
 * @default 51
 * 
 * @param failureMessage1
 * @text 既召喚失敗メッセージ
 * @desc 一体限定召喚で既召喚時の戦闘ログメッセージ（%1は既に召喚されているアクター名）（デフォルト：%1 は 全回復した！）
 * @type string
 * @default %1 は 全回復した！
 * 
 * @param failureRecovery
 * @parent failureMessage1
 * @text 既召喚失敗時全回復
 * @desc 一体限定召喚で既召喚時に既召喚アクターの全回復を行なうか　（デフォルト：ON）（OFF時は何もしない）
 * @type boolean
 * @default true
 * 
 * @param failureAnime
 * @parent failureMessage1
 * @text 既召喚失敗SVアニメ
 * @desc 一体限定召喚で既召喚時の既召喚アクターのSVアニメーション　（デフォルト：41)（ 0 にするとアニメなし）
 * @type animation
 * @default 41
 * 
 * @param failureMessage2
 * @text 人数超過失敗メッセージ
 * @desc 戦闘メンバー超過で召喚失敗時の戦闘ログメッセージ　　　　　（デフォルト：これ以上は 召喚できない！）
 * @type string
 * @default これ以上は 召喚できない！
 * 
 * @param successVarId
 * @text 召喚成否変数ID
 * @desc 召喚成功時に「1」、既召喚後の失敗時に「-1」、人数超過の失敗時に「-2」が入る変数ID（デフォルト：19）
 * @type variable
 * @default 19
 * 
 * @param actorVarId
 * @text 召喚アクター変数ID
 * @desc 召喚の成否に関わらず召喚アクターIDが入る変数ID（デフォルト：20）（複数召喚で成功時は新たに割り振ったIDが入る)
 * @type variable
 * @default 20
 * 
 * @param vanishTime
 * @text HPゼロ消滅時間
 * @desc HPゼロになってから消滅するまでの時間（フレーム）　　　　　（デフォルト：90）
 * @type number
 * @default 90
 * 
 * @param vanishAnime
 * @parent vanishTime
 * @text HPゼロ消滅SVアニメ
 * @desc HPゼロ消滅時の召喚アクターのSVアニメーション　　　　　　　（デフォルト：54)
 * @type animation
 * @default 54
 * 
 * @param vanishEvent
 * @parent vanishTime
 * @text HPゼロ消滅後イベント
 * @desc HPゼロ消滅後に実行されるコモンイベントID　　　　　　　　　（デフォルト：なし）
 * @type common_event
 * @default 0
 * 
 * @param vanishVarId
 * @parent vanishTime
 * @text 消滅アクター変数ID
 * @desc 消滅後イベントで利用できる消滅アクターIDが入る変数ID　　　（デフォルト：なし）（複数召喚でも元アクターのIDが入る）
 * @type variable
 * @default 0
 * 
 * @param changeTargetId
 * @text (高度な設定)ターゲットID化
 * @desc 味方ターゲットをID化して処理（通常はOFFに。「ターン消費なしスキルプラグイン」併用時等のターゲットがずれる際はONに）
 * @type boolean
 * @default false
 * 
 * 
 * @help
 * 
 * 【RPGツクールMZ・MV両用プラグイン】
 * アクターを戦闘中に召喚するアイテムを作成します（下記の【要注意】あり）
 * 
 * 類似のプラグインは他にもあると思いますが、次の特長があります
 *  ① 同名アクターは 一体限定のみ召喚か、複数召喚可能か、を選択できる
 * 　 （混在は不可。また、いずれも最大戦闘メンバー数（通常4）は超えられない）
 *  ② ステータスやフォロワーに召喚アクターを表示可（召喚アイテム喪失で非表示)
 *  ③ 召喚後に戦闘終了まで生き残ると経験値が加算される
 * 
 * 召喚する「アイテム」のメモ欄に以下を記載して下さい
 * 
 * 　　　<isummon:アクターID, 召喚モーション>
 * 
 * 召喚モーションを加える際は半角カンマの後に
 *  　wait, walk, chant, guard, damage, evade, thrust, swing, missile, skill,
 *  　spell, item, escape, victory, dying, abnormal, sleep, dead　のうち一つ
 * を書いて下さい（モーション省略時は victory になります）
 * 　　　　例)　<isummon:2>　　　　<isummon:3, wait>
 * 
 * 　一体限定召喚にて既に召喚済みで同アイテムを使用した場合は「既召喚失敗」と
 * なりますが、召喚アクターを全回復(バフもデバフも初期化)させることもできます
 * 
 * 【要注意!!】
 * 　・ <isummon>で指定されたアクターはアイテムによる召喚以外では「アクターを
 * 　　加える」ことができなくなります！
 * 　　（初期パーティ・戦闘テストにも加入不可となるため、通常アクターが一人も
 * 　　存在しないと、いきなりゲームオーバーになるので注意!!）
 * 　・ 召喚アクターが生き残っていても、通常アクターが全滅なら戦闘敗北です
 * 　・ 召喚されるアクターは「並び替え」で通常アクターと入れ換えができません
 * 　・ 戦闘時以外で召喚アイテムを使用しても何も起こりません
 * 　・ 複数召喚では召喚ごとに新たなアクターIDを割り振っているので、戦闘中の
 * 　　イベントコマンド「アクター」(パーティ全体は可),「戦闘行動の強制」にて
 * 　　元のIDでの操作ができなくなります。召喚アクター変数をご利用ください
 * 　　（召喚アクター変数値が入った後で、スクリプト $gameSystem.forceActor();
 * 　　　を書き込み「戦闘行動の強制」(入力アクターは無視される）を行なえば、
 * 　　　複数召喚でも 召喚アクターの行動を強制することが可能です）
 * 　・ 召喚アイテムのダメージや使用効果は通常通り実行されるため、使用効果の
 * 　　コモンイベントにて召喚成否変数や召喚アクター変数を利用できます
 * 　・ NLM_CardGameMZ.js を併用する際は 本プラグインを「下」に配置して下さい
 * 　　　（複数召喚でも <nxcond:member> で 元アクターIDが利用できます）
 * 　・ アクターを増減する他プラグインと競合しやすい点は御了承ください
 * 
 * プラグインコマンドはありません
 * 利用規約はMITライセンスの通りです
 */

(() => {
    "use strict";

  const pluginName = "NLM_ItemToSummon";
  const NLSIparam  = PluginManager.parameters(pluginName);

  NLSIparam.appearAnime  = Number(NLSIparam.appearAnime)  || 0;
  NLSIparam.failureAnime = Number(NLSIparam.failureAnime) || 0;
  NLSIparam.vanishAnime  = Number(NLSIparam.vanishAnime)  || 0;
  NLSIparam.summonSingularly = NLSIparam.summonSingularly === "true";
  NLSIparam.displayStatus    = NLSIparam.displayStatus    === "true";
  NLSIparam.followerAppear   = NLSIparam.followerAppear   === "true"
                                && NLSIparam.displayStatus;
  NLSIparam.noChangeOpacity  = NLSIparam.noChangeOpacity  === "true"
                                && NLSIparam.displayStatus;
  NLSIparam.changeTargetId   = NLSIparam.changeTargetId   === "true";

  if (Utils.RPGMAKER_NAME === "MV") {
    Game_Temp.prototype.requestBattleRefresh = function() {
    };
    Game_System.prototype.NLSIanimation = function(battler, animeId) {
      battler.startAnimation(animeId);
    };
    Game_Party.prototype.battleMembers = function() {
      return this.allBattleMembers().filter(actor => actor.isAppeared());
    };
    Scene_Map.prototype.requestAutosave = function() {
    };
  } else { // MZの場合
    const _BattleManager_updateStart = BattleManager.updateStart;
    BattleManager.updateStart = function() {
      $gameSystem.forceActor(-2);
      this._NLSIvanishIndex = [];
      _BattleManager_updateStart.apply(this, arguments);
    };

    Game_System.prototype.NLSIanimation = function(battler, animeId) {
      $gameTemp.requestAnimation([battler], animeId);
    };
  }

  DataManager.NLSImeta = function(item) { // メモ欄の配列化
    if (this.isItem(item)) {
      const meta = item.meta["isummon"];
      if (meta) {
        const arr = meta.split(",");
        arr[0] = Number(arr[0]) || 0;
        arr[1] = arr[1] ? arr[1].replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"")
                 : "victory";
        return arr;
      }
    }
    return [0,null];
  };

  const _BattleManager_setup = BattleManager.setup;
  BattleManager.setup = function(troopId, canEscape, canLose) {
    this._NLSIvanishIndex = [];
    this.NLSImemberSetup();
    _BattleManager_setup.apply(this, arguments);
  };

  BattleManager.NLSImemberSetup = function() { // 戦闘開始時のメンバー変更処理
    this._NLSIpreMember = [];
    const preMember = $gameParty._actors;
    for (let i=0; i < preMember.length; i++) {
      this._NLSIpreMember.push(preMember[i]); // 初期メンバー配列を記憶
    }
    const noSummon = $gameParty.noSummonMembers();
    $gameParty._actors = [];
    for (let j=0; j < noSummon.length; j++) {
      $gameParty._actors.push(noSummon[j]._actorId); // 召喚メンバーを外す
    }
    this._NLSIrestore = true;
    this._NLSIactorLength = $dataActors.length;
  };

  BattleManager.NLSIrestoreMember = function() { // 戦闘終了時のメンバー変更処理
    const preMember = this._NLSIpreMember;
    $gameParty._actors = [];
    for (let i=0; i < preMember.length; i++) {
      const id    = preMember[i];
      const actor = $gameActors.actor(id);
      $gameParty._actors.push(id); // 初期メンバー配列に戻す
      if (actor.isSummon()) actor.NLSIrecover();
      if (!actor.isPreserveTp()) actor.clearTp();
    }
    if (!NLSIparam.summonSingularly) { // 複数召喚では新IDを消去
      $gameActors._data.splice(this._NLSIactorLength);
      $dataActors.splice(this._NLSIactorLength);
    }
    if (NLSIparam.displayStatus) {
      $gameParty.NLSIsummonItemCheck(); // 戦闘中のアイテム増減を清算
    }
    $gamePlayer.refresh(); // 戦闘中のfollower変化を一新
  };

  const _BattleManager_startInput = BattleManager.startInput;
  BattleManager.startInput = function() {
    $gameSystem.forceActor(-2);
    this._NLSIvanishIndex = [];
    _BattleManager_startInput.apply(this, arguments);
  };

  const _BM_selectNextCommand = BattleManager.selectNextCommand;
  BattleManager.selectNextCommand = function() {
    _BM_selectNextCommand.apply(this, arguments);
    this._NLSIvanishIndex = [];
  };

  const _BattleManager_gainExp = BattleManager.gainExp;
  BattleManager.gainExp = function() {
    if (NLSIparam.summonSingularly) {
      _BattleManager_gainExp.apply(this, arguments);
    } else {
      this.NLSIgainExp();
    }
  };

  BattleManager.NLSIgainExp = function() { // 複数召喚の場合の経験値取得
    const exp = this._rewards.exp;
    let summonIds = [];
    for (const actor of $gameParty.noSummonMembers()) {
      actor.gainExp(exp); // 非召喚者はそのまま加える
    }
    for (const sActor of $gameParty.summonMembers()) {
      const oldId = sActor._NLSIoldId;
      if (!summonIds.includes(oldId)) { // 召喚者は真IDで経験値を加える
        $gameActors.actor(oldId).gainExp(exp);
        summonIds.push(oldId);
      }
    }
  };

  const _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function() {
    _Game_System_initialize.apply(this, arguments);
    this._isNLMitemToSummon = true;
    this._NLSIforceActor = 0;
  };

  Game_System.prototype.forceActor = function(id) { // アクターID強制指定を伝達（独自関数）
    if (!id) this._NLSIforceActor = $gameVariables.value(NLSIparam.actorVarId);
    if (id === -1) return this._NLSIforceActor;
    if (id === -2)        this._NLSIforceActor = 0;
    if (id && id !== -2)  this._NLSIforceActor = id;
  };

  const _Game_Action_makeTargets = Game_Action.prototype.makeTargets;
  Game_Action.prototype.makeTargets = function() {
    if (!NLSIparam.changeTargetId) {
      const tIndex  = this._targetIndex;
      const indexes = BattleManager._NLSIvanishIndex;
      if (this.subject().isActor() && this.isForFriend() && this.isForOne()
          && tIndex > 0 && indexes.length) {
        for (const index of indexes) {
          if (tIndex > index) {
            this._targetIndex -= 1; // 消滅したアクター分、対象を一つ前へずらす
          }
        }
      }
    }
    const rTargets = _Game_Action_makeTargets.apply(this, arguments);
    const meta = DataManager.NLSImeta(this.item());
    return !rTargets.length && meta[0] ? [this.subject()] : rTargets; // 「範囲：なし」時の対応
  };

  const _Game_Action_apply = Game_Action.prototype.apply 
  Game_Action.prototype.apply = function(target) {
    this.NLSIapplyItem();
    _Game_Action_apply.apply(this, arguments);
  };

  Game_Action.prototype.NLSIapplyItem = function() { // 召喚アイテムを使用した時の処理
    const meta = DataManager.NLSImeta(this.item());
    const actorId = meta[0];
    const actor = actorId ? $gameActors.actor(actorId) : null;
    if (actor && $gameParty.inBattle()) {
      BattleManager._NLSIactor = actorId;
      $gameVariables.setValue(NLSIparam.actorVarId, actorId);
      const singul  = NLSIparam.summonSingularly || !actor.isSummon();
      const include = $gameParty.battleMembers().includes(actor);
      const varId   = NLSIparam.successVarId;
      if (singul && include) { // すでに召喚済みの場合
        if (NLSIparam.failureRecovery === "true") actor.NLSIrecover();
        $gameSystem.NLSIanimation(actor, NLSIparam.failureAnime);
        $gameVariables.setValue(varId, -1);
        BattleManager._NLSIsummon = -1;
      } else if (!actor.isSummon()) {
        BattleManager._NLSIactor = 0;
        $gameVariables.setValue(varId, 0);
      } else if ($gameParty.size() >= $gameParty.maxBattleMembers()) { // 戦闘メンバー超過
        $gameVariables.setValue(varId, -2);
        BattleManager._NLSIsummon = -2;
      } else { // 召喚アクターを出現させる
        actor.NLSIrecover();
        $gameParty.addActor(actorId, true);
        $gameVariables.setValue(varId, 1);
        BattleManager._NLSIsummon = 1;
        BattleManager._NLSImotion = meta[1];
      }
    }
  };

  Game_BattlerBase.prototype.isSummon = function() {
    return this._NLSIsummon;
  };

  const _Game_Actor_setup = Game_Actor.prototype.setup;
  Game_Actor.prototype.setup = function(actorId) {
    _Game_Actor_setup.apply(this, arguments);
    this.NLSIwriteSummon(actorId);
  };

  Game_Actor.prototype.NLSIwriteSummon = function(actorId) {
    const item = $dataItems;
    for (let i=1; i < item.length; i++) {
      const meta = DataManager.NLSImeta(item[i]);
      if (meta[0] === actorId) {
        this._NLSIsummon = true; // 召喚アクターを刻む
        break;
      }
    }
  };

  Game_Actor.prototype.NLSIrecover = function() { // 召喚アクターの全回復
    this.recoverAll();
  };

  const _GA_finalExpRate = Game_Actor.prototype.finalExpRate;
  Game_Actor.prototype.finalExpRate = function() { // 複数召喚の際はベンチでも経験値獲得
    const sing = this.isSummon() && !NLSIparam.summonSingularly;
    return sing ? this.exr : _GA_finalExpRate.call(this);
  };

  const _GA_performCollapse = Game_Actor.prototype.performCollapse;
  Game_Actor.prototype.performCollapse = function() { // サイドビュー時は消滅音なし
    if (this.isSummon() && NLSIparam.vanishAnime && $gameSystem.isSideView()) {
      Game_Battler.prototype.performCollapse.call(this);
    } else {
      _GA_performCollapse.call(this);
    }
  };

  Game_Party.prototype.eraseSummon = function(id) { // 召喚アクターを通常アクター化（隠し）
    const actor = $gameActors.actor(id);
    if (!this.inBattle() && actor) {
      actor._NLSIsummon = false;
      if (this.members().includes(actor)) {
        this.NLSIsortMembers();
        $gamePlayer.refresh();
      }
    }
  };

  Game_Party.prototype.writeSummon = function(id) { // 通常アクターを召喚アクター化（隠し）
    const actor = $gameActors.actor(id);
    if (!this.inBattle() && actor) {
      actor._NLSIsummon = true;
      if (this.members().includes(actor)) {
        this.NLSIsummonItemCheck();
        $gamePlayer.refresh();
      }
    }
  };

  Game_Party.prototype.isAllDead = function() { // 全員死亡判定は召喚アクターを除く
    return this.aliveNoSummonMembers().length === 0;
  };

  Game_Party.prototype.aliveNoSummonMembers = function() {
    return this.members().filter(member => member.isAlive() && !member.isSummon());
  };

  Game_Party.prototype.summonMembers = function() {
    return this.allMembers().filter(actor => actor.isSummon());
  };

  Game_Party.prototype.noSummonMembers = function() {
    return this.allMembers().filter(actor => !actor.isSummon());
  };

  Game_Party.prototype.NLSIsaveBattleMembers = function() {
    return this.allBattleMembers(true).slice(0, this.maxBattleMembers());
  };

  Game_Party.prototype.allBattleMembers = function(tr) { // 書き換え
    const noSummon4 = this.noSummonMembers().slice(0, this.maxBattleMembers());
    if (this.inBattle() || NLSIparam.noChangeOpacity || tr) {
      return noSummon4.concat(this.summonMembers());
    } else {
      return noSummon4;
    }
  };

  Game_Party.prototype.NLSIfollowerMembers = function() {
    const member = NLSIparam.followerAppear ? this.allMembers() : this.noSummonMembers();
    return member.slice(0, this.maxBattleMembers());
  };

  const _Game_Party_gainItem = Game_Party.prototype.gainItem; // アイテムの増減に処理追加
  Game_Party.prototype.gainItem = function(item, amount, includeEquip) {
    _Game_Party_gainItem.apply(this, arguments); 
    if (DataManager.isItem(item) && !this.inBattle() && NLSIparam.displayStatus) {
      this.NLSIsummonItemCheck();
    }
  };

  Game_Party.prototype.NLSIsummonItemCheck = function() { // アイテム増減による召喚アクター増減
    const plugin   = $gameSystem._isNLMcardGame;
    const deckOnly = plugin && NLSIparam.deckOnly === "true";
    const item   = $dataItems;
    const length = (item.length - 1) * (plugin ? 0.4 : 1);
    for (let j=1; j < $dataActors.length; j++) {
      let lost = false;
      for (let i=1; i <= length; i++) {
        const meta = DataManager.NLSImeta(item[i]);
        if (j === meta[0]) {
          const actor = $gameActors.actor(j);
          const incl  = this.members().includes(actor);
          const eva = deckOnly ? item[i].itypeId === 5 : true;
          if (!incl && actor.isSummon() && this.hasItem(item[i]) && eva) {
            this.addActor(j, true); // 召喚アイテム獲得でアクターを加える
            lost = false;
            break;
          }
          if (incl && actor.isSummon()) {
            if (this.hasItem(item[i]) && eva) {
              lost = false; // 他の召喚アイテムを持ってたらアクター消失しない
              break;
            } else {
              lost = true;
            }
          }
        }
      }
　　　if (lost) this.removeActor(j); // 召喚アイテム全消失でアクターを外す
    }
  };

  const _GP_setupStartingMembers = Game_Party.prototype.setupStartingMembers;
  Game_Party.prototype.setupStartingMembers = function() { // 初期メンバーチェック
    _GP_setupStartingMembers.apply(this, arguments);
    this.NLSIsummonItemCheck();
  };

  const _Game_Party_addActor = Game_Party.prototype.addActor;
  Game_Party.prototype.addActor = function(actorId, forced) { // アクターを加える処理変更
    const noSummon = !$gameActors.actor(actorId).isSummon();
    if (noSummon || forced) {
      if (noSummon || NLSIparam.summonSingularly || !this.inBattle()) {
        _Game_Party_addActor.apply(this, arguments);
        this.NLSIsortMembers();
      } else {
        this.NLSIaddActor(actorId);
      }
    }
  };

  Game_Party.prototype.NLSIaddActor = function(actorId) { // 召喚アクターを複数召喚
    const newId = $dataActors.length;
    $dataActors.push($dataActors[actorId]);
    $dataActors[newId].id = newId; // 新たなアクターIDを与える
    const actor = $gameActors.actor(newId);
    for (const [key, value] of Object.entries($gameActors.actor(actorId))) {
      actor[key] = value; // 元アクターのデータ(Lvなど)をコピー
    }
    actor._actorId   = newId;
    actor._NLSIoldId = actorId;
    this._actors.push(newId);
    $gameVariables.setValue(NLSIparam.actorVarId, newId);
    $gameTemp.requestBattleRefresh();
    actor.onBattleStart();
  };

  Game_Party.prototype.NLSIsortMembers = function() { // アクター並び替え
    if (!this.inBattle()) {
      const noSummons = this.noSummonMembers();
      const summons   = this.summonMembers();
      let noSummonActors = [];
      let summonActors   = [];
      for (let i=0; i < noSummons.length; i++) {
        noSummonActors.push(noSummons[i]._actorId);
      }
      for (let j=0; j < summons.length; j++) {
        summonActors.push(summons[j]._actorId);
      }
      if (NLSIparam.sortSummon === "true") {
        summonActors.sort(function(a, b){return a - b;});
      }
      this._actors = noSummonActors.concat(summonActors);
      $gamePlayer.refresh();
    }
  };

  if (NLSIparam.displayStatus && NLSIparam.saveChara === "true") { // セーブでキャラ表示
    Game_Party.prototype.charactersForSavefile = function() {
      return this.NLSIsaveBattleMembers().map(actor => [
        actor.characterName(),
        actor.characterIndex()
      ]);
    };

    Game_Party.prototype.facesForSavefile = function() {
      return this.NLSIsaveBattleMembers().map(actor => [
        actor.faceName(),
        actor.faceIndex()
      ]);
    };
  }

  if (NLSIparam.followerAppear || NLSIparam.noChangeOpacity) {
    Game_Follower.prototype.actor = function() { // 書き換え
      return $gameParty.NLSIfollowerMembers()[this._memberIndex];
    };
  }

  const _GI_iterateActorId = Game_Interpreter.prototype.iterateActorId;
  Game_Interpreter.prototype.iterateActorId = function(param, callback) {
    const id = parseInt($gameSystem.forceActor(-1)) || 0;
    if (id) {
      const actor = $gameActors.actor(id); // アクターID強制指定を実行
      if (actor) callback(actor);
    } else {
      _GI_iterateActorId.apply(this, arguments);
    }
    $gameSystem.forceActor(-2);
  };

  const _Scene_Map_update = Scene_Map.prototype.update;
  Scene_Map.prototype.update = function() { // 戦闘リザルトで召喚者を描画させないために遅れて実行
    _Scene_Map_update.apply(this, arguments);
    if (BattleManager._NLSIrestore && !SceneManager.isSceneChanging()) {
      BattleManager.NLSIrestoreMember();
      BattleManager._NLSIrestore = false;
      if (!$gameSystem._isNLMcardGame) this.requestAutosave(); // オートセーブのタイミング変更
    }
  };

  const _Scene_Menu_onFormationOk = Scene_Menu.prototype.onFormationOk;
  Scene_Menu.prototype.onFormationOk = function() { // 並び替えコマンド変更
    const index = this._statusWindow.index();
    const pendingIndex = this._statusWindow.pendingIndex();
    if (pendingIndex >= 0) { // 召喚キャラと非召喚キャラは並び替えできないように
      const iActor = $gameParty.members()[index];
      const pActor = $gameParty.members()[pendingIndex];
      if (iActor.isSummon() && !pActor.isSummon() || !iActor.isSummon() && pActor.isSummon()) {
        SoundManager.playBuzzer();
        this._statusWindow.activate();
        return;
      }
    }
    _Scene_Menu_onFormationOk.apply(this, arguments);
  };

  const _SIB_showActorWindow = Scene_ItemBase.prototype.showActorWindow;
  Scene_ItemBase.prototype.showActorWindow = function() {
    this._actorWindow.refresh(); // アイテム増減によるアクター増減を考慮
    _SIB_showActorWindow.apply(this, arguments);
  };

  Scene_Battle.prototype.shouldAutosave = function() { // オートセーブのタイミングを強制変更
    return false;
  };

  const _WBL_displayActionResults = Window_BattleLog.prototype.displayActionResults
  Window_BattleLog.prototype.displayActionResults = function(subject, target) {
    _WBL_displayActionResults.apply(this, arguments);
    this.NLSIdisplaySummonResult();
  };

  Window_BattleLog.prototype.NLSIdisplaySummonResult = function() { // 召喚時の戦闘ログを表示
    const bActor = BattleManager._NLSIactor;
    if (bActor) {
      const name = $gameActors.actor(bActor).name();
      const bSum = BattleManager._NLSIsummon;
      const mess = bSum ===  1 ? NLSIparam.successMessage  :
                   bSum === -1 ? NLSIparam.failureMessage1 :
                   NLSIparam.failureMessage2;
      this.push("addText", mess.format(name));
      if (bSum === 1) this.push("wait");
      BattleManager._NLSIactor  = 0;
      BattleManager._NLSIsummon = 0;
    }
  };

  const _WBL_displayFailure = Window_BattleLog.prototype.displayFailure;
  Window_BattleLog.prototype.displayFailure = function(target) { // 「効かなかった」を表示させない
    if (!BattleManager._NLSIactor) _WBL_displayFailure.apply(this, arguments);
  };

  const _WBL_displayAddedStates = Window_BattleLog.prototype.displayAddedStates;
  Window_BattleLog.prototype.displayAddedStates = function(target) { // ステータスウインドウ消滅の時間稼ぎ
    const states = target.result().addedStateObjects();
    for (const state of states) {
      if (state.id === target.deathStateId() && target.isSummon()) {
        this._waitCount = Number(NLSIparam.vanishTime) || 0; // ステータスが消えるまでの時間
        this._NLSIwait  = target._actorId;
      }
    }
    _WBL_displayAddedStates.apply(this, arguments);
  };

  const _WBL_updateWait = Window_BattleLog.prototype.updateWait;
  Window_BattleLog.prototype.updateWait = function() {
    if (this._NLSIwait) {
      if (this._waitCount > 0) {
        this._waitCount--;
        return false;
      } else { // 召喚アクター消滅処理
        this._waitCount = 0;
        this.NLSIvanishActor(this._NLSIwait);
        return true;
      }
    }else {
      return _WBL_updateWait.apply(this, arguments);
    }
  };

  Window_BattleLog.prototype.NLSIvanishActor = function(NLSIwait) {
    const actor = $gameActors.actor(NLSIwait);
    const index = $gameParty.members().indexOf(actor);
    BattleManager._NLSIvanishIndex.push(index);
    $gameParty.removeActor(NLSIwait); // 召喚アクター退場
    SceneManager._scene._statusWindow.refresh(); // ステータスウインドウからも消滅
    $gameTemp.reserveCommonEvent(NLSIparam.vanishEvent); // 消滅イベント
    const actorId = NLSIparam.summonSingularly ? NLSIwait : actor._NLSIoldId;
    $gameVariables.setValue(NLSIparam.vanishVarId, actorId);
    this._NLSIwait = 0;
  };

  const _Window_BattleLog_wait = Window_BattleLog.prototype.wait;
  Window_BattleLog.prototype.wait = function() { // 強制上書き阻止
    if (!this._NLSIwait) _Window_BattleLog_wait.apply(this, arguments);
  };

  const _SA_setActorHome = Sprite_Actor.prototype.setActorHome;
  Sprite_Actor.prototype.setActorHome = function(index) {
    this._offsetX = 0; // 消滅時に下アクターのホーム位置ずれを防ぐ
    this._offsetY = 0;
    _SA_setActorHome.apply(this, arguments);
  };

  const _SA_updateShadow = Sprite_Actor.prototype.updateShadow;
  Sprite_Actor.prototype.updateShadow = function() {
    if (this._NLSIshadowVanish) { // 消滅時に一瞬出現する影を出さない
      this._shadowSprite.visible = false;
    } else {
      _SA_updateShadow.apply(this, arguments);
    }
  };

  const _SA_startEntryMotion = Sprite_Actor.prototype.startEntryMotion;
  Sprite_Actor.prototype.startEntryMotion = function() {
    const bM = BattleManager._NLSImotion;
    if (bM) { // 召喚時アニメとモーション設定
      this._NLSIappear = true;
      this.opacity = 0;
      this.startMotion(bM);
      this.startMove(0, 0, 0);
      $gameSystem.NLSIanimation(this._actor, NLSIparam.appearAnime);
      BattleManager._NLSImotion = null;
    } else {
      _SA_startEntryMotion.apply(this, arguments);
      this.opacity = 255;
    }
    this._NLSIvanish       = false;
    this._NLSIshadowVanish = false;
  };

  const _SA_updateMotion = Sprite_Actor.prototype.updateMotion;
  Sprite_Actor.prototype.updateMotion = function() {
    this.NLSIupdateOpacity();
    _SA_updateMotion.apply(this, arguments);
  };

  Sprite_Actor.prototype.NLSIupdateOpacity = function() { // モーション不透明度の経時変化
    const actor = this._actor;
    if (actor && actor.stateMotionIndex() === 3 && actor.isSummon()) {
      if (!this._NLSIvanish) {
        $gameSystem.NLSIanimation(actor, NLSIparam.vanishAnime);
        this._NLSIvanish = true;
      } else if (this.opacity > 0) {
        this.opacity -= 5; // 徐々にSV消滅
      } else if (this.opacity <= 0) {
        this._NLSIshadowVanish = true;
      }
    }
    if (this._NLSIappear) {
      if (this.opacity < 255) {
        this.opacity += 3; // 徐々にSV出現
      } else {
        this._NLSIappear = false;
        actor.setActionState("waiting");
      }
    }
  };

  // 味方ターゲットをID化して処理（ターン消費なしスキルプラグイン等で味方ターゲットがずれるため。改変多め）
  if (NLSIparam.changeTargetId) {
    const _Game_Action_clear = Game_Action.prototype.clear;
    Game_Action.prototype.clear = function() {
      _Game_Action_clear.apply(this, arguments);
      this._NLSItargetId = 0;
    };

    const _Game_Action_setTarget = Game_Action.prototype.setTarget;
    Game_Action.prototype.setTarget = function(targetIndex, targetId) {
      _Game_Action_setTarget.apply(this, arguments);
      if (targetId) {
        this._NLSItargetId = targetId;
      }
    };

    Game_Action.prototype.decideRandomTarget = function() {
      let target;
      if (this.isForDeadFriend()) {
        target = this.friendsUnit().randomDeadTarget();
      } else if (this.isForFriend()) {
        target = this.friendsUnit().randomTarget();
      } else {
        target = this.opponentsUnit().randomTarget();
      }
      if (target) {
        this._targetIndex = target.index();
        if (target.isActor()) {
          this._NLSItargetId = target.actorId();
        }
      } else {
        this.clear();
      }
    };

    if (Utils.RPGMAKER_NAME === "MV") {
      Game_Action.prototype.targetsForOpponents = function() {
        let targets = [];
        let unit = this.opponentsUnit();
        if (this.isForRandom()) {
          for (var i = 0; i < this.numTargets(); i++) {
            targets.push(unit.randomTarget());
          }
        } else if (this.isForOne()) {
          if (this._targetIndex < 0) {
            targets.push(unit.randomTarget());
          } else {
            targets.push(unit.smoothTarget(this._targetIndex, this._NLSItargetId));
          }
        } else {
          targets = unit.aliveMembers();
        }
        return targets;
      };

      Game_Action.prototype.targetsForFriends = function() {
        let targets = [];
        let unit = this.friendsUnit();
        if (this.isForUser()) {
          return [this.subject()];
        } else if (this.isForDeadFriend()) {
          if (this.isForOne()) {
            targets.push(unit.smoothDeadTarget(this._targetIndex, this._NLSItargetId));
          } else {
            targets = unit.deadMembers();
          }
        } else if (this.isForOne()) {
          if (this._targetIndex < 0) {
            targets.push(unit.randomTarget());
          } else {
            targets.push(unit.smoothTarget(this._targetIndex, this._NLSItargetId));
          }
        } else {
          targets = unit.aliveMembers();
        }
        return targets;
      };
    } else { // MZの場合
      const _GA_targetsForDead = Game_Action.prototype.targetsForDead;
      Game_Action.prototype.targetsForDead = function(unit) {
        if (this.isForOne() && this._NLSItargetId) {
          return [unit.smoothDeadTarget(this._targetIndex, this._NLSItargetId)];
        } else {
          return _GA_targetsForDead.call(this, unit);
        }
      };

      const _GA_targetForAlive = Game_Action.prototype.targetsForAlive;
      Game_Action.prototype.targetsForAlive = function(unit) {
        if (this.isForOne() && this._targetIndex > 0) {
          return [unit.smoothTarget(this._targetIndex, this._NLSItargetId)];
        } else {
          return _GA_targetForAlive.call(this, unit);
        }
      };

      const _GA_targetForDeadAndAlive = Game_Action.prototype.targetsForDeadAndAlive;
      Game_Action.prototype.targetsForDeadAndAlive = function(unit) {
        const actor = this._NLSItargetId ? $gameActors.actor(this._NLSItargetId) : null;
        if (this.isForOne() && this.subject().isActor()
            && actor && $gameParty.members().includes(actor)) {
          return [actor];
        } else {
          return _GA_targetForDeadAndAlive.call(this, unit);
        }
      };
    }

    Game_Action.prototype.evaluate = function() {
      let value = 0;
      for (const target of this.itemTargetCandidates()) {
        const targetValue = this.evaluateWithTarget(target);
        if (this.isForAll()) {
          value += targetValue;
        } else if (targetValue > value) {
          value = targetValue;
          this._targetIndex = target.index();
          if (target.isActor()) {
            this._NLSItargetId = target.actorId();
          }
        }
      }
      value *= this.numRepeats();
      if (value > 0) {
        value += Math.random();
      }
      return value;
    };

    const _GU_smoothTarget = Game_Unit.prototype.smoothTarget;
    Game_Unit.prototype.smoothTarget = function(index, targetId) {
      if (targetId) {
        const member = $gameActors.actor(targetId);
        return member && member.isAlive() ? member : this.aliveMembers()[0];
      } else {
        return _GU_smoothTarget.call(this, index);
      }
    };

    const _GU_smoothDeadTarget = Game_Unit.prototype.smoothDeadTarget;
    Game_Unit.prototype.smoothDeadTarget = function(index, targetId) {
      if (targetId) {
        const member = $gameActors.actor(targetId);
        return member && member.isDead() ? member : this.deadMembers()[0];
      } else {
        return _GU_smoothDeadTarget.call(this, index);
      }
    };

    Scene_Battle.prototype.onActorOk = function() {
      const index = this._actorWindow.index();
      const targetId = $gameParty.members()[index].actorId();
      const action = BattleManager.inputtingAction();
      action.setTarget(index, targetId);
      if (Utils.RPGMAKER_NAME === "MZ") this.hideSubInputWindows();
      this._actorWindow.hide();
      this._skillWindow.hide();
      this._itemWindow.hide();
      this.selectNextCommand();
    };
  }
})();
