﻿/*==========================================================================
 NLM_CardGameMZ.js
----------------------------------------------------------------------------
 (C)2025 NoLimits
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
----------------------------------------------------------------------------
 Version
 1.0.0 2025/09/17 初版
 1.1.0 2025/10/03 Window処理の軽量化
 1.1.1 2025/10/19 アイテムID最終番で戦闘後に数が合わないのを修正
============================================================================*/

/*:
 * @target MZ
 * @plugindesc MZ用カードゲーム・プラグイン (v1.1.1)
 * @author ノリミツ (NoLimits)
 * 
 * @command addDeck
 * @text デッキに加える
 * @desc 指定したカードをまとめてデッキに加える（非戦闘時用）
 * 
 * @arg items
 * @text デッキに加えるカード
 * @desc デッキに加えるカードのIDと枚数
 * @type struct<Card>[]
 * @default []
 * 
 * @arg onlyOffDeck
 * @text デッキ外に持つ場合のみ
 * @desc デッキ外に持つ場合のみ加える（OFFの場合は強制的に加える）
 * @type boolean
 * @default false
 * 
 * @arg overCheck
 * @text デッキ超過チェック
 * @desc デッキ超過（同一最大数・デッキ最大数）のチェックを行なう　（超過した場合はデッキ外へ外す）
 * @type boolean
 * @default true
 * 
 * @command removeDeck
 * @text デッキから外す
 * @desc 指定したカードをまとめてデッキから外す（非戦闘時用）　　　（デッキ総数が減少するので注意）
 * 
 * @arg items
 * @type struct<Card>[]
 * @text デッキから外すカード
 * @desc デッキから外すカードのIDと枚数
 * @default []
 * 
 * @arg forcedDelete
 * @text 強制的に削除
 * @desc 外したカードを強制的に削除（OFFの場合はデッキ外へ移動）
 * @type boolean
 * @default true
 * 
 * @command moveCard
 * @text カードを移動
 * @desc カード種間で1枚ずつカードを移動（戦闘中で使いやすいが、使用直前イベント内だとエラーを誘発しやすいので使用効果で利用を推奨）
 * 
 * @arg fromItype
 * @text 移動元
 * @desc 移動元のカード種（手札・捨札・場札は、戦闘終了後は 0枚 になっているので注意）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @default 山札(デッキ)
 * 
 * @arg toItype
 * @text 移動先
 * @desc 移動先のカード種（手札・捨札・場札は、非戦闘時はメニューで確認できないので注意）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @default 山札(デッキ)
 * 
 * @arg itemId
 * @text カードID
 * @desc 移動させるカードID（必ず「通常アイテム」を指定すること！）（下記変数IDを指定すると、入力値は無効となる）
 * @type item
 * @default 0
 * 
 * @arg idVariable
 * @text カードIDの変数ID
 * @desc カードIDを「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc 移動カードのピクチャをプラグインパラメータで設定したピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command allMoveCard
 * @text カードを全移動(全削除)
 * @desc 移動元のカード種を移動先へ全て合算する（移動元のカード種は 0枚 になる。捨札を山札へ全移動、デッキをデッキ外へ全移動等で利用)
 * 
 * @arg fromItype
 * @text 移動元
 * @desc 移動元のカード種（デッキ外が移動元だと影響大きいので注意）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @default 捨札
 * 
 * @arg toItype
 * @text 移動先
 * @desc 移動先のカード種（「全削除」を選択すると移動元カード種が　強制的に全削除されるので注意）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @option 全削除
 * @default 山札(デッキ)
 * 
 * @arg shuffleSE
 * @text シャッフル時SEを演奏
 * @desc プラグインパラメータで設定した「シャッフル時SE」を演奏する
 * @type boolean
 * @default false
 * 
 * @command gainCard
 * @text カードを増加
 * @desc カードを強制的に増加させる（デッキ最大数や最大手札数は無視）
 * 
 * @arg iType
 * @text カード種
 * @desc 増加させるカード種　　　　　　　　　　　　　　　　　　　　（デッキ外はイベントコマンド「アイテムの増減」でも代用可）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @default 山札(デッキ)
 * 
 * @arg itemId
 * @text カードID
 * @desc 増加させるカードID　　　　　　　　　　　　　　　　　　　　（下記変数IDを指定すると、入力値は無効となる）
 * @type item
 * @default 0
 * 
 * @arg idVariable
 * @text カードIDの変数ID
 * @desc カードIDを「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg num
 * @text 枚数
 * @desc 増加させる枚数（下記変数IDを指定すると 入力値は無効となる)
 * @type number
 * @min -99
 * @default 1
 *
 * @arg numVariable
 * @text 枚数の変数ID
 * @desc 枚数を「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc 増加するカードのピクチャをプラグインパラメータで設定したピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command loseCard
 * @text カードを減少
 * @desc カードを強制的に減少させる（デッキ最小数は無視。減少後の枚数結果はマイナス値にはならない）
 * 
 * @arg iType
 * @text カード種
 * @desc 減少させるカード種　　　　　　　　　　　　　　　　　　　　（デッキ外はイベントコマンド「アイテムの増減」でも代用可）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @default 山札(デッキ)
 * 
 * @arg itemId
 * @text カードID
 * @desc 減少させるカードID　　　　　　　　　　　　　　　　　　　　（下記変数IDを指定すると、入力値は無効となる）
 * @type item
 * @default 0
 * 
 * @arg idVariable
 * @text カードIDの変数ID
 * @desc カードIDを「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg num
 * @text 枚数
 * @desc 減少させる枚数（下記変数IDを指定すると 入力値は無効)
 * @type number
 * @min -99
 * @default 1
 *
 * @arg numVariable
 * @text 枚数の変数ID
 * @desc 枚数を「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc 減少するカードのピクチャをプラグインパラメータで設定したピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command deckOverCheck
 * @text デッキ超過チェック
 * @desc デッキ超過（同一最大数・デッキ最大数）のチェックを行なう　　　（非戦闘時専用。超過した場合はデッキ外へ外す）
 * 
 * @command selectCard
 * @text カード選択(この後 アイテム選択の処理を)
 * @desc このプラグインコマンド後(必要なら「文章表示」後)イベントコマンド「アイテム選択の処理」で変数IDを入力(アイテムタイプは無視)
 * 
 * @arg iType
 * @text 選択されるカード種
 * @desc 選択されるカード種
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @option 大事なもの
 * @option 隠しアイテムA
 * @option 隠しアイテムB
 * @default 山札(デッキ)
 * 
 * @arg matchCondition
 * @text 条件合致カードのみ抽出
 * @desc 条件に合致するカードのみ抽出して選択させるか
 * @type select
 * @option 条件なく全て対象
 * @value all
 * @option 同じアイコンID
 * @value icon
 * @option 同じダメージ属性ID（通常攻撃：-1、なし：0)
 * @value element
 * @option 同じグループ番号
 * @value group
 * @option 同じレア値
 * @value rare
 * @option スクリプト式がtrue（上級者向け）
 * @value script
 * @default all
 * 
 * @arg elementId
 * @parent matchCondition
 * @text 条件合致番号値
 * @desc 上記で抽出して選択させるIDや番号の値　　　　　　　　　　　（下記変数IDを指定すると 入力値は無効)
 * @type number
 * @min -1
 * @default 0
 * 
 * @arg eIdVariable
 * @parent matchCondition
 * @text 条件合致番号の変数ID
 * @desc 抽出して選択させるIDや番号を入れる変数ID
 * @type variable
 * @default 0
 * 
 * @arg script
 * @parent matchCondition
 * @text スクリプト(上級者向け)
 * @desc スクリプト式がtrue用（カードIDはcId, $dataItems[cId]はitemで置換。条件合致番号無効。例) item.meta["ctxt1"]==="召喚"
 * @type multiline_string
 * 
 * @arg centering
 * @text 中央寄せ表示
 * @desc カードを中央寄せ表示にするか（OFF時は通常ウインドウ表示）
 * @type boolean
 * @default false
 * 
 * @arg numDisp
 * @text 個数表示
 * @desc 選択されるカード種の個数表示をするか　　　　　　　　　　　（OFF時は個数表示がない代わりに個数分のアイテムが並ぶ）
 * @type boolean
 * @default false
 * 
 * @arg disable
 * @text 使用不可を選択不可
 * @desc メンバーの誰も使用不可時は選択不可にする（TP・MPコスト、使用可能時、<HandUseSw>、<nxactor>が制約となる）
 * @type select
 * @option すべて選択可
 * @option 選択不可（TP･MPコストを除く）
 * @option 選択不可（TP･MPコストを含め）
 * @default すべて選択可
 * 
 * @arg cancel
 * @text キャンセル入力
 * @desc 選択時にキャンセルを入力できるか
 * @type boolean
 * @default true
 * 
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc 選択したカードのピクチャをプラグインパラメータで設定した　ピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command randomCard
 * @text ランダムにカード抽出
 * @desc 所持している指定カード種からランダムにカードを1枚抽出し、その結果のアイテムIDを指定した変数(および該当カードID変数)に格納する
 * 
 * @arg iType
 * @text 抽出されるカード種
 * @desc 抽出されるカード種
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @option デッキ外
 * @option 大事なもの
 * @option 隠しアイテムA
 * @option 隠しアイテムB
 * @default 山札(デッキ)
 * 
 * @arg matchCondition
 * @text 条件合致カードのみ抽出
 * @desc 条件に合致するカードのみ抽出して選択させるか
 * @type select
 * @option 条件なく全て対象
 * @value all
 * @option 同じアイコンID
 * @value icon
 * @option 同じダメージ属性ID（通常攻撃：-1、なし：0)
 * @value element
 * @option 同じグループ番号
 * @value group
 * @option 同じレア値
 * @value rare
 * @option スクリプト式がtrue（上級者向け）
 * @value script
 * @default all
 * 
 * @arg elementId
 * @parent matchCondition
 * @text 条件合致番号値
 * @desc 上記で抽出して選択させるIDや番号の値　　　　　　　　　　　（下記変数IDを指定すると 入力値は無効)
 * @type number
 * @min -1
 * @default 0
 * 
 * @arg eIdVariable
 * @parent matchCondition
 * @text 条件合致番号の変数ID
 * @desc 抽出して選択させるIDや番号を入れる変数ID
 * @type variable
 * @default 0
 * 
 * @arg script
 * @parent matchCondition
 * @text スクリプト(上級者向け)
 * @desc スクリプト式がtrue用（カードIDはcId, $dataItems[cId]はitemで置換。条件合致番号無効。例) item.meta["ctxt1"]==="召喚"
 * @type multiline_string
 * 
 * @arg varId
 * @text 結果を格納する変数ID
 * @desc 抽出した結果のカードIDを格納する変数ID　　　　　　　　　　（該当カードID変数にも同じ値が入ります）
 * @type variable
 * @default 0
 *
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc 抽出カードのピクチャをプラグインパラメータで設定したピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command predictDraw
 * @text 次ドロー予定カード
 * @desc 次ドロー予定カードIDを以下の値に強制指定(山札に存在する時のみ) あるいはIDがゼロ時は次ドロー予定IDを該当カードID変数に代入
 * 
 * @arg itemId
 * @text カードID
 * @desc 次ドロー予定カードID（必ず「通常アイテム」を指定すること!) （下記変数IDを指定すると、入力値は無効となる）
 * @type item
 * @default 0
 * 
 * @arg idVariable
 * @text カードIDの変数ID
 * @desc 次にドローするカードIDを「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc 次ドロー予定カードのピクチャをプラグインパラメータで設定したピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command gacha
 * @text カードガチャ
 * @desc 抽選にてカードを獲得する（ガチャ演出や割り込みコモンイベントはプラグインパラメータで設定する）
 * 
 * @arg times
 * @text 回数
 * @desc ガチャ回数変数に入れる数字　　　　　　　　　　　　　　　　（0の場合はガチャ回数変数の値をそのまま利用）
 * @type number
 * @default 1
 * 
 * @arg price
 * @text 総価格
 * @desc 総価格（ガチャ1回の値段でなく総回数の値段なので注意。所持金不足の際はパラメータ「所持金不足文章」を表示して終了）
 * @type number
 * @default 0
 * 
 * @arg priceVarId
 * @text 総価格の変数ID
 * @desc 総価格を「変数」で指定する場合の変数ID　　　　　　　　　　（変数IDを指定すると上の総価格の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg groups
 * @text グループ番号
 * @desc 抽選の対象となるグループ番号をすべて羅列　　　　　　　　　(すべて空欄だと、グループ番号1以上の全カードが対象となる)
 * @type number[]
 * @min 1
 * @default []
 * 
 * @arg pValues
 * @text レア値と当選確率
 * @desc レア値と当選確率を羅列（レア値が高いものから判定される。　レア値「0」は100％当選）
 * @type struct<PValue>[]
 * @default ["{\"Rare\":\"1\",\"PVal\":\"100\"}","{\"Rare\":\"2\",\"PVal\":\"40\"}","{\"Rare\":\"3\",\"PVal\":\"10\"}","{\"Rare\":\"4\",\"PVal\":\"4\"}","{\"Rare\":\"5\",\"PVal\":\"1\"}"]
 * 
 * @arg confirmedRare
 * @text 最低確定レア値
 * @desc ガチャ総回数の中で最低限1枚は選出確定しているレア値　　　（該当するレアカードが抽選対象にない場合は確定なし）
 * @type number
 * @default 0
 * 
 * @arg rareVarId
 * @text 最低確定レアの変数ID
 * @desc 最低確定レア値を「変数」で指定する場合の変数ID　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 *
 * @command iconIdAndName
 * @text アイコンID･名前代入
 * @desc アイテムやスキルのID値を元に該当アイコンID変数、該当カード名変数を代入する（各該当変数IDはパラメータで指定）
 * 
 * @arg isItem
 * @text アイテムか
 * @desc ID元は「アイテム」か（OFF時は「スキル」になる）
 * @type boolean
 * @default true
 * 
 * @arg itemId
 * @text アイテムID
 * @desc アイテムを指定する場合のアイテムID
 * @type item
 * @default 0
 * 
 * @arg skillId
 * @text スキルID
 * @desc スキルを指定する場合のスキルID
 * @type skill
 * @default 0
 * 
 * @arg idVariable
 * @text 変数ID
 * @desc IDを「変数」で指定する場合の変数ID　　　　　　　　　　　　（変数IDを指定すると上の定数値は無効となる）
 * @type variable
 * @default 0
 * 
 * @arg pictureSet
 * @text ピクチャを自動セット
 * @desc ID元カードのピクチャをプラグインパラメータで設定したピクチャIDにて、画面上中央に不透明度ゼロ（透明）で設置
 * @type boolean
 * @default false
 * 
 * @command enableCard
 * @text 場札等の使用可否変更（上級者向け）
 * @desc 場札などの戦闘コマンドでの使用可否を変更する（コストなどの制約は受ける。ロード再開時に引き継がれないので注意）
 * 
 * @arg iType
 * @text カード種
 * @desc 使用可否を変更するカード種（「場札」以外はゲームバランスを大きく崩しかねないので注意）
 * @type select
 * @option 山札(デッキ)
 * @option 手札
 * @option 捨札
 * @option 場札
 * @default 場札
 * 
 * @arg itemId
 * @text カードID
 * @desc 変更するカードID（必ず「通常アイテム」を指定すること！）　　（下記変数IDを指定すると、入力値は無効となる）
 * @type item
 * @default 0
 * 
 * @arg idVariable
 * @text カードIDの変数ID
 * @desc カードIDを「変数」で指定する場合の変数ID
 * @type variable
 * @default 0
 * 
 * @arg enableCard
 * @text 使用可能にする
 * @desc 戦闘カテゴリー上で使用可能にするか（途中で使用不可能に戻したい場合はOFFに再設定を）
 * @type boolean
 * @default true
 * 
 * @arg consumableCard
 * @text 消耗するか
 * @desc 消耗するか（ONだと使用後に捨札へ移動。OFFだと使用後に捨札へ移動しない）
 * @type boolean
 * @default false
 * 
 * @command enemyIndex
 * @text 敵強制指定(この後 敵イベントコマンドを)
 * @desc 敵スキルの使用直前・使用効果イベント内で記入すると、次のイベントコマンド（バトル項目）の対象が使用敵（単独）に強制指定される
 * 
 * @arg idVariable
 * @text 敵使用者IDを入れる変数ID
 * @desc 敵使用者の敵キャラIDを入れる変数ID　　　　　　　　　　　（敵キャラIDを知りたい時のみ利用）
 * @type variable
 * @default 0
 * 
 * @command damageWithoutShield
 * @text シールド無視のHP減少
 * @desc MPシールドを無視して味方HPを減少（「MPシールド化」がON時はイベントコマンド「HPの増減」での減少がMPシールドに影響されるため）
 * 
 * @arg actorId
 * @text アクターID
 * @desc HP減少の対象となるアクターID　　　　　　　　　　　　　　（「なし」の場合はパーティ全員が対象となる）
 * @type actor
 * @default 0
 * 
 * @arg actorVarId
 * @text アクター変数ID
 * @desc アクターIDを変数で指定する場合の変数ID（変数値が 0 の場合はパーティ全員が対象。変数IDを指定すると上記定数値は無効）
 * @type variable
 * @default 0
 * 
 * @arg damage
 * @text 減少値
 * @desc 減少させるHPの定数値
 * @type number
 * @default 0
 * 
 * @arg damageVarId
 * @text 減少変数ID
 * @desc 減少させるHP値を変数で指定する場合の変数ID　　　　　　　（変数IDを指定すると上記定数値は無効）
 * @type variable
 * @default 0
 * 
 * @arg allowDeath
 * @text 戦闘不能を許可
 * @desc HP減少による戦闘不能を許可するか
 * @type boolean
 * @default false
 *
 * @command battleStatus
 * @text 戦闘ステータスウインドウ
 * @desc 戦闘ステータスウインドウを操作（ドロー開始時は自動で非表示、　コマンド入力開始時と使用直前イベント後は自動で表示に戻る)
 * 
 * @arg operation
 * @text 戦闘ステータスウインドウ
 * @desc 戦闘ステータスウインドウの表示・非表示を操作　　　　　　　　（戦闘時以外では機能しません）
 * @type select
 * @option 表示(show)
 * @option 非表示(hide)
 * @default 非表示(hide)
 * 
 * @command iconDotChange
 * @text アイコンドット変更
 * @desc メッセージ中のアイコンドット数を変更します　　　　　　　　　（非戦闘時も使用可能。ターン・ガチャ前後で初期化されます）
 * 
 * @arg iconDot
 * @text アイコンドット指定
 * @desc メッセージ中のアイコンドット数を変更します　　　　　　　　　（非戦闘時も使用可能。ターン・ガチャ前後で初期化されます）
 * @type select
 * @option プラグインでの設定値
 * @option ツクールデフォ値
 * @option 下記の値
 * @default プラグインでの設定値
 * 
 * @arg tempDot
 * @text 入力値
 * @desc 上で「下記の値」にした時のみ有効（参考ツクールデフォ：32)
 * @type number
 * @default 0
 * 
 * 
 * @param InitDeck
 * @text 初期デッキ
 * @desc 初期デッキ（設定しない場合は戦闘前にプラグインコマンドでデッキを加えて下さい）（「通常アイテム」を指定すること！）
 * @type struct<Card>[]
 * @default ["{\"Id\":\"7\",\"Num\":\"3\"}","{\"Id\":\"8\",\"Num\":\"3\"}"]
 * 
 * @param BattleTestDeck
 * @parent InitDeck
 * @text 戦闘テスト専用デッキ
 * @desc 戦闘テストでのみ使用されるデッキ（空欄の場合は初期デッキが利用されるため、入力しなくてもよいです）
 * @type struct<Card>[]
 * @default []
 * 
 * @param deckAnno
 * @text ◆◆◆デッキ設定◆◆◆
 * @desc （原則：ON）（OFF時はデッキシステムの大部分を放棄し、　　ドロー設定・戦闘カテゴリー設定も無効化。ガチャ利用のみ等)
 * @type boolean
 * @default true
 * 
 * @param sameMaxBase
 * @parent deckAnno
 * @text 同一カード最大数
 * @desc 同一カードのデッキ内での最大枚数（アイテムのメモ欄の値が　優先されるが、省略するとこの値になる）（デフォルト：3）
 * @type number
 * @min 1
 * @default 3
 * 
 * @param initDeckMax
 * @parent deckAnno
 * @text デッキ最大数
 * @desc デッキの最大枚数（デフォルト：24）
 * @type number
 * @default 24
 * 
 * @param deckMin
 * @parent deckAnno
 * @text デッキ最小数
 * @desc デッキの最小枚数（メニュー操作での制限のみで、他操作で値を下回ってもエラーは出ません）（デフォルト：1）
 * @type number
 * @default 1
 * 
 * @param deckPlus
 * @parent deckAnno
 * @text デッキ増加許可
 * @desc アイテムメニューでデッキ枚数を増やすことを許可　　　　　（デフォルト：ON）（増加・減少ともOFF時は交換のみ）
 * @type boolean
 * @default true
 * 
 * @param deckMinus
 * @parent deckAnno
 * @text デッキ減少許可
 * @desc アイテムメニューでデッキ枚数を減らすことを許可　　　　　（デフォルト：ON）（増加・減少ともOFF時は交換のみ）
 * @type boolean
 * @default true
 * 
 * @param deckSwap
 * @parent deckAnno
 * @text デッキ交換許可
 * @desc アイテムメニューでデッキ交換を許可（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param deckDisableSwitch
 * @parent deckAnno
 * @text デッキ不可スイッチID
 * @desc ON時はデッキ操作不可となるスイッチID（デフォルト：なし)
 * @type switch
 * @default 0
 * 
 * @param deckAlert
 * @parent deckAnno
 * @text 超過エラー表示
 * @desc デッキに超過エラーがある時にアラート表示を行なう　　　　（デフォルト：ON）（ゲーム公開時はOFF推奨）
 * @type boolean
 * @default true
 * 
 * @param deckRecovery
 * @parent deckAnno
 * @text 戦闘前の状態へ戻す
 * @desc 戦闘中のデッキ増減に関わらず、戦闘後にデッキを戦闘前の状態へ戻す（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param drawAnno
 * @text ◆◆◆ドロー設定◆◆◆
 * @desc 毎ターンのカードドロー処理を行なうか（デフォルト：ON）　　　　　（OFF時は一切のドロー処理が行なわれなくなる）
 * @type boolean
 * @default true
 * 
 * @param initHandNum
 * @parent drawAnno
 * @text 初期手札数
 * @desc 1ターン目に配られる手札の枚数（デフォルト：4）
 * @type number
 * @default 4
 * 
 * @param initHandMax
 * @parent drawAnno
 * @text 最大手札数
 * @desc 最大手札数（デフォルト：6）（手札数を制限したくない場合は大きな値を入力。ドロー時以外の操作では値を超えられる）
 * @type number
 * @default 6
 *
 * @param baseDrawNum
 * @parent drawAnno
 * @text 基本ドロー数
 * @desc 2ターン目以降、ドロー数変数に毎回入る基本枚数（最大手札数までドローしたい場合は大きな値を入力）（デフォルト：1）
 * @type number
 * @default 1
 * 
 * @param drawStartShow
 * @parent drawAnno
 * @text ドロー開始文章表示
 * @desc ターン開始前イベント後にデフォルトのドロー開始文章 1-2 を表示する（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param drawObtainShow
 * @parent drawAnno
 * @text ドロー獲得文章表示
 * @desc ドロー直前イベント後のカード獲得時にデフォルトのドロー獲得文章を表示するか（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param shuffleAnno
 * @parent drawAnno
 * @text シャッフル設定
 * @desc ドロー時点で山札がない際、捨札を山札に戻してシャッフルするか（デフォルト：1）
 * @type select
 * @option 1：シャッフルし、そのターンはドローしない
 * @value 1
 * @option 2：シャッフルし、そのターンもドローする
 * @value 2
 * @option 3：シャッフルせずに、今後ドローできない
 * @value 3
 * @option 4：ドロー時に山札がないと、戦闘敗北になる
 * @value 4
 * @default 1
 * 
 * @param shuffleSEfile
 * @parent drawAnno
 * @text シャッフル時SE
 * @desc シャッフル時のSEファイル名（デフォルト：Book2）
 * @type file
 * @dir /audio/se
 * @default Book2
 * 
 * @param shuffleSEvolume
 * @parent shuffleSEfile
 * @text シャッフル時SE音量
 * @desc シャッフル時のSE音量（デフォルト：90）
 * @type number
 * @default 90
 * 
 * @param shuffleSEpitch
 * @parent shuffleSEfile
 * @text シャッフル時SEピッチ
 * @desc シャッフル時のSEピッチ（デフォルト：100）
 * @type number
 * @default 100
 * 
 * @param descAnno
 * @text ◆◆◆文章設定◆◆◆
 * @desc 制御文字が使用可能です
 *
 * @param drawStartDesc1
 * @parent descAnno
 * @text ドロー開始文章1
 * @desc ドロー開始のデフォルト文章1行目（制御文字使用可）　　　　　（デフォルト：\>　　　　\v[11]ターン目\{
 * @type string
 * @default \>　　　　\v[11]ターン目\{
 * 
 * @param drawStartDesc2
 * @parent descAnno
 * @text ドロー開始文章2
 * @desc ドロー開始のデフォルト文章2行目　　　　　　　　　　　　　　（デフォルト：\>　　　　　カードドロー！！\.\.\^）
 * @type string
 * @default \>　　　　　カードドロー！！\.\.\^
 * 
 * @param drawObtainDesc
 * @parent descAnno
 * @text ドロー獲得文章
 * @desc ドローでカード獲得後に表示される文章（デフォルト：\{\{　　\i[\v[16]]\c[17]\v[17]　\}\}\c[0]を ゲット！！\.\.\^）
 * @type string
 * @default \{\{　　\i[\v[16]]\c[17]\v[17]　\}\}\c[0]を ゲット！！\.\.\^
 * 
 * @param shuffleDesc
 * @parent descAnno
 * @text シャッフル時文章
 * @desc シャッフルする時に表示される文章（空欄の場合、表示されず）
 * @type string
 * @default \>　　　　山札がなくなったので、\c[17]シャッフル \c[0]します！
 * 
 * @param imposDrawZeroDesc
 * @parent descAnno
 * @text ドロー不可の文章
 * @desc ドロー変数が0でターン最初からドローできない時に表示される文章　（空欄の場合、表示されず）
 * @type string
 * @default \>　　　　このターン、カードドローが できません！
 * 
 * @param imposDrawHandMaxDesc
 * @parent descAnno
 * @text 手札限界の文章
 * @desc 最大手札数のため、ドローできない時に表示される文章　　　（空欄の場合、表示されず）
 * @type string
 * @default \.\{　　　　手札数 が 限界 です！！
 * 
 * @param imposDrawNoDeckDesc
 * @parent descAnno
 * @text 山札ない時の文章
 * @desc 山札がなく、シャッフルもできない時に表示される文章　　　（空欄の場合、表示されず）
 * @default \.\{　　　山札が もう ありません！！
 * 
 * @param shortGoldDesc
 * @parent descAnno
 * @text 料金不足の文章
 * @desc 料金が不足して、ガチャが不可能の時に表示される文章　　　（空欄の場合、表示されず）
 * @default \{　　　お金 が 足りません！！
 * 
 * @param gachaObtainDesc
 * @parent descAnno
 * @text ガチャ獲得文章
 * @desc ガチャでカード獲得後に表示される文章（デフォルト：\{\{　　\i[\v[16]]\c[17]\v[17]　\}\}\c[0]を ゲット！！）
 * @type string
 * @default \{\{　　\i[\v[16]]\c[17]\v[17]　\}\}\c[0]を ゲット！！
 * 
 * @param failGachaDesc
 * @parent descAnno
 * @text ガチャはずれ文章
 * @desc ガチャで該当するカードが何もない時に表示される文章　　　　（空欄の場合、表示されず）
 * @type string
 * @default \{\{　　　　ハ ズ レ ！！！
 * 
 * @param iconDot
 * @parent descAnno
 * @text アイコンドット数
 * @desc パラメータで設定する文章中のアイコンを拡大(デフォルト：54)（ツクールデフォ：32）（途中変更時はプラグインコマンドで）
 * @type number
 * @default 54
 * 
 * @param varAnno
 * @text ◆◆◆変数設定◆◆◆
 * @desc 計算式や文章の表示等で利用する変数IDを設定（ドロー数・ガチャ回数・ダメージ倍率％の変数は「なし」にはできません)
 * 
 * @param turnVarId
 * @parent varAnno
 * @text ターン数が入る変数ID
 * @desc ターン数が入る変数ID（毎ターン+1される。文章表示等で利用）（デフォルト：11）
 * @type variable
 * @default 11
 * 
 * @param drawVarId
 * @parent varAnno
 * @text ドロー数が入る変数ID
 * @desc 現在のドロー数が入る変数ID（なし にできない。入力すると次ドローに反映され、ドロー後に基本数に戻る。デフォルト：12）
 * @type variable
 * @default 12
 * 
 * @param gachaVarId
 * @parent varAnno
 * @text ガチャ回数が入る変数ID
 * @desc 現在のガチャ回数が入る変数ID（なし にできない。入力すると次ガチャ数に反映。条件分岐等で利用）（デフォルト：13）
 * @type variable
 * @default 13
 * 
 * @param damageVarId
 * @parent varAnno
 * @text ダメージ倍率％変数ID
 * @desc 使用直前(イベント前)ごとに<nxcond>の結果倍率％（条件未成立だと100）が入る変数ID（なし にできない）（デフォルト：14）
 * @type variable
 * @default 14
 * 
 * @param appliCardVarId
 * @parent varAnno
 * @text 該当カード変数ID
 * @desc ドロー･使用･ガチャ等の該当カードのアイテムIDが入る変数ID　（毎回上書きされる。条件分岐等で利用）（デフォルト：15）
 * @type variable
 * @default 15
 * 
 * @param appliIconVarId
 * @parent varAnno
 * @text 該当アイコン変数ID
 * @desc ドロー･使用･ガチャ等の該当カードのアイコンIDが入る変数ID　（毎回上書きされる。文章表示等で利用）（デフォルト：16）
 * @type variable
 * @default 16
 * 
 * @param appliNameVarId
 * @parent varAnno
 * @text 該当カード名変数ID
 * @desc ドロー･使用･ガチャ等の該当カード名称（文字）が入る変数ID　（毎回上書きされる。文章表示等で利用）（デフォルト：17）
 * @type variable
 * @default 17
 * 
 * @param appliItypeVarId
 * @parent varAnno
 * @text 該当起源iType変数ID
 * @desc 該当カードの起源のiTypeが入る変数ID（デフォルト：なし）　　(5:山札,6:手札,7:捨札,8:場札,9:武器,10:防具,11:スキル)
 * @type variable
 * @default 0
 * 
 * @param picId
 * @parent varAnno
 * @text 自動ピクチャ番号
 * @desc カードレイアウト・プラグイン併用時ドロー・ガチャ等でカード画をその番号、裏面画を番号+1として自動設置(デフォルト：31)
 * @type number
 * @default 31
 * 
 * @param eventAnno
 * @text ◆◆コモンイベント◆◆
 * @desc 各タイミングで割り込みできるコモンイベントIDを設定します　不要なら省略可。「トリガー」は「なし」に設定して下さい
 * 
 * @param zeroTurnCommon
 * @parent eventAnno
 * @text 0ターンイベントID
 * @desc 戦闘開始0ターンに一度だけ実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param preTurnCommon
 * @parent eventAnno
 * @text ターン開始前イベントID
 * @desc ターン開始前に毎ターン1回実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param preDrawCommon
 * @parent eventAnno
 * @text ドロー開始前イベントID
 * @desc ドロー開始前に毎ターン1回実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param justBeforeDrawCommon
 * @parent eventAnno
 * @text ドロー直前イベントID
 * @desc ドロー直前に（1枚ごと）実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param justAfterDrawCommon
 * @parent eventAnno
 * @text ドロー直後イベントID
 * @desc ドロー直後に（1枚ごと）実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param postDrawCommon
 * @parent eventAnno
 * @text ドロー終了後イベントID
 * @desc ドローが全て終わった後に毎ターン1回実行されるコモンイベントID（ドロー不可能時でも実行されます）
 * @type common_event
 * @default 0
 * 
 * @param preUseCommon
 * @parent eventAnno
 * @text 使用直前共通イベントID
 * @desc アイテムのメモ欄で指定がない時に、全カード共通で使用直前に実行されるコモンイベントID（使いたくない時は「なし」で）
 * @type common_event
 * @default 0
 * 
 * @param battleEndCommon
 * @parent eventAnno
 * @text 戦闘終了後イベントID
 * @desc 戦闘終了後に必ず実行されるコモンイベントID（カードは全てデッキにまとめられた状態。マップに戻った直後に実行される）
 * @type common_event
 * @default 0
 * 
 * @param preGachaCommon
 * @parent eventAnno
 * @text ガチャ開始前イベントID
 * @desc ガチャ開始前に一度だけ実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param justBeforeGachaCommon
 * @parent eventAnno
 * @text ガチャ直前イベントID
 * @desc ガチャ直前に（1回ごと）実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param justAfterGachaCommon
 * @parent eventAnno
 * @text ガチャ直後イベントID
 * @desc ガチャ直後に（1回ごと）実行されるコモンイベントID
 * @type common_event
 * @default 0
 * 
 * @param postGachaCommon
 * @parent eventAnno
 * @text ガチャ終了後イベントID
 * @desc ガチャがすべて終わった後に一度だけ実行されるコモンイベントID（ガチャがハズレでも実行）
 * @type common_event
 * @default 0
 * 
 * @param menuItem
 * @text ◆◆メニューアイテム◆◆
 * @desc メニュー（非戦闘時）アイテムウインドウの設定　　　　　　　（「大事なもの」の個数表示の有無はシステム1で設定）
 * 
 * @param deckName
 * @parent menuItem
 * @text デッキ名称
 * @desc メニューアイテムで「デッキ」リストにつけられる名称　　　　（デッキでは個数非表示となり、個数分のアイテムが並ぶ）
 * @type string
 * @default デッキ
 * 
 * @param deckWeightDisp
 * @parent deckName
 * @text デッキ総数表示
 * @desc デッキ名称の後の総数表示（デフォルト：デッキ数のみ）
 * @type select
 * @option デッキ数のみ
 * @option デッキ数/最大数
 * @option 表示しない
 * @default デッキ数のみ
 * 
 * @param offDeckName
 * @parent menuItem
 * @text デッキ外名称
 * @desc メニューアイテムで「デッキ外」リスト（＝通常アイテム）に　つけられる名称（空欄の場合、項目削除し、デッキ操作も不可)
 * @type string
 * @default デッキ外
 * 
 * @param offDeckNumDisp
 * @parent offDeckName
 * @text デッキ外で個数表示
 * @desc デッキ外で個数を表示（デフォルト：ON）　　　　　　　　　（OFF時は個数非表示となり、個数分のアイテムが並ぶ）
 * @type boolean
 * @default true
 * 
 * @param battleCategory
 * @text ◆◆戦闘カテゴリー◆◆
 * @desc 戦闘時にアイテムカテゴリーを表示するか（デフォルト：ON）（OFFの場合、手札表示のみとなります）
 * @type boolean
 * @default true
 * 
 * @param categoryWidth
 * @parent battleCategory
 * @text ウインドウ幅
 * @desc カテゴリーウインドウの幅（デフォルト：550）
 * @type number
 * @default 550
 * 
 * @param handName
 * @parent battleCategory
 * @text 手札名称
 * @desc 戦闘カテゴリーで「手札」リストにつけられる名称　　　　　（手札では個数非表示となり、個数分のアイテムが並ぶ）
 * @type string
 * @default 手札
 * 
 * @param handPriority
 * @parent handName
 * @text 手札優先表示
 * @desc アイテムコマンド選択時に（カテゴリー選択を飛ばして）手札を優先フォーカス表示するか（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param discName
 * @parent battleCategory
 * @text 捨札名称
 * @desc 戦闘カテゴリーで「捨札」リストにつけられる名称　　　　　（空欄の場合、項目削除）
 * @type string
 * @default 捨札
 * 
 * @param discNumDisp
 * @parent discName
 * @text 捨札個数表示
 * @desc 捨札で個数を表示（デフォルト：ON）　　　　　　　　　　（OFF時は個数非表示となり、個数分のアイテムが並ぶ）
 * @type boolean
 * @default true
 * 
 * @param boardName
 * @parent battleCategory
 * @text 場札名称
 * @desc 戦闘カテゴリーで「場札」リストにつけられる名称　　　　　（空欄の場合、項目削除）
 * @type string
 * @default 場札
 * 
 * @param boardNumDisp
 * @parent boardName
 * @text 場札個数表示
 * @desc 場札で個数を表示（デフォルト：OFF）　　　　　　　　　　（OFF時は個数非表示となり、個数分のアイテムが並ぶ）
 * @type boolean
 * @default false
 * 
 * @param battleDeckName
 * @parent battleCategory
 * @text 山札名称
 * @desc 戦闘カテゴリーで「山札」リストにつけられる名称　　　　　（空欄の場合、項目削除）
 * @type string
 * @default 山札
 * 
 * @param deckVisual
 * @parent battleDeckName
 * @text 山札可視化
 * @desc 山札を可視化するか（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param bDeckNumDisp
 * @parent battleDeckName
 * @text 山札個数表示
 * @desc 戦闘時の山札で個数を表示（デフォルト：ON）　　　　　　（OFF時は個数非表示となり、個数分のアイテムが並ぶ）
 * @type boolean
 * @default true
 * 
 * @param menuName
 * @parent battleCategory
 * @text メニュー名称
 * @desc 戦闘カテゴリーで「メニュー」につけられる名称　　　　　　（空欄の場合、項目削除）
 * @type string
 * @default メニュー
 * 
 * @param menuFunc
 * @parent menuName
 * @text メニュー機能
 * @desc メニューに割り当てられる機能　　　　　　　　　　　　　　（デフォルト：アクターコマンドへ）
 * @type select
 * @option アクターコマンドへ（キャンセルボタンと同じ）
 * @value command
 * @option 前アクター入力へ（先頭ではパーティコマンドへ）
 * @value previous
 * @option 防御コマンド（アクター入力終了)(「ターン終了」の役目)
 * @value guard
 * @default command
 * 
 * @param battleWindow
 * @text ◆◆戦闘ウインドウ◆◆
 * @desc 戦闘アイテム・スキルのウインドウ設定
 * 
 * @param itemCentering
 * @parent battleWindow
 * @text アイテム中央寄せ
 * @desc 戦闘アイテム（カード）を中央寄せ表示（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param skillCentering
 * @parent battleWindow
 * @text スキル中央寄せ
 * @desc 戦闘スキルのウインドウを中央寄せ表示（デフォルト：OFF）（ON時はウインドウ枠・背景の透過が下記で指定される）
 * @type boolean
 * @default false
 * 
 * @param frameTransparency
 * @parent battleWindow
 * @text ウインドウ枠透過
 * @desc 戦闘アイテム（戦闘スキル・アイテム選択時の中央寄せ時も）　ウインドウ枠を透過にする（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param backTransparency
 * @parent battleWindow
 * @text ウインドウ背景透過
 * @desc 戦闘アイテム（戦闘スキル・アイテム選択時の中央寄せ時も）　ウインドウ背景を透過にする（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param commandAnno
 * @text ◆◆アクターコマンド◆◆
 * @desc 戦闘アクターコマンドでアイテム名変更と職業メモ<nxcommand>　を有効にする（デフォルト：ON）（プラグイン競合時はOFFに）
 * @type boolean
 * @default true
 * 
 * @param itemCommandName
 * @parent commandAnno
 * @text アイテムコマンド名称
 * @desc 戦闘時アイテムコマンド名称を変更する（デフォルト：カード)　（空欄だと「用語」設定と同じになります）
 * @type string
 * @default カード
 * 
 * @param battlePriority
 * @parent commandAnno
 * @text 優先表示
 * @desc コマンド入力時にアイテムやスキルウインドウを優先表示（デフォルト：優先表示しない）(アクターコマンドOFF時も有効)
 * @type select
 * @option アイテム
 * @value item
 * @option スキル
 * @value skill
 * @option 優先表示しない
 * @value default
 * @default default
 * 
 * @param commandSealed
 * @parent commandAnno
 * @text コマンド封印
 * @desc アクターコマンドを封印（デフォルト：OFF）（優先表示がアイテムかスキル時のみ有効。スキルタイプはID順の1つのみで固定)
 * @type boolean
 * @default false
 * 
 * @param battleAnno
 * @text ◆◆◆戦闘設定◆◆◆
 * 
 * @param noPartyCommand
 * @parent battleAnno
 * @text パーティコマンド省略
 * @desc パーティコマンド入力を省略（デフォルト：ON）(TPBでは不可)（戦闘中に逃げたい時は先頭アクターがキャンセルする）
 * @type boolean
 * @default true
 * 
 * @param noSurprise
 * @parent battleAnno
 * @text 不意打ちなし
 * @desc 不意打ち・先制攻撃が起こらなくなる（デフォルト：ON)
 * @type boolean
 * @default true
 * 
 * @param successEscape
 * @parent battleAnno
 * @text 常に逃走成功
 * @desc 常に逃走成功率が100％となる（イベント戦闘を除く）　　　（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param omitSelection
 * @parent battleAnno
 * @text 対象選択を省略
 * @desc 戦闘で敵・味方の対象が一体だけの時は対象選択を省略する　（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param stateBeforeDraw
 * @parent battleAnno
 * @text ドロー前ステート更新
 * @desc ターン終了後ドロー前にステートを更新する（デフォルト：ON）（OFF時はドロー後に更新し、ドロー中のステート付加では注意)
 * @type boolean
 * @default true
 * 
 * @param canLose
 * @parent battleAnno
 * @text 戦闘敗北許可
 * @desc 通常戦闘を含め、敗北してもHP 1で復活（戦闘イベントで敗北を許可しなくてもゲームオーバーにならない）(デフォルト：OFF)
 * @type boolean
 * @default false
 * 
 * @param mpShield
 * @text ◆◆MPシールド化◆◆
 * @desc MP値をシールド値（HPの増加代替）として扱う　　　　　　　（デフォルト：OFF）（ON時は敵も味方も適用されるので注意）
 * @type boolean
 * @default false
 * 
 * @param shieldAnime
 * @parent mpShield
 * @text シールド防御SVアニメ
 * @desc シールドで防いだ時に再生されるSVアニメ（デフォルト：なし）
 * @type animation
 * @default 0
 * 
 * @param breakAnime
 * @parent mpShield
 * @text シールド破壊SVアニメ
 * @desc シールドが壊れた時に再生されるSVアニメ（デフォルト：なし）
 * @type animation
 * @default 0
 * 
 * @param tpAnno
 * @text ◆◆◆TP設定◆◆◆
 * @desc TP設定を変更する（敵・味方とも変更するが、「TP共有化」は味方のみ適用され、敵それぞれは共有化しない）
 * 
 * @param initTP0
 * @parent tpAnno
 * @text TP初期値ゼロ
 * @desc 戦闘開始時のTP初期値をゼロにするか（デフォルト：ON）　　　（TP持ち越しの場合を除く）
 * @type boolean
 * @default true
 * 
 * @param shareTP
 * @parent tpAnno
 * @text TP共有化
 * @desc TP値をパーティ全員で共有化（初期値ゼロも強制ON、TP持ち越しはパーティ先頭の設定のみ反映）（デフォルト：OFF)
 * @type boolean
 * @default false
 * 
 * @param damageTP
 * @parent tpAnno
 * @text TPダメージ変動値
 * @desc ダメージによるTP変動値（デフォ：0)（-999にするとツクールデフォのランダム値)（0の場合はTPチャージ率をTP消費率に変更)
 * @type number
 * @min -99999
 * @default 0
 * 
 * @param maxTP
 * @parent tpAnno
 * @text TP最大値
 * @desc TP最大値を設定（デフォルト：100）（敵・味方両方とも変更）
 * @type number
 * @default 100
 * 
 * @param gachaDirection
 * @text ◆◆◆ガチャ演出◆◆◆
 * @desc ガチャ直前イベント後のカード獲得時の演出（文章、ME）を以下で設定（デフォルト：ON）（OFF時は以下が全て演出されない）
 * @type boolean
 * @default true
 * 
 * @param gachaObtainShow
 * @parent gachaDirection
 * @text ガチャ獲得文章表示
 * @desc ガチャでカード獲得時にデフォルトの「ガチャ獲得文章」を表示するか（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param rareStarX
 * @parent gachaObtainShow
 * @text レア★のX座標
 * @desc 獲得文章の上行にレア値に応じた★と空白を描画するX座標（デフォルト：16）（0の場合は非表示。獲得文章表示OFF時無効）
 * @type number
 * @default 16
 * 
 * @param gachaNormalME
 * @parent gachaDirection
 * @text ガチャノーマルME
 * @desc ガチャでノーマルカード獲得時のMEファイル名　　　　　　　　（デフォルト：Refresh）
 * @type file
 * @dir /audio/me
 * @default Refresh
 * 
 * @param normalMEvolume
 * @parent gachaNormalME
 * @text ノーマルME音量
 * @desc ガチャノーマルMEの音量（デフォルト：90）
 * @type number
 * @default 90
 * 
 * @param normalMEpitch
 * @parent gachaNormalME
 * @text ノーマルMEピッチ
 * @desc ガチャノーマルMEのSEピッチ（デフォルト：100）
 * @type number
 * @default 100
 * 
 * @param gachaRareME
 * @parent gachaDirection
 * @text ガチャレアME
 * @desc ガチャでレアカード獲得時のMEファイル名（デフォルト：Item）
 * @type file
 * @dir /audio/me
 * @default Item
 * 
 * @param rareMEvolume
 * @parent gachaRareME
 * @text レアME音量
 * @desc ガチャレアMEの音量（デフォルト：90）
 * @type number
 * @default 90
 * 
 * @param rareMEpitch
 * @parent gachaRareME
 * @text レアMEピッチ
 * @desc ガチャレアMEのSEピッチ（デフォルト：100）
 * @type number
 * @default 100
 * 
 * @param rareValue
 * @parent gachaRareME
 * @text レア値
 * @desc ガチャレアMEを鳴らす最低のレア値（デフォルト：3）
 * @type number
 * @default 3
 * 
 * @param gachaLostME
 * @parent gachaDirection
 * @text ガチャはずれME
 * @desc ガチャでハズレ（何も選ばれなかった）時のMEファイル名　　　　　（デフォルト：Shock1）
 * @type file
 * @dir /audio/me
 * @default Shock1
 * 
 * @param lostMEvolume
 * @parent gachaLostME
 * @text はずれME音量
 * @desc ガチャはずれMEの音量（デフォルト：90）
 * @type number
 * @default 90
 * 
 * @param lostMEpitch
 * @parent gachaLostME
 * @text はずれMEピッチ
 * @desc ガチャはずれMEのSEピッチ（デフォルト：100）
 * @type number
 * @default 100
 * 
 * 
 * @help
 * 
 * 【RPGツクールMZ専用プラグイン】
 * 通常アイテムをカードに見立てた「デッキ構築型カードゲームRPG」を実現します
 * 　（カードシステムは味方側のみ適用され、敵行動はデフォルトRPGのままです）
 * パラメータは多いですが「初期デッキ」さえ入力すれば、初期設定で動きます
 * 　ベースプラグインとして「NLM_CardLayoutMZ.js」の併用が原則必要です
 * 
 * 主なプラグイン機能は以下の6つ
 * ① メニューアイテムにカテゴリー「デッキ」を新設し「デッキ外(通常アイテム)」
 * 　と入れ換えができる
 * ② 戦闘の毎ターン初めにデッキ（山札）から「カードドロー」としてカード（通常
 * 　アイテム）が手札へ自動で配られる
 * ③ 戦闘アイテムコマンド入力時に手札･捨札･場札･山札のカテゴリーウインドウ表示
 * ④ カード使用時に「TP・MPコスト」「使用直前コモンイベント」を設定できる
 * 　　（TP・MPコストの表示には NLM_CardLayoutMZ.js でレイアウト設定が必要）
 * ⑤ プラグインコマンドでカード獲得「ガチャ」、カード増減などを実行
 * ⑥ ドロー・使用直前・ガチャ時に そのカード画のピクチャを自動設置
 * 詳細な使い方は「サンプルプロジェクト」を参考にして下さい
 * 
 * 【アイテム(カード)の「メモ」欄の記述例】(省略可)
 * 　<ncard:配列> 　　　　　　 1番目の数字： グループ番号（1以上でガチャ対象）
 * 　　　　　　 　　　　　　　 2番目の数字： レア値　　　（ガチャ当選で利用）
 * 　(例)　　　　　　　　　　　3番目の数字： 最大枚数　　（デッキでの最大枚数)
 * 　　<ncard:2,1,99,21>　　 　4番目の数字： コモンイベントID（使用直前に実行)
 * 　　<ncard:1>　　　　　 　  5番目の数字： 武器タイプ　（サイドビュー時のみ)
 * 　　<ncard:1,2,0,21,-1>　　 6番目の文字： モーション　（サイドビュー時のみ)
 * 　　<ncard:2,0,0,0,0,chant>
 * 
 * 　(補足)
 * 　　　1番目はガチャの対象設定で利用し、省略・ゼロの際はガチャの対象外となる
 * 　　　3番目が省略・ゼロの際は「同一カード最大数」パラメータ値となる
 * 　　　5番目は「データベース」→「タイプ」→「武器タイプ」の値で、素手は 0、
 * 　　　　装備武器は -1 とし、省略で 0 となる
 * 　　　6番目は5番目が 0（素手）のとき有効で item, walk, wait, chant, guard,
 * 　　　　　　damage, evade, thrust, swing, missile, skill, spell, escape,
 * 　　　　　　victory, dying, abnormal, sleep, dead が使用可能（省略時 item）
 * 　　　他番号は省略でゼロの値になる
 * 　　　大事なもの、武器、防具は1-2番目のみ有効（ガチャ対象にしたい場合のみ）
 * 
 * 　<TPcost:コスト値>　：　カード使用にコスト値のTPを消費
 * 　<MPcost:コスト値>　：　カード使用にコスト値のMPを消費
 * 　　　(例)　<TPcost:2>　　<MPcost:9 - v[11]>　　<TPcost:this.cardnum(cId,6)>
 * 　　　(補足) コスト値にスクリプトを利用可(変数値はv[],アイテムIDはcIdで置換)
 * 　　　　　　だが、コマンド入力時（カード実行前）の値が参照されるので注意
 * 
 * 　<DeckUseSw:スイッチID>　：　指定スイッチがON時のみ、デッキ交換ができる
 * 　<HandUseSw:スイッチID>　：　指定スイッチがON時のみ、戦闘時などで使用できる
 * 　　　　　　　　　　　　　　　 （プラグインコマンドではOFF時でも移動できる）
 * 　<HandState:ステートID>　：　手札入手時に味方全員そのステートにかかる
 * 　<BoardState:ステートID> ：　場札移動時に味方全員そのステートにかかる
 * 　　　　　　　　　　　　　　　 （手札・場札から喪失で、ステート自動解除）
 * 　<nxactor:アクターIDをカンマで区切って羅列>　：　羅列アクターのみ使用可
 * 　　　(例)　<nxactor:1,2,4>　　<nxactor:5>　　（他アクターで使用不可になる）
 * 　<MPpenetrate>　　：　　MPシールドを無視して、HPのみにダメージを与える
 * 
 * 　<nxcond:対象,条件,倍率, 対象IDをカンマで区切って羅列>
 *  　→ 使用時点で対象の条件を満たすと計算式ダメージが倍率分になり、パラメータ
 *  　　指定のダメージ倍率％変数に100倍値が入る(使用直前コモンイベントで取得可)
 * 
 * 　 対象：　deck　 ：　山札　　　　　　　   条件：　1　：　すべて存在
 * 　 　　　　disc　 ：　捨札　　　　　　　  　 　　　2　：　どれか存在
 * 　 　　　　board　：　場札　　　　　　　  　　　　 3　：　存在数だけ倍率累乗
 * 　 　　　　hand　 ：　手札(使用カードは条件に含めず)
 * 　 　　　　skill　：　使用者の習得スキル
 * 　 　　　　class　：　職業（使用者も所持すること)
 * 　 　　　　member ：　戦闘メンバー(使用者含め)(IDはアクターID）
 * 　 (例)
 * 　　　<nxcond:hand,1,2,21,22,23>　（手札にID:21,22,23がすべて存在で2倍）
 * 　　　<nxcond:disc,3,1.2,21,22>　 （捨札のID:21,22の総枚数をnとして1.2^n倍）
 * 　　　<nxcond:skill,2,3,5,6,7>　　（使用者がスキルID:5,6,7のどれか習得で3倍)
 * 　　　<nxcond:class,2,1.5,2,3,5>　（使用者が職業ID:2,3,5のどれかなら1.5倍）
 * 　　　<nxcond:member,1,5,1,3,4>　 （使用者含め戦闘メンバーがID:1,3,4なら5倍)
 * 
 * 
 * 【スキルの「メモ」欄の記述例】(省略可)
 * 　<nskill:配列>　　　　　　 1番目の数字： コモンイベントID（使用直前に実行）
 * 　　　　　　 　　　　　　　 2番目の数字： 武器タイプ　（サイドビュー時のみ）
 * 　(例)　　　　　　　　　　　3番目の文字： モーション　（サイドビュー時のみ）
 * 　　<nskill:24>
 * 　　<nskill:0,0,evade>
 * 　(補足)
 * 　　　1番目を省略･0 にしても使用直前共通イベントは呼ばれない（個々指定のみ）
 * 　　　　※ 設定する場合は敵が使用してもコモンイベントが呼ばれる点に注意
 * 　　　　※「戦闘行動の強制」及びマップ上では直前イベントは実行されません
 * 　　　2番目を省略で ID:1(攻撃)は -1 (装備武器)、それ以外は 0 (素手)となる
 * 　　　3番目は2番目が 0 のとき有効で記述はアイテムと同じ（省略時skillかspell)
 * 　　　スキルでもアイテム同様 <nxcond> <MPpenetrate> が利用可能です
 * 
 * 
 * 【職業の「メモ」欄の記述例】(「◆◆アクターコマンド◆◆」ON時のみ有効)
 * 　<nxcommand:配列>　：　配列要素の順番で戦闘時アクターコマンドが生成される
 * 　　　配列要素：　a：攻撃、　s：スキル、　g：防御、　i：アイテム
 * 　(例) 　<nxcommand:i,s,g>　　　　　（省略時は <nxcommand:i,a,s,g> になる）
 * 
 * 
 * 【計算式やスクリプトで利用できる独自関数】
 * 　　this.cardnum(ID, iType)　　　：　アイテムID番のiType中の個数を返す
 * 　　　　（iType は 5：デッキ(山札)、6：手札、7：捨札、8：場札、1：デッキ外)
 * 　　　　（ID が 0 の場合は そのiTypeの総数を返す）
 * 　　　(例) this.cardnum(11,5)　　：　ID:11のデッキ(戦闘時は山札)中の枚数
 * 　　　　　 this.cardnum(0,6) 　　：　手札の総数（非戦闘時では0）
 * 
 * 　　this.ncard(ID, n) 　：　アイテムID番のメモ欄 <ncard> のn番目の値を返す
 * 　　　(例)  this.ncard(12,2)　　 ：　ID:12のメモ <ncard> のレア値
 * 
 * 　　this.getTPcost(ID)　：　アイテムID番のTPコスト値を返す（消費率未計算）
 * 　　this.getMPcost(ID)　：　アイテムID番のMPコスト値を返す（消費率未計算）
 * 
 * 　　this.targetIsDead()　：　直前の敵を倒した時に真を返す
 * 　　this.targetIsHit()　 ：　直前の敵にHPダメージを与えた時に真を返す
 * 　（注意）
 * 　　 「直前の敵」とは味方が最後に攻撃した敵単体(全体攻撃後でも)を指します
 * 　　　  計算式や使用直前コモンイベント内でこれから攻撃する敵ではありません!
 * 　　　  使用効果コモンイベント内での条件分岐スクリプトが主な使い道です
 * 
 * 
 * 【カードドロー処理プロセス】　（各コモンイベントは「なし」に設定可）
 *  (1)【0ターンのみ】0ターンコモンイベント（バトルイベント0ターン直後）
 * 　　（使用例) 毎回の戦闘開始前に入れる処理など
 * 　　 （※ 1ターン目のみ、ドロー数変数に「初期手札数」パラメータ値が入る）
 * 　　　　　　　　↓
 *  (2)ターン開始前コモンイベント（毎ターン1回のみ実行）
 * 　　（使用例) ターン終了の後処理、場札の効果発動、手札を捨札へ全移動など
 * 　　　　　　　　↓
 *  (3)ドロー開始文章表示（OFF可。パラメータで設定）
 * 　　　　　　　　↓
 *  (4)ドロー開始前コモンイベント（毎ターン1回のみ実行）
 * 　　（使用例) 自作ドロー開始文章表示など
 * 　　　　　　　　↓
 *  (5)ドロー実行処理（ドロー数変数がゼロになるまで繰り返し）
 * 　　① 山札からランダム抽出されたカードに応じて該当変数・ピクチャが自動更新
 * 　　 （※ ドロー不可時は(6)へ移行）
 * 　　 （※ ピクチャは初期状態で不透明度ゼロ(透明)で設置されています）
 * 　　② ドロー直前コモンイベント（①の該当変数・ピクチャを利用可）
 * 　　③ ドロー獲得文章表示（OFF可。パラメータで設定）、カード獲得
 * 　　④ ドロー直後コモンイベント
 * 　　　　　　　　↓
 *  (6)ドロー終了後コモンイベント（ドロー不可時でも毎ターン1回のみ実行）
 * 　　ドロー数変数が「基本ドロー数」パラメータ値に戻る
 * 　　　　　　　　↓
 *  (7)戦闘アクターコマンド入力へ
 * 
 * 
 * 【カードガチャ処理プロセス】　（各コモンイベントは「なし」に設定可）
 *  (1) プラグインコマンド「カードガチャ」で処理開始、料金消費
 * 　　（※ 料金が不足する場合はパラメータ「料金不足の文章」表示で終了）
 * 　　　　　　　　↓
 *  (2) ガチャ開始前コモンイベント（1回のみ実行）
 * 　　　　　　　　↓
 *  (3) ガチャ実行処理（ガチャ回数変数がゼロになるまで繰り返し）
 * 　　① 抽選確率で選出されたカードに応じて、該当変数・ピクチャが自動更新
 * 　　② ガチャ直前コモンイベント（①の該当変数・ピクチャを利用可）
 * 　　③ ガチャ獲得文章表示・ME演奏（OFF可。パラメータで設定）、カード獲得
 * 　　④ ガチャ直後コモンイベント（※ 直前・直後イベントはハズレでも実行）
 * 　　　　　　　　↓
 *  (4) ガチャ終了後コモンイベント
 * 
 * 
 * 【注意・補足】
 * 　・ メモ欄記述では大文字・小文字が識別されるので書き間違いに注意して下さい
 * 　・ 通常アイテムは全てカードとして扱われ、非戦闘時メニュー上ではデッキ交換
 * 　　のみで使用できなくなります。薬草やポーション等は「大事なもの」で作成し
 * 　　て下さい（大事なものは戦闘中に使用不可。データベース上は混在して設定可)
 * 　・ 通常アイテムの「使用可能時」は原則「常時」にして下さい（「バトル画面」
 * 　　だとデッキ交換不可、「メニュー画面」だと戦闘で使用不可になります)
 * 　・ デッキ外カードの増減はイベントコマンドの「アイテムの増減」でも可能です
 * 　・ 手札使用時、アイテムの「消耗」が「あり」で捨札へ自動移動し、「なし」で
 * 　　手札に留まります。場札は,山札→手札→捨札→山札の輪から外れた除外カード
 * 　　扱いで、コマンドで使用不可（プラグインコマンドで変更可）となります
 * 　・ ダメージ計算式および使用直前コモンイベント内で使用カードは手札に残った
 * 　　状態として数えられ(<nxcond>以外),まだ捨札へ移動していない点に留意して下
 * 　　さい。直前イベント内で使用カードの移動や減少をすると誤作動しやすいです
 * 　　 データベース→アイテム→使用効果→コモンイベントでは、手札が捨札へ移動
 * 　　後として扱われるため、こちらでカードの移動や増減をすることを推奨します
 * 　・ 使用前のピクチャ自動生成はアイテムのみで、スキルでは自動生成されません
 * 　　（必要ならスキルでも該当変数にIDが入るので、直前イベントで手動作成を）
 * 　・ Window内カードの並び順は常にID順になり、入手順や捨てた順にはなりません
 * 　・ 使用直前コモンイベント内で「直前に行動したアクターのID」(これから行動
 * 　　予定のIDが入る）を取得できますが、行動前のため「対象」は取得できません
 * 　・ 該当変数(カード変数、アイコン変数、カード名変数)は多くのプラグインコマ
 * 　　ンドで上書きされるため、ドロー･ガチャ直前イベント内でプラグインコマンド
 * 　　を使用してしまうと,デフォルト獲得文章が正しく表示されない場合があります
 * 　・ 戦闘コマンド上でカードを即時使用したい際は、Ruたん様の「ターン消費なし
 * 　　スキルプラグイン」 https://torigoya-plugin.rutan.dev/battle/quickSkill/
 * 　　を併用し「アイテム」のメモ欄に <QuickSkill> を記入すれば実現可能です
 * 　・ デッキ入れ換え時のSE音は「システム1」の効果音「装備」で設定されます
 * 　・ メニュースキルで、スキルタイプが一つだけの場合は選択が省略されます
 * 　・ 必中のアイテム・スキルの使用効果にコモンイベントを入れると、行動失敗の
 *　　 ログが出ません（行動失敗を出したい時は命中タイプを必中以外にして下さい)
 * 　・ ダメージ倍率％変数は非戦闘時の計算式にも影響し、非戦闘時に変動させると
 * 　　自動では100に戻らないので注意して下さい（非戦闘時の回復魔法などに影響）
 * 　・ TPダメージ変動値を完全に0にしたい時に,スキルの「得TP」を見落としやすい
 * 　・「アイテム水増し表示プラグイン」(NLM_ItemDilution.js)は本プラグイン内へ
 * 　　改修して取り込み済みのため、同時に併用しないで下さい
 * 　・ 本プラグインはターン制戦闘専用に調整しています。タイムプログレス戦闘で
 * 　　の動作は保証できません
 * 　・ 本プラグインによるコアスクリプト改変は多岐に渡るため、他のプラグインと
 * 　　競合しやすい点は御了承ください
 * 
 * 利用規約はMITライセンスの通りです
 * 　私個人の趣味で作成し、無償で提供しているものですので、このプラグインで
 * 生じた問題・不備に対し、制作者が責任を負う義務はないことをご理解ください
 */

/*~struct~Card:
 * 
 * @param Id
 * @text アイテムID
 * @desc カードのアイテムID　（「大事なもの」「隠しアイテム」でなく必ず「通常アイテム」を指定して下さい！！）
 * @type item
 * @default 0
 * 
 * @param Num
 * @text 枚数
 * @desc カードの枚数
 * @type number
 * @default 1
 */

/*~struct~PValue:
 * 
 * @param Rare
 * @text レア値
 * @desc レア値（アイテムメモ欄<ncard:>の2番目の数字）
 * @type number
 * @min 1
 * @default 1
 * 
 * @param PVal
 * @text 当選確率(％)
 * @desc 当選確率(％)
 * @type number
 * @decimals 2
 * @max 100
 * @default 100
 */

(() => {
  "use strict";

  const pluginName = "NLM_CardGameMZ";
  const NLMGparam  = PluginManager.parameters(pluginName);
  NLMGparam.sameMaxBase = Number(NLMGparam.sameMaxBase) || 3;
  NLMGparam.initDeckMax = Number(NLMGparam.initDeckMax) || 0;
  NLMGparam.initHandMax = Number(NLMGparam.initHandMax) || 0;
  NLMGparam.iconDot     = Number(NLMGparam.iconDot)     || 32;
  NLMGparam.picId       = Number(NLMGparam.picId)       || 0;
  NLMGparam.maxTP       = Number(NLMGparam.maxTP)       || 0;
  NLMGparam.deckAnno       = NLMGparam.deckAnno       === "true";
  NLMGparam.deckSwap       = NLMGparam.deckSwap       === "true";
  NLMGparam.deckAlert      = NLMGparam.deckAlert      === "true";
  NLMGparam.drawAnno       = NLMGparam.drawAnno       === "true" && NLMGparam.deckAnno;
  NLMGparam.battleCategory = NLMGparam.battleCategory === "true" && NLMGparam.deckAnno;
  NLMGparam.deckVisual     = NLMGparam.deckVisual     === "true";
  NLMGparam.itemCentering  = NLMGparam.itemCentering  === "true";
  NLMGparam.skillCentering = NLMGparam.skillCentering === "true";
  NLMGparam.commandSealed  = NLMGparam.commandSealed  === "true"
                          && NLMGparam.battlePriority !== "default";
  NLMGparam.noPartyCommand = NLMGparam.noPartyCommand === "true";
  NLMGparam.gachaDirection = NLMGparam.gachaDirection === "true";
  NLMGparam.stateBeforeDraw   = NLMGparam.stateBeforeDraw   === "true"; 
  NLMGparam.frameTransparency = NLMGparam.frameTransparency === "true";
  NLMGparam.backTransparency  = NLMGparam.backTransparency  === "true";

  const NLCLparam = PluginManager.parameters("NLM_CardLayoutMZ"); // パラメータ引継ぎ

  let NLMGitemMaxNum = 0; // データベース上のアイテム最大数
  let NLMGfirstBoot  = true;
  let NLMGcategory   = "none";
  let NLM_CardLayout     = false;
  let TorigoyaQuickSkill = false;

  $plugins.forEach((plugin) => { // プラグイン併用のチェック
    if (plugin.name === "NLM_CardLayoutMZ" && plugin.status) {
      NLM_CardLayout = true;
    }
    if (plugin.name === "TorigoyaMZ_QuickSkill" && plugin.status) {
      TorigoyaQuickSkill = true;
    }
  });

// 変数値の閲覧と代入
  function NLMGvar(name, value) {
    let varId = 0;
    switch (name) {
      case "turn": // ターン数
        varId = NLMGparam.turnVarId;
        break;
      case "draw": // ドロー数
        varId = Number(NLMGparam.drawVarId)   || 12; // ドロー数変数は必要
        break;
      case "gacha": // ガチャ回数
        varId = Number(NLMGparam.gachaVarId)  || 13; // ガチャ回数変数は必要
        break;
      case "damage": // ダメージ倍率％
        varId = Number(NLMGparam.damageVarId) || 14; // ダメージ倍率％変数は必要
        break;
      case "appliId":    // 該当カードID
        varId = NLMGparam.appliCardVarId;
        break;
      case "appliIcon":  // 該当カードアイコンID
        varId = NLMGparam.appliIconVarId;
        break;
      case "appliName":  // 該当カード名
        varId = NLMGparam.appliNameVarId;
        break;
      case "appliItype": // 該当カードiType
        varId = NLMGparam.appliItypeVarId;
        break;
      default:
        return 0;
    }
    if (value !== undefined) $gameVariables.setValue(varId, value);
    return $gameVariables.value(varId);
  };

// DataManager関係
  // 隠しパラメータ
  DataManager._NLMGdeckMaxVarId = 0; // 最大デッキ数を入れる変数ID
  DataManager._NLMGhandMaxVarId = 0; // 最大手札数を入れる変数ID
  DataManager._NLMGcategoryX    = 0; // 戦闘カテゴリーウインドウX座標
  DataManager._NLMGcategoryY    = 0; // 戦闘カテゴリーウインドウY座標（0の時はデフォルト位置）
  DataManager._NLMGeventItemY   = 0; // アイテム選択（中央寄せ）でのウインドウY座標補正
  DataManager._NLMGtcrEx        = 1; // TPチャージ率をTP消費率に変換（0：しない、1：TPダメージ変動値が0時のみ、2：常に変換）
  DataManager._NLMGdamageColor  = 18; // ダメージ倍率％変数値が100より大きい時のダメージフォントカラー番号（0-32）
  DataManager._NLMGgachaStar    = "★"; // ガチャのレア★を表現する一文字
  DataManager._NLMGstarColor    = 27; 　// ガチャのレア★のカラー番号（0-32）
  DataManager._NLMGcategoryFontSize   = 22;    // 戦闘カテゴリーウインドウのフォントサイズ
  DataManager._NLMGeventNormalHeight  = 8;     // アイテム選択・通常時の高さ行数
  DataManager._NLMGeventCenterHeight  = 4;     // アイテム選択・中央寄せ時の高さ行数
  DataManager._NLMGdrawWithoutInput   = false; // 全員入力不可時でもドローできる
  DataManager._NLMGdrawInitObtainOff  = false; // 開始時のドローだけドロー獲得文書が出ない
  DataManager._NLMGescapeFailureDraw  = true;  // 逃走失敗時の次ターンもドローできる
  DataManager._NLMGskillPictureSet    = false; // スキルでも使用直前にピクチャを自動セット
  DataManager._NLMGdeckNumDisp        = false; // メニューアイテムでのデッキの個数表示
  DataManager._NLMGhandNumDisp        = false; // 戦闘アイテムでの手札の個数表示
  DataManager._NLMGhandAllNumDisp     = true;  // 戦闘カテゴリーでの手札の総数表示
  DataManager._NLMGdiscAllNumDisp     = true;  // 戦闘カテゴリーでの捨札の総数表示
  DataManager._NLMGboardAllNumDisp    = true;  // 戦闘カテゴリーでの場札の総数表示
  DataManager._NLMGdeckAllNumDisp     = true;  // 戦闘カテゴリーでの山札の総数表示
  DataManager._NLMGhandCentering      = true;  // 戦闘アイテムでの手札の中央寄せ（中央寄せON時の個別）
  DataManager._NLMGdiscCentering      = true;  // 戦闘アイテムでの捨札の中央寄せ（中央寄せON時の個別）
  DataManager._NLMGboardCentering     = true;  // 戦闘アイテムでの場札の中央寄せ（中央寄せON時の個別）
  DataManager._NLMGdeckCentering      = true;  // 戦闘アイテムでの山札の中央寄せ（中央寄せON時の個別）
  DataManager._NLMGenemyCentering     = true;  // 戦闘エネミーでの中央寄せ(NLM_CardLayout.MZでエネミーで適用ON時のみ）
  DataManager._NLMGcols0              = true;  // 中央寄せ時に列数ゼロの際はデフォルト列数表示
  DataManager._NLMGiFrameTransparency = false; // 戦闘アイテムでのウインドウ枠透過　（強制）
  DataManager._NLMGiBackTransparency  = false; // 戦闘アイテムでのウインドウ背景透過（強制）
  DataManager._NLMGsFrameTransparency = false; // 戦闘スキルでのウインドウ枠透過　（強制）
  DataManager._NLMGsBackTransparency  = false; // 戦闘スキルでのウインドウ背景透過（強制）
  DataManager._NLMGcFrameTransparency = false; // 戦闘カテゴリーのウインドウ枠透過
  DataManager._NLMGcBackTransparency  = false; // 戦闘カテゴリーのウインドウ背景透過
  DataManager._NLMGyFrameTransparency = false; // 戦闘エネミーのウインドウ枠透過
  DataManager._NLMGyBackTransparency  = false; // 戦闘エネミーのウインドウ背景透過
  DataManager._NLMGaBackTransparency  = false; // 戦闘ステータスウインドウ背景透過
  DataManager._NLMGeFrameTransparency = false; // アイテム選択(中央寄せ)でのウインドウ枠透過（強制）
  DataManager._NLMGeBackTransparency  = false; // アイテム選択(中央寄せ)でのウインドウ背景透過（強制）
  DataManager._NLMGnoBattleStatus     = false; // コマンド入力時以外の戦闘ステータスを非表示にする
  DataManager._NLMGitemSVmotion       = true;  // アイテム使用時のSVモーションをメモ欄記述に変更
  DataManager._NLMGskillSVmotion      = true;  // スキル使用時のSVモーションをメモ欄記述に変更
  DataManager._NLMGnoLogFailure       = true;  // 必中の使用効果にコモンイベントを入れると行動失敗の戦闘ログが出ない
  DataManager._NLCLnxcondExc          = true;  // <nxcond:hand>で使用カードは数に含めない
  DataManager._NLMGnxcondPower        = true;  // <nxcond>条件3を倍率累乗にする（false時は存在数に倍率を直接乗算）
  DataManager._NLMGnxcondContinue     = false; // <nxcond>成立時のダメージ倍率変化は1回限り有効にする
  DataManager._NLMGnoSkillType        = true;  // メニュースキルでスキルタイプが一つの時は選択を省略
  DataManager._NLMGgachaContainWeapon = true;  // ガチャに武器を含める
  DataManager._NLMGgachaContainArmor  = true;  // ガチャに防具を含める
  DataManager._NLMGimmediateConsume   = true;  // デッキ設定OFF時でも戦闘入力時のTP･MP即時消費を実行（これをfalseにするならエラースルーもfalseがよい）
  DataManager._NLMGerrorDisp          = true;  // エラー（デッキ超過以外）のConsole表示を行なう
  DataManager._NLMGerrorThrough       = false; // 戦闘で使用直前に使用アイテムが消失した際でもエラースルー
  DataManager._NLMGnoDeckCheck        = false; // 起動時・戦闘終了後・最大デッキ数減少でのデッキ超過チェックを行なわない
  DataManager._NLMGfinishCommonEvent  = false; // 戦闘終了時に実行されていないコモンイベントを消化
  DataManager._NLMGchangeAutosave     = true;  // 戦闘後オートセーブをイベント終了後に変更（false時は戦闘終了後イベントがオートセーブ時に未実行。NLM_ItemToSummon.js併用で強制ON）
  DataManager._NLMGmpShieldGuard      = true;  // MPシールド成功時に防御モーションをとる
  DataManager._NLMGregenerateHpChange = false; // HP再生率でも、MPシールドを適用
  DataManager._NLMGfloorDamageChange  = false; // 床ダメージでもMPシールドを適用
  DataManager._NLMGguarding           = false; // 防御ステートがなくても防御モーションスキルなら防御姿勢継続
  DataManager._NLMGnoLogState         = false; // <HandState>が発動した際に戦闘ログを出さない
  DataManager._NLMGfinalDamage        = false; // ダメージ倍率％変数の反映を最終ダメージにする（false時は基礎ダメージで反映。プラグイン競合時用）
  DataManager._NLMGdeleteLastTarget   = false; // 全アクション直前に「直前に対象となった敵キャラインデックス」を消去
  DataManager._NLMGtcrRound           = false; // TP消費率結果を四捨五入（false時は切り捨て）
  DataManager._NLMGhiddenItemNumber   = false; // アイテム選択での隠しアイテムの個数表示（プラグインコマンドを使わない時）
  DataManager._NLMGcategoryPriority = "hand";  // 戦闘カテゴリーでの優先表示（通常は手札）
  DataManager._NLMGcategorySymbols = ["hand", "disc", "board", "deck", "menu"]; // 戦闘カテゴリーの表示順

 // 構造体変換
  DataManager.NLMstruct = function(param) {
    if (!param.length) return param;
    const str = JSON.parse(param);
    return str.map(str => JSON.parse(str));
  };

  // カード生成・デッキ初期処理
  const _DM_createGameObjects = DataManager.createGameObjects;
  DataManager.createGameObjects = function() {
    _DM_createGameObjects.apply(this, arguments);
    this.NLMGcreateGameObjects();
  };

  DataManager.NLMGcreateGameObjects = function() {
    if (NLMGfirstBoot) {
      NLMGitemMaxNum = $dataItems.length - 1; // データベース上のアイテム最大数取得
      this.NLMGdataRemake();                  // 初回起動時のみアイテム生成
      NLMGfirstBoot = false;
    }
    if (SceneManager._scene.constructor !== Scene_Boot || this.isBattleTest()
        || this.isEventTest() || this.isTitleSkip()) { // 起動時とタイトル後で繰り返さないように
      this.NLMGmakeInitDeck(); // 初期デッキ追加
      ImageManager._NLMGicon = ImageManager.iconWidth;
      $gameVariables.setValue(DataManager._NLMGdeckMaxVarId, NLMGparam.initDeckMax);
      $gameVariables.setValue(DataManager._NLMGhandMaxVarId, NLMGparam.initHandMax);
      NLMGvar("damage", 100);
    }
  };

  DataManager.NLMGdataRemake = function() { // 山札・手札・捨札・置札のアイテム生成
    const data = $dataItems;
    const max  = NLMGitemMaxNum;
    for (let j=1; j<=4; j++) {
      for (let i=1; i<=max; i++) {
        const id = i + j * max;
        const occ  = data[i].occasion;
        const occ2 = (j === 1 && (occ === 0 || occ === 2)) ? 2 : j === 1 ? 3 : j > 2 ? 3 : occ;
        data.push({"id" : id});
        for (const [key, value] of Object.entries(data[i])) {
          data[id][key] = value;
        }
        data[id].id       = id;
        data[id].price    = 0;
        data[id].itypeId  = j + 4;
        data[id].occasion = occ2;
      }
    }
    this.extractArrayMetadata(data); // メタデータ更新
  };

  DataManager.NLMGmakeInitDeck = function() { // 初期デッキ作成
    const btd = NLMGparam.BattleTestDeck;
    const eva = this.isBattleTest() && btd !== "[]";
    const initDeck = this.NLMstruct(eva ? btd : NLMGparam.InitDeck);
    this.NLMGaddDeckArr(initDeck);
    if (!DataManager._NLMGnoDeckCheck) this.NLMGdeckCheck();
    this.NLMGcategorySymbols(); // 戦闘カテゴリーシンボル修正
  };

  DataManager.NLMGaddDeckArr = function(add, onlyOffDeck) {
    if (add.length) {
      add.forEach((array) => {
        const id  = Number(array.Id)  || 0;
        const num = Number(array.Num) || 0;
        this.NLMGaddDeck(id, num, onlyOffDeck);
      });
    }
  };

  DataManager.NLMGaddDeck = function(id, num, onlyOffDeck) {
    if (id && num && $dataItems[id].itypeId === 1) {
      let gainNum  = num;
      if (onlyOffDeck) {
        const offNum = $gameTemp.cardnum(id,1);
        if (offNum < gainNum) { // デッキ外の個数が不足した場合
          gainNum = offNum;
        }
        $gameParty.loseCard(id, gainNum, 1);
      }
      $gameParty.gainCard(id, gainNum, 5);
    }
  };

  DataManager.NLMGdeckMax = function() { // デッキ最大数
    const varId = DataManager._NLMGdeckMaxVarId;
    return varId ? $gameVariables.value(varId) : NLMGparam.initDeckMax;
  };

  DataManager.NLMGdeckCheck = function() { // デッキ超過チェック
    const iMax = NLMGitemMaxNum;
    for (let i = 1; i <= iMax; i++) {
      const d  = $gameTemp.cardnum(i,5) - $gameTemp.ncard(i,3);
      if (d > 0) { // 同一カード最大数を超えていたら
        $gameParty.loseCard(i,d,5);
        $gameParty.gainCard(i,d,1);
        if (NLMGparam.deckAlert) {
          const nm = $dataItems[i].name;
          alert("「" + nm + "」の同一カード最大数を超えたため、デッキ外へ外しました");
        }
      }
    }
    const alln = $gameTemp.cardnum(0,5);
    const dMax = this.NLMGdeckMax();
    if (alln > dMax) { // デッキ最大数を超えていたら
      let wei = alln;
      for (let i = iMax; i > 0; i--) {
        const num = $gameTemp.cardnum(i,5);
        for (let j = 1; j <= num; j++) {
          $gameParty.moveCard(i,5,1);
          wei--;
          if (NLMGparam.deckAlert) {
            const nm = $dataItems[i].name;
            alert("デッキ最大数(" + dMax + ")を超えたため「" + nm + "」をデッキ外へ外しました");
          }
          if (wei <= dMax) break;
        }
        if (wei <= dMax) break;
      }
    }
  };

  DataManager.NLMGcategorySymbols = function() { // 戦闘カテゴリーのシンボル修正
    let symbols = [];
    for (const symbol of this._NLMGcategorySymbols) {
      let plus = true;
      if (symbol === "disc")  plus = NLMGparam.discName;
      if (symbol === "board") plus = NLMGparam.boardName;
      if (symbol === "deck")  plus = NLMGparam.battleDeckName;
      if (symbol === "menu")  plus = NLMGparam.menuName;
      if (plus) symbols.push(symbol);
    }
    this._NLMGcategorySymbols = symbols;
  };

  // メモ欄情報 <ncard> <nskill> <nxactor> <nxcond> <nxcommand>を配列化
  DataManager.NLMGcardData = function(item) {
    if (!item) return;
    const sMax = NLMGparam.sameMaxBase;
    const data = item.meta["ncard"];
    if (data && data.length) {
      const arr = data.split(",");
      for (let i=0; i <= 4; i++) {
        arr[i] = parseInt(arr[i]) || 0;
      }
      arr[2] = arr[2] || sMax;
      arr[5] = arr[5] ? this.NLMdeleteSpace(arr[5]) : "item";
      return arr;
    }
    return [0,0,sMax,0,0,"item"];
  };

  DataManager.NLMGskillData = function(skill) {
    if (skill) {
      const data = skill.meta["nskill"];
      if (data && data.length) {
        const arr = data.split(",");
        arr[0] = parseInt(arr[0]) || 0;
        return arr;
      }
      return [0];
    }
  };

  DataManager.NLMGnxactor = function(item) {
    const actors = item.meta["nxactor"];
    if (actors && actors.length) {
      const arr = actors.split(",");
      for (let i=0; i < arr.length; i++) {
        arr[i] = parseInt(arr[i]) || 0;
      }
      return arr;
    }
    return [];
  };

  DataManager.NLMGnxcond = function(item) {
    const data = item.meta["nxcond"];
    if (data && data.length) {
      const arr = data.split(",");
      arr[0] = this.NLMdeleteSpace(arr[0]);
      for (let i=1; i < arr.length; i++) {
        arr[i] = Number(arr[i]) || 0;
      }
      return arr;
    }
    return [];
  };

  DataManager.NLMGcommandList = function(cClass) {
    const data = cClass.meta["nxcommand"];
    if (data && data.length) {
      const arr = data.split(",");
      for (let i=0; i < arr.length; i++) {
        arr[i] = this.NLMdeleteSpace(arr[i]);
      }
      return arr;
    }
    return ["i","a","s","g"];
  };

  DataManager.NLMdeleteSpace = function(str) { // 前後の空白を除去
    return str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"");
  };

  // メモ欄 <DeckUseSw>判定
  DataManager.NLMGdeckUseSwitch = function(id) {
    if ($gameParty.inBattle()) return true;
    const meta = $dataItems[id].meta["DeckUseSw"];
    if (!meta) return true;
    return $gameSwitches.value(meta);
  };

  // アイテムを分類
  DataManager.NLMGcategolize = function(item) {
    let iType = 0;
    if (this.isWeapon(item)) iType = 9;
    if (this.isArmor(item))  iType = 10;
    if (this.isSkill(item))  iType = 11;
    if (this.isItem(item))   iType = item.itypeId;
    return iType;
  };

  // 戦闘アイテムの中央寄せ判定
  DataManager.NLMGcentering = function(category) {
    if (category === "hand"  && this._NLMGhandCentering)  return true;
    if (category === "disc"  && this._NLMGdiscCentering)  return true;
    if (category === "board" && this._NLMGboardCentering) return true;
    if (category === "deck"  && this._NLMGdeckCentering)  return true;
    if (category === "menu") return true;
    return false;
  };

// BattleManager関係
  const _BattleManager_setup = BattleManager.setup;
  BattleManager.setup = function(troopId, canEscape, canLose) { // 戦闘初期処理追加
    _BattleManager_setup.apply(this, arguments);
    if (NLMGparam.deckRecovery === "true") this.NLMGdeckSave();
    if (NLMGparam.canLose === "true") this._canLose = true;
    this._NLMGdrawProc  = 0;
    this._NLMGpredictId = 0;
    this._NLMGpreUse    = 0;
    this._NLMGpartyCommand  = false;
    this._NLMGescapeFailure = false;
    this._NLMGautosave      = false;
    this._NLMGconsumedItems = [];
    this._NLMGconsumedTp = [];
    this._NLMGconsumedMp = [];
    this._NLMGusedSkills = [];
    this._NLMGusedTp = [];
    this._NLMGusedMp = [];
    NLMGvar("turn", 1); // ターン数変数に「1」を代入
    NLMGvar("damage", 100);
    NLMGvar("draw", Number(NLMGparam.initHandNum) || 0); // ドロー数変数に初期手札数を代入
  };

  BattleManager.NLMGdeckSave = function() { // 戦闘前のデッキ情報をセーブ
    this._NLMGdeckSaveId  = [];
    this._NLMGdeckSaveNum = []
    const max  = NLMGitemMaxNum;
    for (let id = max + 1; id < max * 2 + 1; id++) { // v1.1.1にて修正（+1を忘れていた）
      const num = $gameParty.numItems($dataItems[id]);
      if (num) {
        this._NLMGdeckSaveId.push(id);
        this._NLMGdeckSaveNum.push(num);
      }
    }
  };

  // 不意打ち・先制攻撃なし
  if (NLMGparam.noSurprise === "true") {
    BattleManager.onEncounter = function() {
      this._preemptive = 0;
      this._surprise   = 0;
    };
  }

  // 逃走が必ず成功
  if (NLMGparam.successEscape === "true") {
    BattleManager.makeEscapeRatio = function() {
      this._escapeRatio = 1;
    };
  }

  // ターン終了処理変更
  const _BattleManager_endTurn = BattleManager.endTurn;
  BattleManager.endTurn = function() {
    _BattleManager_endTurn.apply(this, arguments);
    this._NLMGdrawProc = 0;
    NLMGvar("turn", NLMGvar("turn") + 1); // ターン数変数を+1
  };

  const _BM_endAllBattlersTurn = BattleManager.endAllBattlersTurn;
  BattleManager.endAllBattlersTurn = function() { // ドローON時はステート更新をドロー前へ移動
    if (!NLMGparam.drawAnno || !NLMGparam.stateBeforeDraw) {
      this.NLMGendAllBattlersTurn();
    }
  };

  BattleManager.NLMGendAllBattlersTurn = function() {
    this.NLMGcheckState(); // HandStateの漏れをチェック
    _BM_endAllBattlersTurn.apply(this, arguments); // ステート更新
    this.NLMGregenerateTp(); // TP再生改変
    this._logWindow.push("wait");
  };

  BattleManager.NLMGregenerateTp = function() {
    if (NLMGparam.shareTP === "true") { // TP共有化時は最大再生率で一人のみ適用
      let value = 0;
      for (const actor of $gameParty.members()) {
        const aValue = Math.floor(actor.maxTp() * actor.trg);
        value = Math.abs(value) >= Math.abs(aValue) ? value : aValue;
      }
      if (value !== 0) {
        $gameParty.members()[0].gainSilentTp(value);
      }
    }
  };

  // イベント処理改変
  const _BM_updateEventMain = BattleManager.updateEventMain;
  BattleManager.updateEventMain = function() {
    if (_BM_updateEventMain.call(this)) return true;
    return this.NLMGupdateEventMain();
  };

  BattleManager.NLMGupdateEventMain = function() { // カードドロー処理分岐
    if (!NLMGparam.drawAnno) return false;
    if (!this._NLMGdrawProc && $gameTroop.turnCount() === 0) {
      this.NLMGzeroTurn(); // 0ターン処理
      return true;
    }
    if (this._NLMGdrawProc === 1) {
      if (this._surprise) {
        this._NLMGdrawProc = 6;
      } else {
        this.NLMGpreDraw1(); // カードドロー前処理1
        return true;
      }
    }
    if (!this._NLMGdrawProc && this.isTurnEnd()) { // ターン終了時
      if (NLMGparam.stateBeforeDraw) {
        this.NLMGendAllBattlersTurn(); // ステート更新をここで実行
      }
      if ($gameParty.canInput() || DataManager._NLMGdrawWithoutInput) {
        this.NLMGpreDraw1(); // カードドロー前処理1
        return true;
      } else {
        return false;
      }
    }
    if (this._NLMGdrawProc === 2) {
      this.NLMGpreDraw2(); // カードドロー前処理2
      return true;
    }
    if (this._NLMGdrawProc === 3) {
      this.NLMGcardDraw1(); // カードドロー処理1
      return true;
    }
    if (this._NLMGdrawProc === 4) {
      this.NLMGcardDraw2(); // カードドロー処理2
      return true;
    }
    if (this._NLMGdrawProc === 5) {
      this.NLMGpostDraw1(); // カードドロー後処理1
      return true;
    }
    if (this._NLMGdrawProc === 6) {
      this.NLMGpostDraw2(); // カードドロー後処理2
      return true;
    }
    return false;
  };

  // 割込イベント事前処理
  BattleManager.NLMGpreDo = function() {
    if (this._NLMGdrawProc) { // ドロー中の場合
      SceneManager._scene._statusWindow.hide(); // ステータスウインドウを隠す
    }
    ImageManager._NLMGicon = NLMGparam.iconDot; // アイコン拡大
  };

  // 0ターン処理（バトルイベント0ターン直後)
  BattleManager.NLMGzeroTurn = function() {
    this._NLMGdrawProc = 1;
    this.NLMGpreDo();
    $gameTemp.reserveCommonEvent(NLMGparam.zeroTurnCommon); // 0ターンイベント予約
  };

  // カードドロー前処理1
  BattleManager.NLMGpreDraw1 = function() {
    if (!this._NLMGdrawProc) {
      this._NLMGdrawProc = 1;
      this.NLMGpreDo();
    }
    if (this._NLMGescapeFailure && !DataManager._NLMGescapeFailureDraw) { // 逃走失敗時
      NLMGvar("draw", 0);
    }
    $gameTemp.reserveCommonEvent(NLMGparam.preTurnCommon); // ターン開始前イベント予約
    this._NLMGdrawProc = 2;
  };

  // カードドロー前処理2（this._NLMGdrawProc = 2）
  BattleManager.NLMGpreDraw2 = function() {
    if (NLMGparam.drawStartShow === "true") { // ドロー開始デフォルト文章表示
      $gameMessage.setBackground(1);
      $gameMessage.setPositionType(1);
      $gameMessage.add("\x1b>" + NLMGparam.drawStartDesc1);
      $gameMessage.add("\x1b>" + NLMGparam.drawStartDesc2);
    }
    $gameTemp.reserveCommonEvent(NLMGparam.preDrawCommon); // ドロー開始前イベント予約
    this._NLMGdrawFirst = true;
    this._NLMGdrawProc  = 3;
  };

  // カードドロー処理1（this._NLMGdrawProc = 3）
  BattleManager.NLMGcardDraw1 = function() {
    const deckAll = $gameTemp.cardnum(0,5);
    const shuffle = Number(NLMGparam.shuffleAnno);
    const handMax = $gameVariables.value(DataManager._NLMGhandMaxVarId) || NLMGparam.initHandMax;
    if (NLMGvar("draw") <= 0) {  // ドロー変数が0
      if (this._NLMGdrawFirst) { // 最初からドロー不可時
        $gameTemp.oneLineDisp(NLMGparam.imposDrawZeroDesc, 2); // ドロー不可文章表示
      }
      this._NLMGdrawProc = 5;
    } else if ($gameTemp.cardnum(0,6) >= handMax) { // 手札が最大数を超えている時
      $gameTemp.oneLineDisp(NLMGparam.imposDrawHandMaxDesc, 2); // 手札限界文章表示
      this._NLMGdrawProc = 5;
    } else if (!deckAll && (shuffle >= 3 || !$gameTemp.cardnum(0,7))) { // 山札も捨札もない時またはシャッフルできない時
      $gameTemp.oneLineDisp(NLMGparam.imposDrawNoDeckDesc, 2); // 山札ない時の文章表示
      if (shuffle === 4) { // 山札ないと全員死亡
        $gameParty.members().forEach((actor) => {
          actor.addState(1);
        });
        this._NLMGdrawProc = 6;
      } else {this._NLMGdrawProc = 5;}
    } else if (!deckAll) { // 山札がない時 = シャッフル
      $gameTemp.NLMGshuffleSE(); // シャッフルSE演奏
      $gameTemp.oneLineDisp(NLMGparam.shuffleDesc, 0); // シャッフル時文章表示
      $gameParty.allMoveCard(7, 5); // 捨札を山札へ全移動
      if (shuffle === 1) this._NLMGdrawProc = 5;
    } else { // ドロー準備
      const pre = this._NLMGpredictId;
      const eva = pre && $gameTemp.cardnum(pre,5);
      const rId = eva ? pre : $gameTemp.randomCard(5); // 山札からランダムに1枚抽出
      this._NLMGdrawId = rId;
      const item  = $dataItems[rId];
      $gameTemp.NLMGcardPictureSet(item); // ピクチャをセット
      $gameTemp.reserveCommonEvent(NLMGparam.justBeforeDrawCommon); // ドロー直前イベント予約
      $gameTemp.appliVar(item, 5); // 該当変数更新
      this._NLMGpredictId = 0;
      this._NLMGdrawProc  = 4;
    }
    this._NLMGdrawFirst = false;
  };

  // カードドロー処理2（this._NLMGdrawProc = 4）
  BattleManager.NLMGcardDraw2 = function() {
    const descShow = NLMGparam.drawObtainShow === "true";
    const initHide = DataManager._NLMGdrawInitObtainOff && !$gameTroop.turnCount();
    if (descShow && !initHide) {
      $gameTemp.oneLineDisp(NLMGparam.drawObtainDesc, 2); // ドロー獲得デフォルト文章表示
    }
    $gameParty.moveCard(this._NLMGdrawId, 5, 6); // ドローカードを山札から手札へ移動
    $gameTemp.reserveCommonEvent(NLMGparam.justAfterDrawCommon); // ドロー直後イベント予約
    NLMGvar("draw", NLMGvar("draw") - 1); // ドロー変数を-1
    this._NLMGdrawProc = 3;
  };

  // カードドロー後処理1（this._NLMGdrawProc = 5）
  BattleManager.NLMGpostDraw1 = function() {
    NLMGvar("draw", Number(NLMGparam.baseDrawNum) || 0); // ドロー数変数を基本ドロー数に戻す
    $gameTemp.reserveCommonEvent(NLMGparam.postDrawCommon);　// ドロー終了後イベント予約
    this._NLMGdrawProc = 6;
  };

  // カードドロー後処理2（this._NLMGdrawProc = 6）
  BattleManager.NLMGpostDraw2 = function() {
    this.NLMGafterDo(); // 事後処理
    this._NLMGdrawProc = 7;
  };

  // 割込イベント事後処理
  BattleManager.NLMGafterDo = function() {
    $gameScreen.NLMGerasePictures(); // ピクチャ消去
    ImageManager._NLMGicon = ImageManager.iconWidth; // アイコン戻す
    if (this._NLMGdrawProc === 7 && !DataManager._NLMGnoBattleStatus) {
      SceneManager._scene._statusWindow.show(); // ステータスウインドウを戻す
    }
  };

  // コマンド入力中のアイテム・スキル消費の変更
  BattleManager.NLMGcancelConsumedItem = function(actor) {
    this._NLMGconsumedItems.pop();
    actor.gainMp(this._NLMGconsumedMp.pop()); // キャンセル時にコストを返す
    actor.gainSilentTp(this._NLMGconsumedTp.pop());
  };

  BattleManager.NLMGcancelUsedSkill = function(actor) {
    this._NLMGusedSkills.pop();
    actor.gainMp(this._NLMGusedMp.pop());     // キャンセル時にコストを返す
    actor.gainSilentTp(this._NLMGusedTp.pop());
  };

  BattleManager.NLMGnumConsumedItems = function(item) {
    let cNum  = 0;
    this._NLMGconsumedItems.forEach((cItem) => {
      if (cItem.id === item.id) cNum++;
    });
    return cNum
  };

  BattleManager.NLMGpaidCost = function() { // 戦闘最中かどうか（戦闘中のTP・MP消費をなくすため）
    return (this._phase === "action" || this._phase === "turn")
              && (NLMGparam.deckAnno || DataManager._NLMGimmediateConsume);
  };

  BattleManager.NLMGexecQuickSkill = function(item) { // TorigoyaMZ_QuickSkill.js が発動したか
    return this.isTpb() || TorigoyaQuickSkill &&
      (item.meta["QuickSkill"] || item.meta["ターン消費なし"] || item.meta["ターン消費無し"]);
  };

  // 毎ターン開始時（入力後）処理追加
  const _BattleManager_startTurn = BattleManager.startTurn;
  BattleManager.startTurn = function() {
    this._NLMGpartyCommand  = false;
    this._NLMGescapeFailure = false;
    this._NLMGlastSubject   = null;
    this._NLMGconsumedItems = [];
    this._NLMGconsumedTp = [];
    this._NLMGconsumedMp = [];
    this._NLMGusedSkills = [];
    this._NLMGusedTp = [];
    this._NLMGusedMp = [];
    $gameSystem.NLMGenemyIndex(-1);
    _BattleManager_startTurn.apply(this, arguments);
  };

  // アイテム・スキル使用前の処理追加
  const _BattleManager_updateTurn = BattleManager.updateTurn;
  BattleManager.updateTurn = function(timeActive) {
    if (!this._subject) NLMGvar("damage", 100);
    _BattleManager_updateTurn.apply(this, arguments);
  };

  const _BattleManager_processTurn = BattleManager.processTurn;
  BattleManager.processTurn = function() {
    const subject = this._subject;
    const action  = subject.currentAction();
    const item = action ? action.item() : null;
    this._NLMGlastSubject = subject;
    this._NLMGlastTarget  = this._NLMGtarget;
    this._NLMGlastItem    = item;
    if (item && !this._NLMGpreUse) {
      action.updateLastSubject(); // 直前に行動する予定のアクター・アイテムのIDを登録
      action.updateLastUsed();
      if (DataManager._NLMGdeleteLastTarget) {
        $gameTemp.setLastTargetEnemyIndex(0);
      }
      this.NLMGpreStartAction(item, subject);
    } else {
      if (this._NLMGpreUse === 2) {
        this.NLMGafterDo();
        this._NLMGpreUse = 3;
      }
      if (DataManager.isItem(item) && !$gameParty.hasItem(item)) {
        if (DataManager._NLMGerrorDisp) {
          const id = $gameTemp.iTypeExchange(item.id, "<", item.itypeId);
          console.error("戦闘でアイテム（ID:" + id + "）が使用直前で消失しています！　直前コモンイベントなどを見直して下さい");
        }
        if (DataManager._NLMGerrorThrough) this.startAction(); // エラーをスルー（デフォルトではしない）
        subject.NLMGremoveCurrentAction();
        return;
      }
      _BattleManager_processTurn.apply(this, arguments);
    }
  };

  BattleManager.NLMGpreStartAction = function(item, actor) {
    let evId = 0;
    this.NLMGnxcond(item, actor); // <nxcond>判定
    if (DataManager.isItem(item)) { // アイテムの場合
      const ncard4 = DataManager.NLMGcardData(item)[3];
      evId = ncard4 ? ncard4 : Number(NLMGparam.preUseCommon) || 0;
      $gameTemp.NLMGcardPictureSet(item); // ピクチャをセット
      const iType = item.itypeId;
      const itId  = $gameTemp.iTypeExchange(item.id, "<", iType);
      $gameTemp.appliVar($dataItems[itId], iType); // 該当変数更新
    } else { // スキルの場合
      evId = DataManager.NLMGskillData(item)[0];
      if (DataManager._NLMGskillPictureSet) {
        $gameTemp.NLMGcardPictureSet(item);
      }
      $gameTemp.appliVar(item, 11); // 該当変数更新
    }
    if (evId) {
      this.NLMGpreDo();
      $gameTemp.reserveCommonEvent(evId); // 使用直前コモンイベント予約
      this._NLMGpreUse = 2;
    } else {
      this._NLMGpreUse = 1;
    }
    if (this.NLMGexecQuickSkill(item)) this._logWindow.push("wait");
    this._phase = "turn"; // TorigoyaMZ_QuickSkill.js との競合対策
  };

  BattleManager.NLMGnxcond = function(item, actor) { // <nxcond>判定
    let rate = 1, sum = 0, sum1 = 1, sum2 = 0, self = false;
    const nxcn  = DataManager.NLMGnxcond(item);
    if (nxcn.length && !actor.isEnemy()) {
      const members  = $gameParty.battleMembers();
      const target   = this.NLMGnxcondTarget(nxcn[0]);
      const elements = [];
      for (let i = 3; i < nxcn.length; i++) {
        elements.push(nxcn[i]);
      }
      for (const element of elements) {
        let num  = this.NLMGnxcondCard(item, target, element); // カード判定
        switch (nxcn[0]) { // カード以外判定
          case "skill":
            if (actor.isLearnedSkill(element)) num = 1;
            self = true;
            break;
          case "class":
            if (actor._classId === element) self = true;
            for (const member of members) {
              if (member._classId === element) num++;
            }
            break;
          case "member": // _NLSIoldId は NLM_ItemToSummon.js 対策です
            if (actor._actorId === element || actor._NLSIoldId === element) self = true;
            for (const member of members) {
              if (member._actorId === element || member._NLSIoldId === element) num++;
            }
            break;
        }
        if (nxcn[1] === 1) sum1 *= num;
        if (nxcn[1] > 1)   sum2 += num;
      }
      sum = nxcn[1] === 1 ? sum1 : sum2;
      if (nxcn[1] < 3) sum = sum && elements.length ? 1 : 0;
      if (!target) sum = self ? sum : 0;
      const d = !DataManager._NLMGnxcondPower;
      rate = !sum ? 1 : nxcn[1] < 3 && d ? nxcn[2] * sum : nxcn[2] ** sum;
    }
    NLMGvar("damage", rate * 100);
  };

  BattleManager.NLMGnxcondTarget = function(nxcn0) {
    switch (nxcn0) {
      case "deck":
        return 5;
      case "hand":
        return 6;
      case "disc":
        return 7;
      case "board":
        return 8;
      default:
        return 0;
    }
  };

  BattleManager.NLMGnxcondCard = function(item, target, element) {
    let num = 0;
    if (target && element) {
      num = $gameTemp.cardnum(element, target);
      const id = DataManager.isItem(item) ?
                 $gameTemp.iTypeExchange(item.id, "<", item.itypeId) : 0;
      if (DataManager._NLCLnxcondExc && target === 6 && id === element && num) {
        num--; // 使用カードは含めない
      }
    }
    return num;
  };

  const _BattleManager_updateAction = BattleManager.updateAction;
  BattleManager.updateAction = function() {
    if (this._targets.length) {
      this._NLMGtarget = this._targets[0]; // MPシールド用
    }
    _BattleManager_updateAction.apply(this, arguments);
  };

  const _BattleManager_endAction = BattleManager.endAction;
  BattleManager.endAction = function() {
    this._NLMGpreUse = 0;
    this._action._NLMGeffectGainTp = false;
    _BattleManager_endAction.apply(this, arguments);
    if (DataManager._NLMGnxcondContinue) NLMGvar("damage", 100);
  };

  const _BM_processForcedAction = BattleManager.processForcedAction;
  BattleManager.processForcedAction = function() {
    if (this._actionForcedBattler) {
      const subject = this._actionForcedBattler;
      const action  = subject.currentAction();
      const item    = action ? action.item() : null;
      if (item) this.NLMGnxcond(item, subject); // <nxcond>判定
      if (this._NLMGpreUse === 2) { // TorigoyaMZ_QuickSkill.js との競合対策
        if (this._subject) {
          this.endBattlerActions(this._subject);
        }
        this._subject = subject;
        this._actionForcedBattler = null;
        this.startAction();
        subject.NLMGremoveCurrentAction(); // 変更
        return;
      }
    }
    _BM_processForcedAction.apply(this, arguments);
  };

  // 戦闘終了チェック修正
  const _BM_checkBattleEnd = BattleManager.checkBattleEnd;
  BattleManager.checkBattleEnd = function() {
    const eva = DataManager._NLMGfinishCommonEvent && $gameTemp.isCommonEventReserved();
    return eva ? false : _BM_checkBattleEnd.call(this);
  };

  // 逃走失敗処理追加
  const _BM_onEscapeFailure = BattleManager.onEscapeFailure
  BattleManager.onEscapeFailure = function() {
    _BM_onEscapeFailure.apply(this, arguments);
    this._NLMGescapeFailure = true;
  };

  // 戦闘終了後処理
  const _BM_updateBattleEnd = BattleManager.updateBattleEnd;
  BattleManager.updateBattleEnd = function() {
    this.NLMGbattleEnd(); // 追加
    _BM_updateBattleEnd.apply(this, arguments);
  };

  BattleManager.NLMGbattleEnd = function() {
    this._NLMGlastSubject = null;
    for (let i=6; i<=8; i++) {
      $gameParty.allMoveCard(i, 5); // 手札・捨札・場札をすべてデッキへ移動
    }
    if (NLMGparam.deckRecovery === "true") this.NLMGdeckRecovery();
    $gameTemp.reserveCommonEvent(NLMGparam.battleEndCommon); // 戦闘終了後イベント予約
    NLMGvar("damage", 100);
    this._NLMGlastItem = null;
    this._NLMGautosave = true;
  };

  BattleManager.NLMGdeckRecovery = function() { // デッキを復元
    $gameParty.allMoveCard(5, 0); // デッキを全消去
    const ids  = this._NLMGdeckSaveId;
    const nums = this._NLMGdeckSaveNum;
    for (let i=0; i < ids.length; i++) {
      $gameParty.gainItem($dataItems[ids[i]], nums[i]);
    }
  };

  // ターン終了時にHandState等の漏れをチェック（NLM_ItemToSummon.js対策）
  BattleManager.NLMGcheckState = function() {
    for (let i = 1; i <= NLMGitemMaxNum; i++) {
      const data = $dataItems[i];
      const stateId6 = parseInt(data.meta["HandState"])  || 0;
      const stateId8 = parseInt(data.meta["BoardState"]) || 0;
      if (stateId6 && $gameTemp.cardnum(i,6)) { // HandStateの手札があれば
        this.NLMGallAddState(stateId6);
      }
      if (stateId8 && $gameTemp.cardnum(i,8)) { // BoardStateの場札があれば
        this.NLMGallAddState(stateId8);
      }
    }
  };

  BattleManager.NLMGallAddState = function(stateId) {
    $gameParty.members().forEach((actor) => {
      if (!actor.isStateAffected(stateId)) actor.addState(stateId);
    });
  };

  // カード獲得時にステートをかける（←$gameParty.gainCard）
  BattleManager.NLMGaddState = function(item, iType) {
    const iMeta = iType === 6 ? "HandState" : "BoardState";
    const stateId = parseInt(item.meta[iMeta]) || 0;
    let writtenLog = null;
    if (stateId > 0) {
      $gameParty.members().forEach((actor) => {
        if (!actor.isStateAffected(stateId)) {
          actor.addState(stateId);
          if (this.NLMGstateLog()) {
            writtenLog = this.NLMGaddLog(stateId, 1, actor);
          }
        }
      });
      if (writtenLog) {
        this._logWindow.push("wait");
        this._logWindow.push("clear");
      }
    }
  };

  // カードを捨てたらステートを解除（←$gameParty.gainCard）
  BattleManager.NLMGremoveState = function(item, iType) {
    const iMeta = iType === 6 ? "HandState" : "BoardState";
    const stateId = parseInt(item.meta[iMeta]) || 0;
    let writtenLog = null;
    if (stateId > 1 && !this.NLMGcheckSameState(stateId)) {
      $gameParty.members().forEach((actor) => {
        if (actor.isStateAffected(stateId)) {
          actor.removeState(stateId);
          if (this.NLMGstateLog()) {
            writtenLog = this.NLMGaddLog(stateId, 4, actor);
          }
        }
      });
      if (writtenLog) {
        this._logWindow.push("wait");
        this._logWindow.push("clear");
      }
    }
  };

  BattleManager.NLMGcheckSameState = function(stateId) {
    let sameState = false;
    for (let i = 1; i <= NLMGitemMaxNum; i++) {
      const data = $dataItems[i];
      const stateId6 = parseInt(data.meta["HandState"])  || 0;
      const stateId8 = parseInt(data.meta["BoardState"]) || 0;
      if ((stateId6 === stateId && $gameTemp.cardnum(i,6))
          || (stateId8 === stateId && $gameTemp.cardnum(i,8))) {
        sameState = true;
        break;
      }
    }
    return sameState;
  }; // 同じステートを指定するカードが残っているか判定

  BattleManager.NLMGstateLog = function() {
    return $gameParty.inBattle() && this._phase !== "battleEnd"
             && !DataManager._NLMGnoLogState;
  };

  BattleManager.NLMGaddLog = function(stateId, mesId, actor) {
    const state = $dataStates[stateId];
    const sText = mesId === 1 ? state.message1 : state.message4;
    if (sText) {
      this._logWindow.push("addText", sText.format(actor.name()));
    }
    return sText
  };

// PluginManager関係（プラグインコマンド処理）
  PluginManager.registerCommand(pluginName, "addDeck", args => { // デッキに加える
    const items = DataManager.NLMstruct(args.items);
    DataManager.NLMGaddDeckArr(items, args.onlyOffDeck === "true");
    if (args.overCheck === "true") $gameTemp.deckOverCheck();
  });

  PluginManager.registerCommand(pluginName, "removeDeck", args => { // デッキから外す
    const items = DataManager.NLMstruct(args.items);
    items.forEach((array) => {
      const id  = Number(array.Id)  || 0;
      const num = Number(array.Num) || 0;
      PluginManager.NLMGremoveDeck(id, num, args.forcedDelete === "true");
    });
  });

  PluginManager.NLMGremoveDeck = function(id, num, forcedDelete) { // デッキから外す処理
    const deckNum = $gameTemp.cardnum(id, 5);
    const loseNum = num > deckNum ? deckNum : num;
    if (id && $dataItems[id].itypeId === 1 && loseNum) {
      $gameParty.loseCard(id, loseNum, 5);
      if (!forcedDelete) {
        $gameParty.gainCard(id, loseNum, 1);
      }
    }
  };

  PluginManager.registerCommand(pluginName, "moveCard", args => { // カードの移動
    const cId = PluginManager.NLMGvariables(args.idVariable, args.itemId);
    const fromItype = PluginManager.NLMGiType(args.fromItype);
    const toItype   = PluginManager.NLMGiType(args.toItype);
    const item = $dataItems[cId];
    $gameParty.moveCard(cId, fromItype, toItype);
    if (args.pictureSet === "true") $gameTemp.NLMGcardPictureSet(item);
    $gameTemp.appliVar(item, fromItype);
  });

  PluginManager.NLMGvariables = function(varId, constant) {
    const vId = Number(varId);
    return Number(vId ? $gameVariables.value(vId) : constant) || 0;
  };

  PluginManager.NLMGiType = function(name) {
    switch(name) {
      case "山札(デッキ)":
        return 5;
      case "手札":
        return 6;
      case "捨札":
        return 7;
      case "場札":
        return 8;
      case "デッキ外":
        return 1;
      case "大事なもの":
        return 2;
      case "隠しアイテムA":
        return 3;
      case "隠しアイテムB":
        return 4;
      default:
        return 0;
    }
  };

  PluginManager.registerCommand(pluginName, "allMoveCard", args => { // カードの全移動
    const fromItype = PluginManager.NLMGiType(args.fromItype);
    const toItype   = PluginManager.NLMGiType(args.toItype);
    $gameParty.allMoveCard(fromItype, toItype);
    if (args.shuffleSE === "true") $gameTemp.NLMGshuffleSE();
  });

  PluginManager.registerCommand(pluginName, "gainCard", args => { // カード増加
    let iType   = PluginManager.NLMGiType(args.iType);
    const cId   = PluginManager.NLMGvariables(args.idVariable, args.itemId);
    const num   = PluginManager.NLMGvariables(args.numVariable, args.num);
    const item  = $dataItems[cId];
    const iTypD = item ? item.itypeId : 0;
    if (iTypD > 1 && iTypD < 5) {iType = iTypD;}
    $gameParty.gainCard(cId, num, iType);
    if (args.pictureSet === "true") $gameTemp.NLMGcardPictureSet(item);
    $gameTemp.appliVar(item, iType);
  });

  PluginManager.registerCommand(pluginName, "loseCard", args => { // カード減少
    let iType   = PluginManager.NLMGiType(args.iType);
    const cId   = PluginManager.NLMGvariables(args.idVariable, args.itemId);
    const num   = PluginManager.NLMGvariables(args.numVariable, args.num);
    const item  = $dataItems[cId];
    const iTypD = item ? item.itypeId : 0;
    if (iTypD > 1 && iTypD < 5) {iType = iTypD;}
    $gameParty.loseCard(cId, num, iType);
    if (args.pictureSet === "true") $gameTemp.NLMGcardPictureSet(item);
    $gameTemp.appliVar(item, iType);
  });

  PluginManager.registerCommand(pluginName, "deckOverCheck", args => { // デッキ超過チェック
    $gameTemp.deckOverCheck();
  });

  PluginManager.registerCommand(pluginName, "selectCard", args => { // カード選択
    const iType = PluginManager.NLMGiType(args.iType);
    if (iType) {
      const dis = PluginManager.NLMGdisableCard(args.disable);
      const eId = PluginManager.NLMGvariables(args.eIdVariable, args.elementId);
      $gameSystem.NLMGmatchCondition(args.matchCondition);
      $gameSystem.NLMGmatchElementId(eId);
      $gameSystem.NLMGmatchScript(args.script);
      $gameSystem.NLMGdisableCard(dis);
      $gameSystem.NLMGneedsNumber(args.numDisp === "true" ? 1 : 2);
      $gameSystem.NLMGeventItemCancel(args.cancel   === "true" ? 1 : 0);
      $gameSystem.NLMGeventCentering(args.centering === "true" ? 1 : 0);
      $gameSystem.NLMGpictureNeed(args.pictureSet   === "true" ? 1 : 0);
      $gameSystem.NLMGselectCard(iType);
    }
  });

  PluginManager.NLMGdisableCard = function(disable) {
    switch(disable) {
      case "選択不可（TP･MPコストを除く）":
        return 2;
      case "選択不可（TP･MPコストを含め）":
        return 3;
      default:
        return 1;
    }
  };

  PluginManager.registerCommand(pluginName, "randomCard", args => { // ランダムなカード抽出
    const iType = PluginManager.NLMGiType(args.iType);
    const elem  = args.matchCondition;
    const eId   = PluginManager.NLMGvariables(args.eIdVariable, args.elementId);
    const cId   = $gameTemp.randomCard(iType, elem, eId, args.script);
    const item  = $dataItems[cId];
    $gameVariables.setValue(args.varId, cId);
    if (args.pictureSet === "true") $gameTemp.NLMGcardPictureSet(item);
    $gameTemp.appliVar(item, iType);
  });

  PluginManager.registerCommand(pluginName, "predictDraw", args => { // 次ドロー予定
    const iId = PluginManager.NLMGvariables(args.idVariable, args.itemId);
    const cId = iId && $gameTemp.cardnum(iId, 5) ? iId : $gameTemp.randomCard(5);
    const item = $dataItems[cId];
    BattleManager._NLMGpredictId = cId;
    $gameVariables.setValue(args.idVariable, cId);
    if (args.pictureSet === "true") $gameTemp.NLMGcardPictureSet(item);
    $gameTemp.appliVar(item, 5);
  });

  PluginManager.registerCommand(pluginName, "gacha", args => { // ガチャ
    const times = Number(args.times) || NLMGvar("gacha") || 0;
    if (times && !$gameTemp.NLMGgachaStart()) {
      if (NLMGvar("gacha") !== times) {NLMGvar("gacha", times);}
      const price = PluginManager.NLMGvariables(args.priceVarId, args.price);
      const group = DataManager.NLMstruct(args.groups);
      const pVal  = DataManager.NLMstruct(args.pValues);
      const confR = PluginManager.NLMGvariables(args.rareVarId, args.confirmedRare);
      if ($gameParty.gold() >= price) {
        $gameParty.loseGold(price); // 料金支払い
        $gameTemp.NLMGgachaStartSet(1, group, pVal, confR);
      } else {
        $gameTemp.oneLineDisp(NLMGparam.shortGoldDesc, 2); // 料金不足文章表示
      }
    }
  });

  PluginManager.registerCommand(pluginName, "iconIdAndName", args => { // アイコンIDと名前代入
    const isItem = args.isItem === "true";
    const argId  = isItem ? args.itemId : args.skillId;
    const cId    = PluginManager.NLMGvariables(args.idVariable, argId);
    const item   = isItem ? $dataItems[cId] : $dataSkills[cId];
    $gameTemp.appliVar(item);
    if (args.pictureSet === "true") $gameTemp.NLMGcardPictureSet(item);
  });

  PluginManager.registerCommand(pluginName, "enableCard", args => { // 場札等の使用可否を変更
    const iType  = PluginManager.NLMGiType(args.iType);
    const itemId = PluginManager.NLMGvariables(args.idVariable, args.itemId);
    const itId   = $gameTemp.iTypeExchange(itemId, ">", iType);
    if (itId) {
      const enab = args.enableCard === "true";
      const occ  = iType === 5 ? (enab ? 0 : 2) : enab ? 1 : 3;
      $dataItems[itId].occasion   = occ;
      $dataItems[itId].consumable = args.consumableCard === "true";
    }
  });

  PluginManager.registerCommand(pluginName, "enemyIndex", args => { // 敵index強制
    let id = 0;
    const subject = BattleManager._NLMGlastSubject;
    const index   = $gameTemp._lastActionData[3] - 1;
    if (subject && subject.isEnemy() && index >= 0) {
      $gameSystem.NLMGenemyIndex(index);
      id = $gameTroop.members()[index].enemyId();
    } else {
      if (DataManager._NLMGerrorDisp) {
        console.error("「敵強制指定」で敵を認知できませんでした");
      }
    }
    $gameVariables.setValue(args.idVariable, id);
  });

  PluginManager.registerCommand(pluginName, "damageWithoutShield", args => { // シールド無視のHP減少
    const actorId = PluginManager.NLMGvariables(args.actorVarId, args.actorId);
    const damage  = PluginManager.NLMGvariables(args.damageVarId, args.damage);
    const allowD  = args.allowDeath === "true";
    if (actorId) {
      $gameTemp.actorDamageWithoutShield(damage, actorId, allowD);
    } else {
      $gameTemp.partyDamageWithoutShield(damage, allowD);
    }
  });

  PluginManager.registerCommand(pluginName, "battleStatus", args => { // 戦闘ステータスウインドウ操作
    if ($gameParty.inBattle()) {
      if (args.operation === "表示(show)") {
        SceneManager._scene._statusWindow.show();
      } else {
        SceneManager._scene._statusWindow.hide();
      }
    }
  });

  PluginManager.registerCommand(pluginName, "iconDotChange", args => { // アイコンドット変更
    let dot = ImageManager.iconWidth;
    if (args.iconDot === "プラグインでの設定値") dot = NLMGparam.iconDot;
    if (args.iconDot === "下記の値") dot = Number(args.tempDot) || 32;
    ImageManager._NLMGicon = dot;
  });

// Game_Temp関係（独自関数を主に設定）
  Game_Temp.prototype.cardnum = function(id, iType, element, eId, script) { // idのiType中のカードを数える（idはデッキ外ID）
    if (id) {
      const de = $dataItems[this.iTypeExchange(id, ">", iType)];
      return de && de.itypeId === iType && this.NLMGmatchCondition(de, element, eId, script)
              ? $gameParty.NLMGnumItemsForShow(de) : 0;
    } else { // idが0の時は総数を算出
      const max   = NLMGitemMaxNum;
      const start = iType > 4 ? max * (iType - 4) + 1 : 1;
      let sum = 0;
      for (let i = start; i < start + max; i++) {
        const d = $dataItems[i];
        sum += d.itypeId === iType && this.NLMGmatchCondition(d, element, eId, script)
                ? $gameParty.NLMGnumItemsForShow(d) : 0;
      }
      return sum;
    }
  };

  Game_Temp.prototype.NLMGmatchCondition = function(item, element, eId, script) {
    if (element === "icon")    return item.iconIndex === eId;
    if (element === "element") return item.damage.type && item.damage.elementId === eId;
    if (element === "group")   return DataManager.NLMGcardData(item)[0] === eId;
    if (element === "rare")    return DataManager.NLMGcardData(item)[1] === eId;
    if (element === "script")  return this.NLMGevalFormula(script, item);
    return true;
  }

  Game_Temp.prototype.iTypeExchange = function(id, arrow, iType) { // 真のIDとデータベースIDを相互変換
    if (!id) return 0;
    const it = $dataItems[id].itypeId;
    if ((arrow === ">" && it > 1) || (arrow === "<" && (it < 5 || it !== iType)))
      {return id;}
    const max  = NLMGitemMaxNum; // NLM_CardLayoutMZ.jsとの違い
    const sign = arrow === "<" ? -1 : 1;
    let itId = id;
    switch (iType) {
      case 5: // デッキ（山札）
        itId += max * sign;
        break;
      case 6: // 手札
        itId += 2 * max * sign;
        break;
      case 7: // 捨札
        itId += 3 * max * sign;
        break;
      case 8: // 場札
        itId += 4 * max * sign;
        break;
    }
    return itId;
  };

  Game_Temp.prototype.ncard = function(id, n) { // アイテムメモ <ncard> の n番目の値を取得
    if (id > 0 && n > 1) {
      return DataManager.NLMGcardData($dataItems[id])[n-1];
    }
    return 0;
  };

  Game_Temp.prototype.getTPcost = function(id, isSkill) { // TPコストを取得（消費率の計算前）
    const item = isSkill ? $dataSkills[id] : $dataItems[id];
    if (!item) return 0;
    return isSkill ? item.tpCost : this.itemTpCost(item);
  };

  Game_Temp.prototype.getMPcost = function(id, isSkill) { // MPコストを取得（消費率の計算前）
    const item = isSkill ? $dataSkills[id] : $dataItems[id];
    if (!item) return 0;
    return isSkill ? item.mpCost : this.itemMpCost(item);
  };

  Game_Temp.prototype.targetIsDead = function(index) { // 直前の敵を倒した時に真を返す
    if (!index) {index = this._lastActionData[5] - 1;}
    return index >= 0 ? $gameTroop.members()[index].isDead() : false;
  };

  Game_Temp.prototype.targetIsHit = function(index) { // 直前の敵にHPダメージを与えた時に真を返す
    if (!index) {index = this._lastActionData[5] - 1;}
    return index >= 0 ? $gameTroop.members()[index].isHit()  : false;
  };

  Game_Temp.prototype.deckOverCheck = function() { // デッキ超過チェック
    if (!$gameParty.inBattle()) DataManager.NLMGdeckCheck();
  };

  Game_Temp.prototype.itemTpCost = function(item) {
    if (!item) return 0;
    return this.NLMGevalFormula(item.meta["TPcost"], item);
  };

  Game_Temp.prototype.itemMpCost = function(item) {
    if (!item) return 0;
    return this.NLMGevalFormula(item.meta["MPcost"], item);
  };

  Game_Temp.prototype.NLMGevalFormula = function(formula, item) {
    if (!formula) return 0;
    try {
      const v = $gameVariables._data; // 変数値に置き換え
      const V = $gameVariables._data;
      const cId = this.iTypeExchange(item.id, "<", item.itypeId); // IDに置き換え
      const value = Math.max(eval(formula), 0);
      return isNaN(value) ? 0 : value;
    } catch (e) {
      return 0;
    }
  };

  Game_Temp.prototype.appliVar = function(item, cItype) { // 該当変数の代入
    if (item) {
      const iType = cItype ? cItype : DataManager.NLMGcategolize(item);
      NLMGvar("appliId",    item.id);
      NLMGvar("appliIcon",  item.iconIndex);
      NLMGvar("appliName",  item.name || " ");
      NLMGvar("appliItype", iType);
    } else {
      NLMGvar("appliId",    0);
      NLMGvar("appliIcon",  0);
      NLMGvar("appliName",  " ");
      NLMGvar("appliItype", 0);
    }
  };

  Game_Temp.prototype.icate = function(iType) { // 開いているitemWindowのカテゴリーがiTypeなら真を返す
    const cate = SceneManager._scene._itemWindow._category;
    switch(iType) {
      case 5:
        return cate === "deck";
      case 6:
        return cate === "hand";
      case 7:
        return cate === "disc";
      case 8:
        return cate === "board";
      case 9:
        return cate === "weapon";
      case 10:
        return cate === "armor";
      case 1:
        return cate === "item";
      case 2:
        return cate === "keyItem";
      default:
        return false;
    }
  };

  Game_Temp.prototype.actorDamageWithoutShield = function(damage, actorId, allowDeath) {
    const actor = $gameParty.members().find(actor => actor.actorId() === actorId);
    if (actor && actor.isAlive()) {
      if (!allowDeath && actor.hp <= damage) {
        damage = actor.hp - 1;
      }
      actor.gainHpWithoutShield(-damage);
      if (actor.isDead()) {
        actor.performCollapse();
      }
    }
  };

  Game_Temp.prototype.partyDamageWithoutShield = function(damage, allowDeath) {
    for (const actor of $gameParty.members()) {
      this.actorDamageWithoutShield(damage, actor.actorId(), allowDeath);
    }
  };

  Game_Temp.prototype.enemyDamageWithoutShield = function(damage, index, allowDeath) {
    const enemy = $gameTroop.members()[index];
    if (enemy && enemy.isAlive()) {
      if (!allowDeath && enemy.hp <= damage) {
        damage = enemy.hp - 1;
      }
      enemy.gainHpWithoutShield(-damage);
      if (enemy.isDead()) {
        enemy.performCollapse();
      }
    }
  };

  Game_Temp.prototype.troopDamageWithoutShield = function(damage, allowDeath) {
    for (const enemy of $gameTroop.members()) {
      this.enemyDamageWithoutShield(damage, enemy.index(), allowDeath);
    }
  };

  Game_Temp.prototype.oneLineDisp = function(desc, pos) { // 一行表示
    if (desc) {
      $gameMessage.setBackground(1);
      $gameMessage.setPositionType(pos);
      $gameMessage.add();
      $gameMessage.add("\x1b>" + desc);
    }
  };

  Game_Temp.prototype.randomCard = function(iType, element, eId, script) { // ランダムで1枚抽出してID(デッキ外)を返す
    const iTypeMax = this.cardnum(0, iType, element, eId, script);  // 種別総数
    if (!iTypeMax) return 0;
    const rand  = Math.floor(Math.random() * iTypeMax) + 1; // 乱数発生
    const data  = $dataItems;
    const max   = NLMGitemMaxNum;
    const start = iType > 4 ? max * (iType - 4) + 1 : 1;
    let j = rand;
    for (let i = start; i < start + max; i++) {
      if (data[i].itypeId === iType && this.NLMGmatchCondition(data[i], element, eId, script)) {
        j -= $gameParty.NLMGnumItemsForShow(data[i]);
        if (j <= 0) return this.iTypeExchange(i, "<", iType);
      }
    }
    return 0;
  };

  Game_Temp.prototype.NLMGshuffleSE = function() { // シャッフル時SE演奏
    const file = NLMGparam.shuffleSEfile;
    const vol  = Number(NLMGparam.shuffleSEVolume) || 90;
    const pit  = Number(NLMGparam.shuffleSEPitch)  || 100;
    if (file) {
      AudioManager.playSe({"name":file, "volume":vol, "pitch":pit, "pan":0});
    }
  };

  // ピクチャ自動セット（NLM_CardLayoutMZ.jsプラグイン機能へ丸投げ）
  Game_Temp.prototype.NLMGcardPictureSet = function(item) {
    if (item && NLM_CardLayout) {
      const pId   = NLMGparam.picId;
      const file  = NLCLparam.reverseComFile;
      const tr    = !DataManager.isSkill(item);
      const scale = Number(NLCLparam.reverseAutoScale) || 4;
      $gameScreen.cardPictureSet(item, pId);
      $gameScreen.reversePictureSet(file, pId+1, scale, tr);
    } else {
      $gameSwitches.setValue(NLCLparam.successSwId, false);
    }
  };

  // カードガチャ準備
  const _Game_Temp_initialize = Game_Temp.prototype.initialize;
  Game_Temp.prototype.initialize = function() {
    _Game_Temp_initialize.apply(this, arguments);
    this._NLMGgachaStart  = 0;
    this.NLMGgachaClear();
  };

  Game_Temp.prototype.NLMGgachaClear = function() {
    this._NLMGgachaGroup  = [];
    this._NLMGgachaPValue = [];
    this._NLMGgachaConfR  = 0;
  };

  Game_Temp.prototype.NLMGgachaStart = function() {
    return this._NLMGgachaStart;
  };

  Game_Temp.prototype.NLMGgachaConfR = function() {
    return this._NLMGgachaConfR;
  };

  Game_Temp.prototype.NLMGgachaStartSet = function(tr, group, pValue, confR) {
    this._NLMGgachaStart = tr;
    if (tr === 1) {
      this._NLMGgachaGroup  = group;
      this._NLMGgachaPValue = pValue;
      this._NLMGgachaConfR  = confR;
    } else if (!tr) {
      this.NLMGgachaClear();
    }
  };

  Game_Temp.prototype.NLMGrandomGacha = function(confirmed) {
    const pVal = this._NLMGgachaPValue;
    let rare = pVal === [] ? 0 : confirmed;
    if (!rare) {
      pVal.map((array) => {// pValを数値化
        array.Rare = Number(array.Rare) || 0;
        array.PVal = Number(array.PVal) || 0;
      });
      pVal.sort(function(a,b) { // pValをレア降順にソート
        if (a.Rare > b.Rare) return -1;
        if (a.Rare < b.Rare) return 1;
        return 0;
      });
      for (let i=0; i<pVal.length; i++) {
        if (Math.random() < pVal[i].PVal / 100) {
          rare = pVal[i].Rare; // 当選レア値決定
          break;
        }
      }
    }
    const group = this._NLMGgachaGroup;
    for (let r = rare; r >= 0; r--) {
      const sum  = this.NLMGgachaLoop(group, r);
      const rand = Math.floor(Math.random() * sum) + 1;
      const item = this.NLMGgachaLoop(group, r, rand);
      if (item) return item; // 当選itemを返す
    }
    return null;
  };

  Game_Temp.prototype.NLMGgachaLoop = function(group, rare, rand) { 
    let sum = 0;
    let win = rand || 0;
    const leng = group.length;
    const all  = leng ? false : true;
    const loop = leng ? leng  : 1;
    for (let j=0; j < loop; j++) {
      const gr = parseInt(group[j]);
      const ir = this.NLMGgachaLoop2($dataItems, NLMGitemMaxNum + 1, rare, all, gr, sum, rand, win);
      if (rand && ir[1]) {
        return $dataItems[ir[1]];
      } else {
        sum = ir[0]
        win = ir[0];
      }
      if (DataManager._NLMGgachaContainWeapon) {
        const wr = this.NLMGgachaLoop2($dataWeapons, $dataWeapons.length, rare, all, gr, sum, rand, win);
        if (rand && wr[1]) {
          return $dataWeapons[wr[1]];
        } else {
          sum = wr[0]
          win = wr[0];
        }
      }
      if (DataManager._NLMGgachaContainArmor) {
        const ar = this.NLMGgachaLoop2($dataArmors, $dataArmors.length, rare, all, gr, sum, rand, win);
        if (rand && ar[1]) {
          return $dataArmors[ar[1]];
        } else {
          sum = ar[0];
        }
      }
    }
    return rand ? null : sum;
  };

  Game_Temp.prototype.NLMGgachaLoop2 = function(item, max, rare, all, gr, sum, rand, win) {
    for (let id=1; id < max; id++) {
      if (item[id]) {
        const ncard = DataManager.NLMGcardData(item[id]); 
        if (ncard[1] === rare && ncard[0] > 0 && (all ? true : ncard[0] === gr)) {
          sum++;
          if (rand) {
            win--;
            if (!win) return [0, id]; // 当選したIDを返す
          }
        }
      }
    }
    return [rand ? win : sum, 0]
  }

// Game_System関係（プラグインコマンド「カード選択」「敵強制指定」の入力補助など）
  const _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function() {
    _Game_System_initialize.apply(this, arguments);
    this._isNLMcardGame   = true;
    this._NLMGpictureNeed = 0
    this._NLMGenemyIndex  = -1;
    this._NLMGenemyImage  = 0;
    this.NLMGeventItemClear();
  }

  Game_System.prototype.NLMGitemMaxNum = function() {
    return NLMGitemMaxNum;
  };

  Game_System.prototype.NLMGtcrEx = function() { // TPチャージ率をTP消費率に変換するか
    const ex = DataManager._NLMGtcrEx;
    return (ex === 1 && NLMGparam.damageTP === "0") || ex === 2;
  };

  Game_System.prototype.gachaItem = function(item) { // ガチャ当選item
    if (item || item === null) this._NLMGgachaItem = item;
    return this._NLMGgachaItem;
  };

  Game_System.prototype.NLMGselectCard = function(iType) {
    if (iType !== undefined) this._NLMGselectCard = iType;
    return this._NLMGselectCard;
  };

  Game_System.prototype.NLMGmatchCondition = function(element) {
    if (element !== undefined) this._NLMGmatchCondition = element;
    return this._NLMGmatchCondition;
  };

  Game_System.prototype.NLMGmatchElementId = function(eId) {
    if (eId !== undefined) this._NLMGmatchElementId = eId;
    return this._NLMGmatchElementId;
  };

  Game_System.prototype.NLMGmatchScript = function(script) {
    if (script !== undefined) this._NLMGmatchScript = script;
    return this._NLMGmatchScript;
  };

  Game_System.prototype.NLMGeventCentering = function(num) {
    if (num !== undefined) this._NLMGeventCentering = num;
    return this._NLMGeventCentering;
  };

  Game_System.prototype.NLMGneedsNumber = function(num) {
    if (num !== undefined) this._NLMGneedsNumber = num;
    return this._NLMGneedsNumber;
  };

  Game_System.prototype.NLMGeventItemCancel = function(num) {
    if (num !== undefined) this._NLMGeventItemCancel = num;
    return this._NLMGeventItemCancel;
  };

  Game_System.prototype.NLMGdisableCard = function(num) {
    if (num !== undefined) this._NLMGdisableCard = num;
    return this._NLMGdisableCard;
  };

  Game_System.prototype.NLMGpictureNeed = function(num) {
    if (num !== undefined) this._NLMGpictureNeed = num;
    return this._NLMGpictureNeed;
  };

  Game_System.prototype.NLMGenemyIndex = function(index) {
    if (index !== undefined) this._NLMGenemyIndex = index;
    return this._NLMGenemyIndex;
  };

  Game_System.prototype.NLMGenemyImage = function(num) {
    if (num !== undefined) this._NLMGenemyImage = num;
    return this._NLMGenemyImage;
  };

  Game_System.prototype.NLMGeventItemClear = function() {
    this.NLMGselectCard(0);
    this.NLMGmatchCondition("all");
    this.NLMGmatchElementId(0);
    this.NLMGmatchScript("");
    this.NLMGeventCentering(0);
    this.NLMGneedsNumber(0);
    this.NLMGdisableCard(0);
    this.NLMGeventItemCancel(1);
  };

// Game_Message関係（プラグインコマンド「カード選択」の補助）
  const _GM_setItemChoice = Game_Message.prototype.setItemChoice;
  Game_Message.prototype.setItemChoice = function(variableId, itemType) {
    _GM_setItemChoice.apply(this, arguments);
    if ($gameSystem.NLMGselectCard()) {
      this._itemChoiceItypeId = $gameSystem.NLMGselectCard();
    }
  };

// Game_Variables関係
  const _Game_Variables_setValue = Game_Variables.prototype.setValue;
  Game_Variables.prototype.setValue = function(variableId, value) {
    const maxId = DataManager._NLMGdeckMaxVarId;
    if (maxId && variableId === maxId) {
      const preValue = this.value(maxId);
      _Game_Variables_setValue.apply(this, arguments);
      if (preValue > value && !DataManager._NLMGnoDeckCheck) {
        $gameTemp.deckOverCheck(); // 最大数変数が減少するとデッキ超過になるおそれあり
      }
    } else {
      _Game_Variables_setValue.apply(this, arguments);
    }
  };

// Game_Screen関係（自動ピクチャ消去）
  Game_Screen.prototype.NLMGerasePictures = function() {
    const pId = NLMGparam.picId;
    if (NLM_CardLayout && pId) {
      this.erasePicture(pId);
      if (NLCLparam.reverseComFile) {
        this.erasePicture(pId + 1);
      }
    }
  };

// Game_Action関係
  const _Game_Action_apply = Game_Action.prototype.apply;
  Game_Action.prototype.apply = function(target) {
    target.isHit(-1); // isHit初期化
    _Game_Action_apply.apply(this, arguments);
  };

  const _GAction_makeDamageValue = Game_Action.prototype.makeDamageValue;
  Game_Action.prototype.makeDamageValue = function(target, critical) { // ダメージ倍率％変数反映
    const value = _GAction_makeDamageValue.apply(this, arguments);
    target.isHit(this.NLMGisHit(value) ? -2 : -1); // isHit判定
    return DataManager._NLMGfinalDamage ? Math.round(value * NLMGvar("damage") / 100) : value;
  };

  Game_Action.prototype.NLMGisHit = function(value) {
    return this.isHpEffect() && value > 0; // HPダメージ > 0 で真を返す
  };

  Game_Action.prototype.evalDamageFormula = function(target) { // ダメージ倍率％変数反映
    try {
      const item = this.item();
      const cId = $gameTemp.iTypeExchange(item.id, "<", item.itypeId); // cIdを使えるように
      const a = this.subject(); // eslint-disable-line no-unused-vars
      const b = target; // eslint-disable-line no-unused-vars
      const v = $gameVariables._data; // eslint-disable-line no-unused-vars
      const V = $gameVariables._data; // 追加
      const sign = [3, 4].includes(item.damage.type) ? -1 : 1;
      const eV   = Math.max(eval(item.damage.formula), 0) * sign;
      const value = DataManager._NLMGfinalDamage ? eV : eV * NLMGvar("damage") / 100;
      return isNaN(value) ? 0 : value;
    } catch (e) {
      return 0;
    }
  };

  const _Game_Action_applyGuard = Game_Action.prototype.applyGuard;
  Game_Action.prototype.applyGuard = function(damage, target) {
    if (DataManager._NLMGskillSVmotion) { // isGuard を書き換えているため
      return damage / (damage > 0 && target.isGuard(true) ? 2 * target.grd : 1);
    } else {
      return _Game_Action_applyGuard.apply(this, arguments);
    }
  };

  const _GAction_itemEffectCommonEvent = Game_Action.prototype.itemEffectCommonEvent;
  Game_Action.prototype.itemEffectCommonEvent = function(target, effect) {
    _GAction_itemEffectCommonEvent.apply(this, arguments);
    if (this.isCertainHit() && DataManager._NLMGnoLogFailure) {
      this.makeSuccess(target); // 必中のアイテム・スキルにコモンイベントを入れると成功扱い
    }
  };

  const _GAction_applyItemUserEffect = Game_Action.prototype.applyItemUserEffect;
  Game_Action.prototype.applyItemUserEffect = function() {
    if ($gameSystem.NLMGtcrEx()) { // TPチャージ率をTP消費率に変換する場合
      const value = Math.floor(this.item().tpGain); // tcr削除
      if (value) this.subject().gainSilentTp(value);
    } else {
      _GAction_applyItemUserEffect.apply(this, arguments);
    }
  };

  const _GAction_updateLastUsed = Game_Action.prototype.updateLastUsed
  Game_Action.prototype.updateLastUsed = function() {
    _GAction_updateLastUsed.apply(this, arguments);
    const item = this.item();
    if (DataManager.isItem(item)) {
      const iType = item.itypeId;
      const id = $gameTemp.iTypeExchange(item.id, "<", iType); // 「直前に使用したアイテムID」をiType変換
      $gameTemp.setLastUsedItemId(id);
    }
  };

  // 計算式で独自関数を使用可能にする
  Game_Action.prototype.cardnum = function(id, iType, element, eId) {
    return $gameTemp.cardnum(id, iType, element, eId);
  };

  Game_Action.prototype.ncard = function(id, n) {
    return $gameTemp.ncard(id, n);
  };

  Game_Action.prototype.getTPcost = function(id, isSkill) {
    return $gameTemp.getTPcost(id, isSkill);
  };

  Game_Action.prototype.getMPcost = function(id, isSkill) {
    return $gameTemp.getMPcost(id, isSkill);
  };

  Game_Action.prototype.targetIsDead = function(index) {
    return $gameTemp.targetIsDead(index);
  };

  Game_Action.prototype.targetIsHit = function(index) {
    return $gameTemp.targetIsHit(index);
  };

// Game_BattlerBase関係
  const _GBB_initMembers = Game_BattlerBase.prototype.initMembers;
  Game_BattlerBase.prototype.initMembers = function() {
    _GBB_initMembers.apply(this, arguments);
    this._NLMGisHit    = false;
    this._NLMGguarding = false;
    this._NLMGnoGuard  = this.NLMGnoGuard();
  };

  Game_BattlerBase.prototype.isHit = function(num) { // 直前攻撃が当たったかを返す独自関数
    if (num === -1) this._NLMGisHit = false;
    if (num === -2) this._NLMGisHit = true;
    return this._NLMGisHit;
  };

  Game_BattlerBase.prototype.NLMGnoGuard = function() { // スキル2番が防御モーションでなければtrue
    const gskl = this.guardSkillId();
    const data = DataManager.NLMGskillData($dataSkills[gskl]);
    const dat1 = Number(data[1]) || 0;
    const dat2 = data[2] ? data[2].replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"") : null;
    const sklm = DataManager._NLMGskillSVmotion;
    const eva1 = !dat1 && dat2 === "guard";
    const eva2 = !dat1 && !dat2;
    return sklm && !(eva1 || eva2);
  };

  const _GBB_isGuard = Game_BattlerBase.prototype.isGuard;
  Game_BattlerBase.prototype.isGuard = function(tr) {
    if (DataManager._NLMGguarding && this._NLMGguarding && !tr) {
      return true;  // 防御ステートがなくても防御モーションスキルなら防御姿勢継続（隠し）
    } else if (this._NLMGnoGuard && !tr) {
      return false; // スキル2番<nskill>で"guard"以外を指定なら防御姿勢はとらない
    } else {
      return _GBB_isGuard.apply(this, arguments); // 防御ステート中は防御姿勢（デフォルト）
    }
  };

  const _GBB_skillTpCost = Game_BattlerBase.prototype.skillTpCost;
  Game_BattlerBase.prototype.skillTpCost = function(skill) {
    if ($gameSystem.NLMGtcrEx()) { // TPチャージ率をTP消費率に変換する場合
      const cost = skill.tpCost * this.tcr
      return DataManager._NLMGtcrRound ? Math.round(cost) : Math.floor(cost);
    } else {
      return _GBB_skillTpCost.apply(this, arguments);
    }
  };

// Game_Battler関係
  const _Game_Battler_onTurnEnd = Game_Battler.prototype.onTurnEnd;
  Game_Battler.prototype.onTurnEnd = function() {
    _Game_Battler_onTurnEnd.apply(this, arguments);
    this._NLMGguarding = false;
  };

  const _GB_isGuardWaiting = Game_Battler.prototype.isGuardWaiting;
  Game_Battler.prototype.isGuardWaiting = function() { // 防御待ち姿勢の中止
    return this._NLMGnoGuard ? false : _GB_isGuardWaiting.call(this);
  };

  const _GB_removeCurrentAction = Game_Battler.prototype.removeCurrentAction;
  Game_Battler.prototype.NLMGremoveCurrentAction = function() {
    _GB_removeCurrentAction.apply(this, arguments);
  }; // TorigoyaMZ_QuickSkill.jsとの競合対策

// MPシールド化
  const _Game_Battler_gainHp = Game_Battler.prototype.gainHp;
  if (NLMGparam.mpShield === "true") {
    Game_Battler.prototype.gainHp = function(value) {
      const item = BattleManager._NLMGlastItem;
      const pene = item ? !item.meta["MPpenetrate"] : true;
      if (value < 0 && this.mp && pene) {
        this.NLMGgainShield(value);
      } else {
        _Game_Battler_gainHp.apply(this, arguments);
      }
    };

    const _GB_regenerateHp = Game_Battler.prototype.regenerateHp;
    Game_Battler.prototype.regenerateHp = function() {
      if (DataManager._NLMGregenerateHpChange) {
        _GB_regenerateHp.apply(this, arguments);
      } else { // HP再生率ではMPシールド無視
        const minRecover = -this.maxSlipDamage();
        const value = Math.max(Math.floor(this.mhp * this.hrg), minRecover);
        if (value !== 0) {
          this.gainHpWithoutShield(value); // 改変
        }
      }
    };

    const _GA_executeFloorDamage = Game_Actor.prototype.executeFloorDamage;
    Game_Actor.prototype.executeFloorDamage = function() {
      if (DataManager._NLMGfloorDamageChange) {
        _GA_executeFloorDamage.apply(this, arguments);
      } else { // ダメージ床ではMPシールド無視
        const floorDamage = Math.floor(this.basicFloorDamage() * this.fdr);
        const realDamage = Math.min(floorDamage, this.maxFloorDamage());
        this.gainHpWithoutShield(-realDamage); // 改変
        if (realDamage > 0) { // 
          this.performMapDamage();
        }
      }
    };

    Game_Interpreter.prototype.changeHp = function(target, value, allowDeath) {
      if (target.isAlive()) {
        if (!allowDeath && target.hp + target.mp <= -value) { // MP値を考慮
          value = 1 - target.hp - target.mp;
        }
        target.gainHp(value);
        if (target.isDead()) {
          target.performCollapse();
        }
      }
    };
  }

  Game_Battler.prototype.NLMGgainShield = function(value) {
    const target = BattleManager._NLMGtarget;
    const d = this.mp + value;
    if (d >= 0) {
      if (target && $gameParty.inBattle()) {
        $gameTemp.requestAnimation([target], NLMGparam.shieldAnime);
      }
      if (this.isActor() && DataManager._NLMGmpShieldGuard) {
        this.requestMotion("guard");
      }
      this.gainMp(value);
    } else {
      if (target && $gameParty.inBattle()) {
        $gameTemp.requestAnimation([target], NLMGparam.breakAnime);
      }
      this.gainMp(-this.mp);
      _Game_Battler_gainHp.call(this, d);
    }
  };

  Game_Battler.prototype.gainHpWithoutShield = function(value) {
    _Game_Battler_gainHp.apply(this, arguments);
  };

// TP制御関係
  if (NLMGparam.maxTP !== 100) { // TP最大値
    Game_BattlerBase.prototype.maxTp = function() {
      return NLMGparam.maxTP;
    };

    Game_Battler.prototype.regenerateTp = function() {
      const value = Math.floor(this.maxTp() * this.trg); // 100をmaxTpへ置き換え
      this.gainSilentTp(value);
    };
  }

  if (NLMGparam.initTP0 === "true" || NLMGparam.shareTP === "true") {
    Game_Battler.prototype.initTp = function() { // TP初期値ゼロ
      this.setTp(0);
    };
  }

  const _GB_chargeTpByDamage = Game_Battler.prototype.chargeTpByDamage;
  Game_Battler.prototype.chargeTpByDamage = function(damageRate) { // ダメージによるTP変動値
    const param = Number(NLMGparam.damageTP) || 0;
    const tcrEx = $gameSystem.NLMGtcrEx();
    if (param === -999 && !tcrEx) {
      _GB_chargeTpByDamage.apply(this, arguments);
    } else if (param) {
      const val = param !== -999 ? param : 50 * damageRate;
      const tcr = tcrEx ? 1 : this.tcr;
      this.gainSilentTp(Math.floor(val * tcr));
    }
  };

  if (NLMGparam.shareTP === "true") { // TP共有化（アクターのみ）
    Game_Actor.prototype.initTp = function() {
      const member0 = $gameParty.members()[0];
      if (member0._actorId === this._actorId && !this.isPreserveTp()) {
        this.setTp(0);
      } else {
        this.setTp(member0._tp);
      }
    };

    Game_Actor.prototype.NLMGgainTp = function(value) {
      if (value) {
        this._tp -= value;
        $gameParty.members().forEach((actor) => {
          actor.setTp(actor.tp + value);
        });
      }
    };

    const _Game_Actor_gainTp = Game_Actor.prototype.gainTp;
    Game_Actor.prototype.gainTp = function(value) {
      _Game_Actor_gainTp.apply(this, arguments);
      this.NLMGgainTp(value);
    };

    const _Game_Actor_gainSilentTp = Game_Actor.prototype.gainSilentTp;
    Game_Actor.prototype.gainSilentTp = function(value) {
      _Game_Actor_gainSilentTp.apply(this, arguments);
      this.NLMGgainTp(value);
    };

    Game_Actor.prototype.regenerateTp = function() {
    }; // 削除して、BattleManagerのターン終了処理へ移動

    const _GA_repeatsTargets = Game_Action.prototype.repeatTargets
    Game_Action.prototype.repeatTargets = function(targets) {
      this._NLMGrepeats = this.numRepeats(); // 追加
      return _GA_repeatsTargets.apply(this, arguments);
    };

    const _GA_itemEffectGainTp = Game_Action.prototype.itemEffectGainTp;
    Game_Action.prototype.itemEffectGainTp = function(target, effect) {
      const value = Math.floor(effect.value1);
      if (!this._NLMGeffectGainTp) {
        _GA_itemEffectGainTp.apply(this, arguments);
        this._NLMGrepeats--;
        if (target.isActor() && !this._NLMGrepeats) {
          this._NLMGeffectGainTp = true; // 味方全員対象では繰り返さない
        }
      } else if (value !== 0) {
        this.makeSuccess(target);
      }
    };

    Game_Interpreter.prototype.NLMGevaAll = function(params) { // 対象がパーティ全体か
      const p0 = params[0];
      const p1 = params[1]
      return (!p0 && !p1) || (p0 && !$gameVariables.value(p1));
    };

    const _GI_command326 = Game_Interpreter.prototype.command326;
    Game_Interpreter.prototype.command326 = function(params) { // Change TP
      if (this.NLMGevaAll(params)) {
        const value = this.operateValue(params[2], params[3], params[4]);
        if (value) $gameParty.members()[0].gainTp(value);
        return true;
      } else {
        return _GI_command326.call(this, params);
      }
    };
  }

// Game_Actor関係
  // スキルを戦闘入力時TP・MP即消費に変更
  const _GActor_canPaySkillCost = Game_Actor.prototype.canPaySkillCost;
  Game_Actor.prototype.canPaySkillCost = function(skill) {
    if (BattleManager.NLMGpaidCost()) return true; // 戦闘入力後は消費に関わらず可
    return _GActor_canPaySkillCost.apply(this, arguments);
  };

  Game_Actor.prototype.paySkillCost = function(skill, noQuickSkill) { // QuickSkill判定追加
    const tpc = this.skillTpCost(skill);
    const mpc = this.skillMpCost(skill);
    if (tpc) this.gainSilentTp(-tpc);
    if (mpc) this.gainMp(-mpc);
    if (noQuickSkill) {
      BattleManager._NLMGusedTp.push(tpc);
      BattleManager._NLMGusedMp.push(mpc);
    }
  };

  const _Game_Actor_useItem = Game_Actor.prototype.useItem;
  Game_Actor.prototype.useItem = function(item) { // 戦闘最中はスキルを消費しない
    if (!(BattleManager.NLMGpaidCost() && DataManager.isSkill(item))) {
      _Game_Actor_useItem.apply(this, arguments);
    }
  };

  // カード使用後の処理改変
  const _Game_Actor_consumeItem = Game_Actor.prototype.consumeItem;
  Game_Actor.prototype.consumeItem = function(item) {
    _Game_Actor_consumeItem.apply(this, arguments);
    this.NLMGconsumeItem(item);
  };

  Game_Actor.prototype.NLMGconsumeItem = function(item) {
    const iType = item.itypeId;
    const itId  = $gameTemp.iTypeExchange(item.id, "<", iType);
    if (NLMGparam.deckAnno && BattleManager.NLMGpaidCost()) {
      if (item.consumable) {
        $gameParty.gainCard(itId, 1, 7); // 捨札を1枚増やす
      }
    } else {
      this.NLMGpayItemCost(item, false);
    }
    if (this.NLMGnoCard(itId, iType)) {
      BattleManager.NLMGremoveState(item, iType); // ステートチェック
    }
  };

  Game_Actor.prototype.NLMGnoCard = function(id, iType) {
    if (iType !== 6 && iType !== 8) return false;
    const eva6 = iType === 6 && !$gameTemp.cardnum(id, 6);
    const eva8 = iType === 8 && !$gameTemp.cardnum(id, 8);
    return eva6 || eva8;
  };

  // アイテムにTP・MP消費、スイッチ・アクター制限を勘案
  const _GActor_meetsItemConditions = Game_Actor.prototype.meetsItemConditions;
  Game_Actor.prototype.meetsItemConditions = function(item) {
    return _GActor_meetsItemConditions.apply(this, arguments) && this.NLMGmeetsItemConditions(item);
  };

  Game_Actor.prototype.NLMGmeetsItemConditions = function(item) {
    if (NLMGparam.deckAnno && !$gameParty.inBattle() && item.itypeId !== 2
          && !$gameSystem.NLMGdisableCard()) return true;
    return this.NLMGcanPayItemCost(item) && this.NLMGcanUseByActor(item) && this.NLMGcanUseBySwitch(item);
  };

  Game_Actor.prototype.NLMGitemTpCost = function(item) {
    const tcr  = $gameSystem.NLMGtcrEx() ? this.tcr : 1;
    const cost = $gameTemp.itemTpCost(item) * tcr;
    return DataManager._NLMGtcrRound ? Math.round(cost) : Math.floor(cost);
  };

  Game_Actor.prototype.NLMGitemMpCost = function(item) {
    return Math.floor($gameTemp.itemMpCost(item) * this.mcr);
  };

  Game_Actor.prototype.NLMGcanPayItemCost = function(item) {
    const dis = $gameSystem.NLMGdisableCard();
    if (dis !== 3 && BattleManager.NLMGpaidCost()) return true; // 戦闘最中は消費に関わらずtrue
    if (dis === 2) return true;
    return this._tp >= this.NLMGitemTpCost(item) && this._mp >= this.NLMGitemMpCost(item);
  };

  Game_Actor.prototype.NLMGcanUseByActor = function(item) { // アクター制限判定
    const actors = DataManager.NLMGnxactor(item);
    return !actors.length ? true : actors.includes(this.actorId());
  };

  Game_Actor.prototype.NLMGcanUseBySwitch = function(item) { // メモ「HandUseSw」判定
    const meta = item.meta["HandUseSw"];
    return !meta ? true : $gameSwitches.value(meta);
  };

  Game_Actor.prototype.NLMGpayItemCost = function(item, noQuickSkill) {
    const tpc = this.NLMGitemTpCost(item);
    const mpc = this.NLMGitemMpCost(item);
    if (tpc) this.gainSilentTp(-tpc);
    if (mpc) this.gainMp(-mpc);
    if (noQuickSkill) {
      BattleManager._NLMGconsumedTp.push(tpc);
      BattleManager._NLMGconsumedMp.push(mpc);
    }
  };

  //戦闘SVモーション変更
  const _Game_Actor_performAction = Game_Actor.prototype.performAction;
  Game_Actor.prototype.performAction = function(action) {
    if (action.isItem() && DataManager._NLMGitemSVmotion) {
      Game_Battler.prototype.performAction.apply(this, arguments);
      this.NLMGperformItem(action.item());
    } else if (action.isSkill() && DataManager._NLMGskillSVmotion) {
      Game_Battler.prototype.performAction.apply(this, arguments);
      this.NLMGperformSkill(action);
    } else {
      _Game_Actor_performAction.apply(this, arguments);
    }
  };

  Game_Actor.prototype.NLMGperformItem = function(item) {
    const ncard   = DataManager.NLMGcardData(item);
    const wtypeId = ncard[4];
    const motion  = ncard[5];
    this.NLMGperformAction(wtypeId, motion);
  };

  Game_Actor.prototype.NLMGperformSkill = function(action) {
    const nskill = DataManager.NLMGskillData(action.item());
    const nskil1 = Number(nskill[1]) || 0;
    const nskil2 = nskill[2] ? DataManager.NLMdeleteSpace(nskill[2]) : null;
    let wtypeId  = nskil1;
    let motion   = nskil2;
    if (action.isAttack()) { 　　　// スキルID:1番
      wtypeId = nskill[1] === undefined ? -1 : nskil1;
    } else if (action.isGuard()) { // スキルID:2番
      motion  = nskill[2] === undefined ? "guard" : nskil2;
    } else if (action.isMagicSkill()) {
      motion  = nskill[2] === undefined ? "spell" : nskil2;
    } else {
      motion  = nskill[2] === undefined ? "skill" : nskil2;
    }
    this._NLMGguarding = motion === "guard";
    this.NLMGperformAction(wtypeId, motion);
  };

  Game_Actor.prototype.NLMGperformAction = function(wtypeId, motion) {
    if (wtypeId === -1) {
      this.performAttack();
    } else if (!wtypeId && motion) {
      this.requestMotion(motion);
    } else {
      this.NLMGperformWeapon(wtypeId);
    }
  };

  Game_Actor.prototype.NLMGperformWeapon = function(wtypeId) { // Game_Actor.prototype.performAttackの一部コピー
    const attackMotion = $dataSystem.attackMotions[wtypeId];
    if (attackMotion) {
      if (attackMotion.type === 0) {
        this.requestMotion("thrust");
      } else if (attackMotion.type === 1) {
        this.requestMotion("swing");
      } else if (attackMotion.type === 2) {
        this.requestMotion("missile");
      }
      this.startWeaponAnimation(attackMotion.weaponImageId);
    }
  };

  // スクリプトで独自関数を使用可能にする
  Game_Actor.prototype.cardnum = function(id, iType, element, eId) {
    return $gameTemp.cardnum(id, iType, element, eId);
  };

  Game_Actor.prototype.ncard = function(id, n) {
    return $gameTemp.ncard(id, n);
  };

  Game_Actor.prototype.getTPcost = function(id, isSkill) {
    return $gameTemp.getTPcost(id, isSkill)
  };

  Game_Actor.prototype.getMPcost = function(id, isSkill) {
    return $gameTemp.getMPcost(id, isSkill)
  };

  Game_Actor.prototype.targetIsDead = function(index) {
    return $gameTemp.targetIsDead(index);
  };

  Game_Actor.prototype.targetIsHit = function(index) {
    return $gameTemp.targetIsHit(index);
  };

// Game_Party関係
  Game_Party.prototype.setupBattleTestItems = function() {
  }; // 戦闘テスト時のアイテムなし

  // アイテム個数を消費した分だけ削除して表示
  Game_Party.prototype.NLMGnumItemsForShow = function(item) {
    const num  = this.numItems(item);
    if (BattleManager.isInputting()) {
      return num - BattleManager.NLMGnumConsumedItems(item);
    }
    return num;
  };

  Game_Party.prototype.NLMGnumItypeForShow = function() {
    const sum = [0,0,0,0];
    for (let iType = 5; iType <= 8; iType++) {
      sum[iType - 5] = $gameTemp.cardnum(0, iType);
    }
    return sum;
  };

  // カード増減に関する独自関数（新設）
  Game_Party.prototype.gainCard = function(id, amount, iType) { // カード増減（idはデッキ外ID）
    const item = $dataItems[$gameTemp.iTypeExchange(id, ">", iType)];
    const eva  = amount < 0 && !$gameTemp.cardnum(id, iType);
    if (!item || !amount || item.itypeId !== iType || eva) return false;
    this.gainItem(item, amount);
    if ((iType === 6 || iType === 8) && amount > 0) BattleManager.NLMGaddState(item, iType);
    if (amount < 0 && this.NLMGnoCard(id, iType))   BattleManager.NLMGremoveState(item, iType);
    return true;
  };

  Game_Party.prototype.NLMGnoCard = function(id, iType) {
    if (iType !== 6 && iType !== 8) return false;
    const eva6 = iType === 6 && !$gameTemp.cardnum(id, 6);
    const eva8 = iType === 8 && !$gameTemp.cardnum(id, 8);
    return eva6 || eva8;
  };

  Game_Party.prototype.loseCard = function(id, amount, iType) {
    return this.gainCard(id, -amount, iType);
  };

  Game_Party.prototype.moveCard = function(id, fromItype, toItype) { // カード移動（idはデッキ外ID）
    const item = $dataItems[$gameTemp.iTypeExchange(id, ">", fromItype)];
    const eva1 = item ? item.itypeId === fromItype : false; // 大事なものや隠しアイテムでないこと
    const eva2 = $gameTemp.cardnum(id, fromItype);          // fromItypeにカードが存在すること
    if (eva1 && eva2 && toItype) {
      this.loseCard(id, 1, fromItype);
      this.gainCard(id, 1, toItype);
      return true;
    }
    if (DataManager._NLMGerrorDisp) {
        console.error("ID:" + id + " のカード移動に失敗しました");
    }
    return false;
  };

  Game_Party.prototype.allMoveCard = function(fromItype, toItype) { // 全てのカード種を別のカード種へ移動
    if ((fromItype === 1 || fromItype > 4) && (toItype <= 1 || toItype > 4)) {
      for (let i=1; i <= NLMGitemMaxNum; i++) {
        const n = $gameTemp.cardnum(i, fromItype);
        if (n) {
          this.loseCard(i, n, fromItype);            // 移動元カード種から削除
          if (toItype) this.gainCard(i, n, toItype); // 移動先カード種に追加（toItypeが0の時は削除のみ）
        }
      }
    }
  };

// Game_Character関係（スクリプトで独自関数を使用可能にする）
  Game_Character.prototype.cardnum = function(id, iType, element, eId) {
    return $gameTemp.cardnum(id, iType, element, eId);
  };

  Game_Character.prototype.ncard = function(id, n) {
    return $gameTemp.ncard(id, n);
  };

  Game_Character.prototype.getTPcost = function(id, isSkill) {
    return $gameTemp.getTPcost(id, isSkill)
  };

  Game_Character.prototype.getMPcost = function(id, isSkill) {
    return $gameTemp.getMPcost(id, isSkill)
  };

  Game_Character.prototype.targetIsDead = function(index) {
    return $gameTemp.targetIsDead(index);
  };

  Game_Character.prototype.targetIsHit = function(index) {
    return $gameTemp.targetIsHit(index);
  };

// Game_Interpreter関係（主にカードガチャ処理）
  const _Game_Interpreter_updateChild = Game_Interpreter.prototype.updateChild;
  Game_Interpreter.prototype.updateChild = function() {
    if (_Game_Interpreter_updateChild.call(this)) return true;
    return this.NLMGupdateChild();
  };

  Game_Interpreter.prototype.NLMGupdateChild = function() { // ガチャ処理を割り込み
    if ($gameTemp.NLMGgachaStart() === 1) {
      this.NLMGpreGacha(); // ガチャ前処理
      return true;
    }
    if ($gameMessage.isBusy()) {
      return false;
    }
    switch(this._NLMGgachaProc) {
      case 1:
        this.NLMGcardGacha1(); // ガチャ処理1
        return true;
      case 2:
        this.NLMGcardGacha2(); // ガチャ処理2
        return true;
      case 3:
        this.NLMGcardGacha3(); // ガチャ処理3
        return true;
      case 4:
        this.NLMGpostGacha1(); // ガチャ後処理1
        return true;
      case 5:
        this.NLMGpostGacha2(); // ガチャ後処理2
        return true;
    }
    return false;
  };

  Game_Interpreter.prototype.NLMGreserveEvent = function(id) {
    const commonEvent = $dataCommonEvents[parseInt(id) || 0];
    if (commonEvent) {
        const eventId = this.isOnCurrentMap() ? this._eventId : 0;
        this.setupChild(commonEvent.list, eventId);
    }
  };

  // ガチャ前処理
  Game_Interpreter.prototype.NLMGpreGacha = function() {
    this._NLMGgachaMaxRare = 0;
    ImageManager._NLMGicon = NLMGparam.iconDot;      // アイコン拡大
    this.NLMGreserveEvent(NLMGparam.preGachaCommon); // ガチャ開始前イベント予約
    $gameTemp.NLMGgachaStartSet(2);
    this._NLMGgachaProc = 1;
  };

  // ガチャ処理1（this._NLMGgachaProc === 1）
  Game_Interpreter.prototype.NLMGcardGacha1 = function() {
    if (NLMGvar("gacha") <= 0) { // ガチャ変数がゼロの時
      this._NLMGgachaProc = 4;
    } else { // ガチャ準備
      const confR = $gameTemp.NLMGgachaConfR();
      const confirmed = NLMGvar("gacha") === 1 ? (this._NLMGgachaMaxRare < confR ? confR : 0) : 0;
      const item = $gameTemp.NLMGrandomGacha(confirmed); // ランダムで当選抽出
      $gameTemp.NLMGcardPictureSet(item);  // ピクチャをセット
      if (!item) $gameScreen.NLMGerasePictures(); // ハズレ時
      $gameTemp.appliVar(item); // 該当変数更新
      $gameSystem.gachaItem(item);
      this.NLMGreserveEvent(NLMGparam.justBeforeGachaCommon); // ガチャ直前イベント予約
      this._NLMGgachaItem = item;
      this._NLMGgachaProc = 2;
    }
  };

  // ガチャ処理2（this._NLMGgachaProc === 2）
  Game_Interpreter.prototype.NLMGcardGacha2 = function() {
    const item = this._NLMGgachaItem;
    if (item) {
      const rare = DataManager.NLMGcardData(item)[1];
      if (NLMGparam.gachaDirection) {
        const min  = rare >= (Number(NLMGparam.rareValue) || 1);
        const file = min ? NLMGparam.gachaRareME : NLMGparam.gachaNormalME;
        const vol  = Number(min ? NLMGparam.rareMEVolume : NLMGparam.normalMEVolume) || 90;
        const pit  = Number(min ? NLMGparam.rareMEPitch  : NLMGparam.noramlMEPitch)  || 100;
        if (file) {
          AudioManager.playMe({"name":file, "volume":vol, "pitch":pit, "pan":0}); // ME演奏
        }
        if (NLMGparam.gachaObtainShow === "true") {
          this.NLMGgachaObtainShow(rare);
        }
      }
      $gameParty.gainItem(item, 1); // アイテムを獲得
      if (rare > this._NLMGgachaMaxRare) {this._NLMGgachaMaxRare = rare;}
    } else { // ハズレ時
      if (NLMGparam.gachaDirection) {
        const file2 = NLMGparam.gachaLostME;
        const vol2  = Number(NLMGparam.lostMEVolume) || 90;
        const pit2  = Number(NLMGparam.lostMEPitch)  || 100;
        if (file2) {
          AudioManager.playMe({"name":file2, "volume":vol2, "pitch":pit2, "pan":0}); // ME演奏
        }
      }
      $gameTemp.oneLineDisp(NLMGparam.failGachaDesc, 2); // ガチャはずれ文章
      this.setWaitMode("message");
    }
    this._NLMGgachaProc = 3;
  };


  Game_Interpreter.prototype.NLMGgachaObtainShow = function(rare) {
    const rX = Number(NLMGparam.rareStarX) || 0;
    let star1 = "";
    for (let i=0; i < rare; i++) {
      star1 += DataManager._NLMGgachaStar;
    }
    let space = "";
    for (let j=0; j < 9 - rare; j++) {
      space += " ";
    }
    const star2 = rX > 0 ? star1 : "";
    const color = DataManager._NLMGstarColor
    $gameMessage.setBackground(1);
    $gameMessage.setPositionType(2);
    $gameMessage.add("\x1b>\x1bc[" + color + "]\x1bpx[" + rX + "]"+ space + star2);
    $gameMessage.add("\x1b>\x1bc[0]" + NLMGparam.gachaObtainDesc); // ガチャ獲得デフォルト文章
    this.setWaitMode("message");
  };

  // ガチャ処理3（this._NLMGgachaProc === 3）
  Game_Interpreter.prototype.NLMGcardGacha3 = function() {
    this.NLMGreserveEvent(NLMGparam.justAfterGachaCommon); // ガチャ直後イベント予約
    NLMGvar("gacha", NLMGvar("gacha") - 1); // ガチャ回数変数を-1 
    if (NLMGvar("gacha") <= 0) {
      this._NLMGgachaProc = 4;
    } else {
      this._NLMGgachaProc = 1;
    }
  };

  // ガチャ後処理1（this._NLMGgachaProc = 4）
  Game_Interpreter.prototype.NLMGpostGacha1 = function() {
    if (NLMGvar("gacha") > 0) { // 直後イベントでガチャ回数が増えた場合の対策
      this._NLMGgachaProc = 1;
    } else {
      NLMGvar("gacha", 0);
      this.NLMGreserveEvent(NLMGparam.postGachaCommon); // ガチャ終了後イベント予約
      this._NLMGgachaProc = 5;
    }
  };

  // ガチャ後処理2（this._NLMGgachaProc = 5）
  Game_Interpreter.prototype.NLMGpostGacha2 = function() {
    $gameScreen.NLMGerasePictures();
    ImageManager._NLMGicon = ImageManager.iconWidth; // アイコン戻す
    $gameTemp.NLMGgachaStartSet(0);
    this._NLMGgachaItem = null;
    this._NLMGgachaProc = 0;
  };

  // 敵強制指定プラグインコマンド用
  const _GI_iterateEnemyIndex = Game_Interpreter.prototype.iterateEnemyIndex;
  Game_Interpreter.prototype.iterateEnemyIndex = function(param, callback) {
    const index = $gameSystem.NLMGenemyIndex();
    if (index >= 0) {
      const enemy = $gameTroop.members()[index];
      if (enemy) callback(enemy);
      $gameSystem.NLMGenemyIndex(-1);
    } else {
      _GI_iterateEnemyIndex.apply(this, arguments);
    }
  };

  // スクリプトで独自関数を使用可能にする
  Game_Interpreter.prototype.cardnum = function(id, iType, element, eId) {
    return $gameTemp.cardnum(id, iType, element, eId);
  };

  Game_Interpreter.prototype.ncard = function(id, n) {
    return $gameTemp.ncard(id, n);
  };

  Game_Interpreter.prototype.getTPcost = function(id, isSkill) {
    return $gameTemp.getTPcost(id, isSkill)
  };

  Game_Interpreter.prototype.getMPcost = function(id, isSkill) {
    return $gameTemp.getMPcost(id, isSkill)
  };

  Game_Interpreter.prototype.targetIsDead = function(index) {
    return $gameTemp.targetIsDead(index);
  };

  Game_Interpreter.prototype.targetIsHit = function(index) {
    return $gameTemp.targetIsHit(index);
  };

// Scene_Message関係（アイテム選択の最大高を変更）
  const _SM_eventItemWindowRect = Scene_Message.prototype.eventItemWindowRect;
  Scene_Message.prototype.eventItemWindowRect = function() {
    const rect  = _SM_eventItemWindowRect.call(this);
    rect.height = this.calcWindowHeight(8, true); // 4行から8行に変更
    return rect; 
  };

// Scene_Map関係（戦闘後オートセーブのタイミング変更、NLM_ItemToSummon.jsのrestoreが先）
  const _Scene_Map_update = Scene_Map.prototype.update;
  Scene_Map.prototype.update = function() {
    _Scene_Map_update.apply(this, arguments);
    const BM = BattleManager;
    if (!BM._NLSIrestore && BM._NLMGautosave && !$gameMap.isEventRunning()) {
      BM._NLMGautosave = false;
      if (!DataManager._NLMGnoDeckCheck) DataManager.NLMGdeckCheck();
      if (DataManager._NLMGchangeAutosave || $gameSystem._isNLMitemToSummon) {
        this.requestAutosave();
      }
    }
  };

// Scene_Item関係（メニューアイテム改変）
  const _Scene_Item_create = Scene_Item.prototype.create;
  Scene_Item.prototype.create = function() {
    _Scene_Item_create.apply(this, arguments);
    this.createDeckItemWindow(); // 追加
  };

  Scene_Item.prototype.createDeckItemWindow = function() {
    const rect = this.deckItemWindowRect();
    this._deckItemWindow = new Window_DeckItem(rect);
    this._deckItemWindow.setHelpWindow(this._helpWindow);
    this._deckItemWindow.setHandler("ok",     this.onDeckOk.bind(this));
    this._deckItemWindow.setHandler("cancel", this.onDeckCancel.bind(this));
    this.addWindow(this._deckItemWindow);
    this._deckItemWindow.hide();
    this._NLMGdeckOp = false;
  };

  Scene_Item.prototype.deckItemWindowRect = function() {
    const wx = 0;
    const wy = this._categoryWindow.y;
    const iCol = Window_ItemList.prototype.maxCols();
    const dCol = Window_DeckItem.prototype.maxCols();
    const ww = Math.round(Graphics.boxWidth / iCol * dCol + 12);
    const wh = this.mainAreaBottom() - wy;
    return new Rectangle(wx, wy, ww, wh);
  };

  Scene_Item.prototype.item = function() {
    if (!this._NLMGdeckOp) {
      return this._itemWindow.item();
    } else {
      return this._deckItemWindow.item();
    }
  };

  const _Scene_Item_onItemOk = Scene_Item.prototype.onItemOk;
  Scene_Item.prototype.onItemOk = function() {
    if (this.item().itypeId === 2 || !NLMGparam.deckAnno) {
      _Scene_Item_onItemOk.apply(this, arguments);
    } else {
      this.NLMGonItemOK();
    }
  };

  Scene_Item.prototype.NLMGonItemOK = function() {
    const id    = this.item().id;
    const iType = this.item().itypeId;
    const dAll  = $gameTemp.cardnum(0,5);
    if (this.NLMGnoControl(id)) {  // デッキ操作不可時
      this.NLMGitemBuzzer();
    } else if (NLMGparam.deckMinus === "true" && iType === 5) {
      this.NLMGdeckDecrease(dAll); // デッキを減少
    } else if (NLMGparam.deckPlus  === "true" && iType === 1) {
      this.NLMGdeckIncrease(dAll); // デッキを増加
    } else if (!NLMGparam.deckSwap) {
      this.NLMGitemBuzzer();
    } else {
      this.NLMGdeckWinDisp(); // デッキ交換（デッキウインドウを出す）
    }
  };

  Scene_Item.prototype.NLMGnoControl = function(id) {
    return !NLMGparam.offDeckName || !this.NLMGdeckUseSw(id)
           || $gameSwitches.value(NLMGparam.deckDisableSwitch);
  };

  Scene_Item.prototype.NLMGitemBuzzer = function() {
    SoundManager.playBuzzer();
    this._itemWindow.activate();
  };

  Scene_Item.prototype.NLMGdeckBuzzer = function() {
    SoundManager.playBuzzer();
    this._deckItemWindow.activate();
  };

  Scene_Item.prototype.NLMGplayCardset = function() {
    this.NLMGplaySound();
    this._categoryWindow.refresh();
    this._itemWindow.refresh();
    this._itemWindow.activate();
  };

  Scene_Item.prototype.NLMGplaySound = function() {
    SoundManager.playEquip();
  };

  Scene_Item.prototype.NLMGdeckDecrease = function(dAll) { // デッキを減少
    const id  = this.item().id - NLMGitemMaxNum;
    const min = Number(NLMGparam.deckMin) || 0;
    if (dAll === min && NLMGparam.deckSwap) {
      this.NLMGdeckWinDisp();
    } else if (dAll <= min) {
      this.NLMGitemBuzzer();
    } else {
      $gameParty.moveCard(id, 5, 1);
      this.NLMGplayCardset();
      this.NLMGcursorLeft(id, 0, true);
    }
  };

  Scene_Item.prototype.NLMGdeckIncrease = function(dAll) { // デッキを増加
    const id  = this.item().id;
    const max = DataManager.NLMGdeckMax();
    const eva = this.NLMGsameMax(id) || dAll > max ||
                (dAll === max && !NLMGparam.deckSwap);
    if (eva) {
      this.NLMGitemBuzzer();
    } else if (dAll === max) {
      this.NLMGdeckWinDisp();
    } else {
      $gameParty.moveCard(id, 1, 5);
      this.NLMGplayCardset();
      this.NLMGcursorLeft(0, id, true);
    }
  };

  Scene_Item.prototype.NLMGdeckWinDisp = function() { // デッキウインドウを出す
    const item = this.item();
    this._NLMGpreItem = item;
    this._deckItemWindow._category = NLMGcategory === "deck" ? "item" : "deck";
    this._deckItemWindow.show();
    this._deckItemWindow.activate();
    this._itemWindow.deactivate();
    this._deckItemWindow.refresh();
    this._deckItemWindow.selectLast();
    const rightX = Graphics.boxWidth - this._deckItemWindow.width
    this._deckItemWindow.x = this._itemWindow.NLMGwinHalf() ? 0 : rightX;
    this._NLMGdeckOp = true;
  };

  Scene_Item.prototype.onDeckOk = function() {
    const preId = this._NLMGpreItem.id;
    const id    = this.item().id;
    const max   = NLMGitemMaxNum;
    if (NLMGcategory === "deck") { // デッキから起動し、通常アイテムを開いている
      const preItId = preId - max;
      if (preItId === id || this.NLMGsameMax(id) || !this.NLMGdeckUseSw(id)) {
        this.NLMGdeckBuzzer();
      } else {
        this.NLMGswap(preItId, id);
      }
    } else { // 通常アイテムから起動し、デッキウインドウを開いている
      const itId = id - max;
      if (preId === itId || this.NLMGsameMax(preId) || !this.NLMGdeckUseSw(itId)) {
        this.NLMGdeckBuzzer();
      } else {
        this.NLMGswap(itId, preId);
      }
    }
  };

  Scene_Item.prototype.onDeckCancel = function() {
    this._deckItemWindow.hide();
    this._itemWindow.activate();
    this._NLMGdeckOp = false;
  };

  Scene_Item.prototype.NLMGsameMax = function(id) { // 同一カード最大枚数に達しているか
    return $gameTemp.cardnum(id, 5) >= $gameTemp.ncard(id, 3);
  };

  Scene_Item.prototype.NLMGdeckUseSw = function(id) { // メモ欄「DeckUseSw」判定
    return DataManager.NLMGdeckUseSwitch(id);
  };

  Scene_Item.prototype.NLMGswap = function(deckId, itemId) { // デッキ交換実施
    $gameParty.moveCard(itemId, 1, 5);
    $gameParty.moveCard(deckId, 5, 1);
    this._deckItemWindow.refresh();
    this.NLMGplayCardset();
    this.NLMGcursorLeft(deckId, itemId, false);
    this.onDeckCancel();
  };

  Scene_Item.prototype.NLMGcursorLeft = function(deckId, itemId, dec) {
    if ((this._itemWindow.index() === this._itemWindow.maxItems()) 
       && ((NLMGcategory === "deck" && (!$gameTemp.cardnum(deckId, 5)
       ||  (dec && !DataManager._NLMGdeckNumDisp)))
       ||  (NLMGcategory !== "deck" && (!$gameTemp.cardnum(itemId, 1)
       ||  (dec && NLMGparam.offDeckNumDisp !== "true"))))) {
      this._itemWindow.cursorLeft(); // カードなくなる時カーソルを左へ
    }
  };

// Scene_Skill関係（スキルタイプ選択を省略）
  Scene_Skill.prototype.NLMGnoSkillType = function() {
    return DataManager._NLMGnoSkillType && this._actor.skillTypes().length === 1;
  };

  const _Scene_Skill_start = Scene_Skill.prototype.start;
  Scene_Skill.prototype.start = function() {
    _Scene_Skill_start.apply(this, arguments);
    if (this.NLMGnoSkillType()) {
      this._skillTypeWindow.update();
      this._skillTypeWindow.deactivate();
      this.commandSkill();
    }
  };

  const _SS_createItemWindow = Scene_Skill.prototype.createItemWindow;
  Scene_Skill.prototype.createItemWindow = function() {
    _SS_createItemWindow.apply(this, arguments);
    if (DataManager._NLMGnoSkillType) {
      this._itemWindow.setHandler("pagedown", this.nextActor.bind(this));
      this._itemWindow.setHandler("pageup", this.previousActor.bind(this));
    }
  };

  const _SS_onItemCancel = Scene_Skill.prototype.onItemCancel;
  Scene_Skill.prototype.onItemCancel = function() {
    if (this.NLMGnoSkillType()) {
      this.popScene();
    } else {
      _SS_onItemCancel.apply(this, arguments);
    }
  };

  const _SS_onActorChange = Scene_Skill.prototype.onActorChange;
  Scene_Skill.prototype.onActorChange = function() {
    _SS_onActorChange.apply(this, arguments);
    if (this.NLMGnoSkillType()) {
      this._skillTypeWindow.deactivate();
      this.commandSkill();
    }
  };

// Scene_Battle関係
  // オートセーブのタイミング変更
  const _SB_shouldAutosave = Scene_Battle.prototype.shouldAutosave;
  Scene_Battle.prototype.shouldAutosave = function() {
    return DataManager._NLMGchangeAutosave ? false : _SB_shouldAutosave.call(this);
  };

  // パーティーコマンド消去
  if (NLMGparam.noPartyCommand) {
    const _SB_createPartyCommandWindow = Scene_Battle.prototype.createPartyCommandWindow;
    Scene_Battle.prototype.createPartyCommandWindow = function () {
      _SB_createPartyCommandWindow.apply(this, arguments);
      this._partyCommandWindow.setHandler("cancel", this.commandFight.bind(this));
    };

    const _SB_startPartyCommandSelection = Scene_Battle.prototype.startPartyCommandSelection;
    Scene_Battle.prototype.startPartyCommandSelection = function () {
      if (BattleManager._NLMGpartyCommand || BattleManager.isTpb()) {
        _SB_startPartyCommandSelection.apply(this, arguments);
      } else {
        this.selectNextCommand();
        BattleManager._NLMGpartyCommand = true;
      }
    };
  }

  // 戦闘時優先表示
  const _SB_startActorCommandSelection = Scene_Battle.prototype.startActorCommandSelection;
  Scene_Battle.prototype.startActorCommandSelection = function() {
    _SB_startActorCommandSelection.apply(this, arguments);
    this.NLMGstartActorCommandSelection();
  };

  Scene_Battle.prototype.NLMGstartActorCommandSelection = function() {
    const prior = NLMGparam.battlePriority;
    const actor = BattleManager.actor();
    const cList = DataManager.NLMGcommandList(actor.currentClass());
    const comMod  = NLMGparam.commandAnno === "true";
    const sealed  = NLMGparam.commandSealed;
    const exItem  = comMod ? cList.includes("i") : true;
    const exSkill = comMod ? cList.includes("s") : true;
    if (!NLMGparam.battleCategory && prior === "item") {
      this._itemWindow._actor = actor;
      this._itemWindow.makeItemList();
      if ((this._itemWindow._data.length && exItem) || sealed) {
        this._actorCommandWindow.selectSymbol("item");
        this.commandItem();
      }
    } else if (prior === "item"  && (exItem  || sealed)) {
      this._actorCommandWindow.selectSymbol("item");
      this.commandItem();
    } else if (prior === "skill" && (exSkill || sealed)) {
      this.NLMGcommandSkill(actor, sealed);
    }
  };

  Scene_Battle.prototype.NLMGcommandSkill = function(actor, sealed) {
    const skillTypes = actor.skillTypes();
    if (skillTypes.length || sealed) {
      this._actorCommandWindow.selectSymbol("skill");
      this._skillWindow.setActor(actor);
      this._skillWindow.setStypeId(skillTypes[0]);
      this._skillWindow.refresh();
      this._skillWindow.show();
      this._skillWindow.activate();
      this._statusWindow.hide();
      this._actorCommandWindow.hide();
    }
  };

  if (NLMGparam.battlePriority === "skill" && NLMGparam.commandSealed) {
    Scene_Battle.prototype.onSkillCancel = function() {
      this.commandCancel();
    };
  }

  // 戦闘入力処理変更
  const _SB_selectNextCommand = Scene_Battle.prototype.selectNextCommand;
  Scene_Battle.prototype.selectNextCommand = function () {
    this.NLMGselectNextCommand();
    _SB_selectNextCommand.apply(this, arguments);
  };

  Scene_Battle.prototype.NLMGselectNextCommand = function() {
    if (!NLMGparam.deckAnno && !DataManager._NLMGimmediateConsume) return;
    const BM = BattleManager;
    const action = BM.inputtingAction();
    if (action) {
      const actor = BM.actor();
      if (action.isItem()) {
        const item = action.item();
        if (!BM.NLMGexecQuickSkill(item)) {
          actor.NLMGpayItemCost(item, true); // TP・MPを即消費
          BM._NLMGconsumedItems.push(item);
        } else {
          actor.NLMGpayItemCost(item, false);
        }
        this._itemWindow.refresh();
      } else if (action.isSkill()) {
        const skill = action.item();
        if (!BM.NLMGexecQuickSkill(skill)) {
          actor.paySkillCost(skill, true);  // TP・MPを即消費
          BM._NLMGusedSkills.push(skill);
        } else {
          actor.paySkillCost(skill, false);
        }
      }
    }
  };

  const _SB_selectPreviousCommand = Scene_Battle.prototype.selectPreviousCommand;
  Scene_Battle.prototype.selectPreviousCommand = function () {
    _SB_selectPreviousCommand.apply(this, arguments);
    this.NLMGselectPreviousCommand();
  };

  Scene_Battle.prototype.NLMGselectPreviousCommand = function() {
    if (!NLMGparam.deckAnno && !DataManager._NLMGimmediateConsume) return;
    const action = BattleManager.inputtingAction();
    if (action) {
      const actor = BattleManager.actor();
      if (action.isItem()) {
        BattleManager.NLMGcancelConsumedItem(actor);
        if (NLMGparam.battleCategory) this._categoryWindow.refresh();
        this._itemWindow.NLMGchangeMaxCols(DataManager._NLMGcategoryPriority);
      } else if (action.isSkill()) {
        BattleManager.NLMGcancelUsedSkill(actor);
      }
    }
  };

  // 戦闘で対象が一体の場合、対象選択を省略する
  if (NLMGparam.omitSelection === "true") {
    const _SB_startActorSelection = Scene_Battle.prototype.startActorSelection;
    Scene_Battle.prototype.startActorSelection = function() {
      _SB_startActorSelection.apply(this, arguments);
      if (this._actorWindow.maxItems() === 1) { // 味方一体のとき省略
        this._actorWindow.deactivate();
        this.onActorOk();
      }
    };

    const _SB_startEnemySelection = Scene_Battle.prototype.startEnemySelection;
    Scene_Battle.prototype.startEnemySelection = function() {
      _SB_startEnemySelection.apply(this, arguments);
      if (this._enemyWindow.maxItems() === 1) { // 敵一体のとき省略
        this._enemyWindow.deactivate();
        this.onEnemyOk();
      }
    };
  }

  // コマンド入力後に戦闘ステータスウインドウを閉じる（隠し）
  const _SB_endCommandSelection = Scene_Battle.prototype.endCommandSelection;
  Scene_Battle.prototype.endCommandSelection = function() {
    _SB_endCommandSelection.apply(this, arguments);
    if (DataManager._NLMGnoBattleStatus) this._statusWindow.hide();
  };

  // スクリプトで独自関数を使用可能にする（NLM_AnotherBattleStatusMZ.js用)
  Scene_Battle.prototype.cardnum = function(id, iType, element, eId) {
    return $gameTemp.cardnum(id, iType, element, eId);
  };

  Scene_Battle.prototype.ncard = function(id, n) {
    return $gameTemp.ncard(id, n);
  };

  Scene_Battle.prototype.getTPcost = function(id, isSkill) {
    return $gameTemp.getTPcost(id, isSkill)
  };

  Scene_Battle.prototype.getMPcost = function(id, isSkill) {
    return $gameTemp.getMPcost(id, isSkill)
  };

  Scene_Battle.prototype.targetIsDead = function(index) {
    return $gameTemp.targetIsDead(index);
  };

  Scene_Battle.prototype.targetIsHit = function(index) {
    return $gameTemp.targetIsHit(index);
  };

// 戦闘アイテムカテゴリー新設
  const _Scene_Battle_commandItem = Scene_Battle.prototype.commandItem;
  if (NLMGparam.battleCategory) {
    function Window_BattleItemCategory() { // カテゴリーウインドウ新設
      this.initialize(...arguments);
    }

    Window_BattleItemCategory.prototype = Object.create(Window_ItemCategory.prototype);
    Window_BattleItemCategory.prototype.constructor = Window_BattleItemCategory;

    Window_BattleItemCategory.prototype.initialize = function(rect) {
      Window_HorzCommand.prototype.initialize.apply(this, arguments);
      const frame = DataManager._NLMGcFrameTransparency;
      const back  = DataManager._NLMGcBackTransparency;
      this.frameVisible = frame ? false : true;
      this.backOpacity  = back ? 0 : $gameSystem.windowOpacity();
      this.hide();
    };

    Window_BattleItemCategory.prototype.maxCols = function() {
      return DataManager._NLMGcategorySymbols.length;
    };

    Window_BattleItemCategory.prototype.itemHeight = function() {
      return Window_Selectable.prototype.itemHeight.call(this);
    };

    const _WBIC_drawItem = Window_BattleItemCategory.prototype.drawItem;
    Window_BattleItemCategory.prototype.drawItem = function(index) {
      _WBIC_drawItem.apply(this, arguments);
      this.contents.fontSize = parseInt(DataManager._NLMGcategoryFontSize) || 22;
    };

    Window_BattleItemCategory.prototype.makeCommandList = function() {
      const numI = $gameParty.NLMGnumItypeForShow();
      for (const symbol of DataManager._NLMGcategorySymbols) {
        const disp = this.NLMGnameDisplay(symbol, numI);
        this.addCommand(disp[0], symbol, disp[1]); 
      }
    };

    Window_BattleItemCategory.prototype.NLMGnameDisplay = function(symbol, numI) {
      let name = "", disp = false, num = 1;
      switch (symbol) {
        case "hand":
          name = NLMGparam.handName || "手札";
          disp = DataManager._NLMGhandAllNumDisp;
          num  = numI[1];
          break;
        case "disc":
          name = NLMGparam.discName;
          disp = DataManager._NLMGdiscAllNumDisp;
          num  = numI[2];
          break;
        case "board":
          name = NLMGparam.boardName;
          disp = DataManager._NLMGboardAllNumDisp;
          num  = numI[3];
          break;
        case "deck":
          name = NLMGparam.battleDeckName;
          disp = DataManager._NLMGdeckAllNumDisp;
          num  = numI[0];
          break;
        case "menu":
          name = NLMGparam.menuName;
          break;
      }
      const nDisp   = name + (disp ? "(" + num + ")" : "");
      const enabled = symbol === "deck" ? num && NLMGparam.deckVisual : num;
      return [nDisp, enabled];
    };

    Window_BattleItem.prototype.includes = function(item) {
      if (item && $gameParty.NLMGnumItemsForShow(item) > 0) {
        switch (this._category) {
          case "hand":
            return item.itypeId === 6;
          case "disc":
            return item.itypeId === 7;
          case "board":
            return item.itypeId === 8;
          case "deck":
            return item.itypeId === 5 && NLMGparam.deckVisual;
        }
      }
      return false;
    };

    const _SB_createAllWindows = Scene_Battle.prototype.createAllWindows;
    Scene_Battle.prototype.createAllWindows = function() {
      this.createCategoryWindow();
      _SB_createAllWindows.apply(this, arguments);
    };

    Scene_Battle.prototype.createCategoryWindow = function() {
      const rect = this.categoryWindowRect();
      this._categoryWindow = new Window_BattleItemCategory(rect);
      this._categoryWindow.setHandler("ok", this.onCategoryOk.bind(this));
      this._categoryWindow.setHandler("cancel", this.onCategoryCancel.bind(this));
      this.addWindow(this._categoryWindow);
    };

    Scene_Battle.prototype.categoryWindowRect = function() {
      const dy = DataManager._NLMGcategoryY || 0;
      const ww = Number(NLMGparam.categoryWidth) || 550;
      const wh = this.calcWindowHeight(1, true);
      const wx = DataManager._NLMGcategoryX || 0;
      const wy = dy ? dy : Graphics.boxHeight - this.windowAreaHeight() - wh;
      return new Rectangle(wx, wy, ww, wh);
    };

    Scene_Battle.prototype.onCategoryOk = function() {
      if (this._itemWindow._category === "menu") {
        switch (NLMGparam.menuFunc) {
          case "guard":
            this.commandGuard();
            break;
          case "previous":
            this.selectPreviousCommand();
            break;
          default:
            this.onCategoryCancel();
        }
      } else {
        this._itemWindow.activate();
        this._itemWindow.select(0);
      }
    };

    Scene_Battle.prototype.onCategoryCancel = function() {
      if (NLMGparam.battlePriority === "item" && NLMGparam.commandSealed) {
        this.commandCancel();
      } else {
        this._itemWindow.hide();
        this._categoryWindow.hide();
        this._statusWindow.show();
        this._actorCommandWindow.show();
        this._actorCommandWindow.activate();
      }
    };

    Scene_Battle.prototype.onItemCancel = function() {
      this._itemWindow.deselect();
      this._categoryWindow.activate();
      this._helpWindow.clear();
    };

    const _SB_createItemWindow = Scene_Battle.prototype.createItemWindow;
    Scene_Battle.prototype.createItemWindow = function() {
      _SB_createItemWindow.apply(this, arguments);
      this._categoryWindow.setItemWindow(this._itemWindow);
    };

    const _SB_isAnyInputWindowActive = Scene_Battle.prototype.isAnyInputWindowActive;
    Scene_Battle.prototype.isAnyInputWindowActive = function() {
      if (this._categoryWindow.active) return true;
      return _SB_isAnyInputWindowActive.call(this);
    }; 

    const _SB_hideSubInputWindows = Scene_Battle.prototype.hideSubInputWindows;
    Scene_Battle.prototype.hideSubInputWindows = function() {
      _SB_hideSubInputWindows.apply(this, arguments);
      this._categoryWindow.deactivate();
      this._categoryWindow.hide();
    };

    Scene_Battle.prototype.commandItem = function() {
      const cateP = DataManager._NLMGcategoryPriority;
      this._categoryWindow.selectSymbol(cateP);
      this._itemWindow.NLMGchangeMaxCols(cateP);
      this._itemWindow.setActor(BattleManager.actor());
      this._itemWindow.scrollTo(0, 0);
      this._categoryWindow.refresh();
      this._categoryWindow.show();
      this._helpWindow.clear();
      _Scene_Battle_commandItem.apply(this, arguments);
      if (NLMGparam.handPriority === "true" && this._itemWindow._data.length) {
        this._itemWindow.select(0);
        this._categoryWindow.deactivate();
      } else {
        this._itemWindow.deselect();
        this._itemWindow.deactivate();
        this._categoryWindow.activate();
      }
    };
  } else { // 戦闘カテゴリーウインドウOFF時
    Window_BattleItem.prototype.includes = function(item) {
      const actor = this._actor;
      return item && $gameParty.NLMGnumItemsForShow(item) &&
             NLMGparam.deckAnno ? item.itypeId === 6 : (item.itypeId < 3 && actor && actor.canUse(item));
    };

    Scene_Battle.prototype.commandItem = function() {
      _Scene_Battle_commandItem.apply(this, arguments);
      this._itemWindow.setActor(BattleManager.actor());
    };

    if (NLMGparam.battlePriority === "item" && NLMGparam.commandSealed) {
      Scene_Battle.prototype.onItemCancel = function() {
        this.commandCancel();
      };
    }
  }

// Window_Base関係（計算式やスクリプトで独自関数を使用可能にする）（NLM_CardLayoutMZ.js対策）
  Window_Base.prototype.cardnum = function(id, iType, inclusion) {
    return $gameTemp.cardnum(id, iType, inclusion);
  };

  Window_Base.prototype.ncard = function(id, n) {
    return $gameTemp.ncard(id, n);
  };

  Window_Base.prototype.getTPcost = function(id, isSkill) {
    return $gameTemp.getTPcost(id, isSkill)
  };

  Window_Base.prototype.getMPcost = function(id, isSkill) {
    return $gameTemp.getMPcost(id, isSkill)
  };

// Window_Selectable関係（中央寄せ時のrefresh定義）
  Window_Selectable.prototype.NLMGchangeMaxCols = function(data, iCols) {
    const num = data.length;
    this._NLMGmaxCols = !num && DataManager._NLMGcols0 ? iCols : 
                         num < iCols ? num : iCols;
    this.NLMGrefresh(iCols);
  };

  Window_Selectable.prototype.NLMGrefresh = function(iCols) {
    const gbW   = Graphics.boxWidth;
    const bCols = this.maxCols();
    const extra = !bCols && !DataManager._NLMGcols0 ? 0 : 24
    const width = (gbW - 24) / iCols * bCols + extra;
    this.x      = (gbW - width) / 2;
    this.width  = width;
    Window_Selectable.prototype.refresh.call(this);
  };

// Window_ItemCategory関係（メニューアイテム改変）
  const _Window_ItemCategory_maxCols = Window_ItemCategory.prototype.maxCols;
  Window_ItemCategory.prototype.maxCols = function() {
    const plus = NLMGparam.deckAnno && NLMGparam.offDeckName && this.needsCommand("weapon")
                 && this.needsCommand("armor") && this.needsCommand("keyItem");
    return _Window_ItemCategory_maxCols.call(this) + (plus ? 1 : 0);
  };

  const _Window_ItemCategory_update = Window_ItemCategory.prototype.update;
  Window_ItemCategory.prototype.update = function() {
    _Window_ItemCategory_update.apply(this, arguments);
    NLMGcategory = this.currentSymbol();
  };

  const _WIC_makeCommandList = Window_ItemCategory.prototype.makeCommandList
  Window_ItemCategory.prototype.makeCommandList = function() {
    if (NLMGparam.deckAnno) {
      const wNum = this.NLMGweightDisp();
      this.addCommand((NLMGparam.deckName || "デッキ") + wNum , "deck"); // 「デッキ」追加
      if (NLMGparam.offDeckName) {
        this.addCommand(NLMGparam.offDeckName, "item"); // 通常アイテムを「デッキ外」表示
      }
    }
    _WIC_makeCommandList.apply(this, arguments);
  };

  Window_ItemCategory.prototype.NLMGweightDisp = function() {
    const weight = "(" + $gameTemp.cardnum(0,5);
    switch (NLMGparam.deckWeightDisp) {
      case "デッキ数のみ":
        return weight + ")";
      case "デッキ数/最大数":
        const max = DataManager.NLMGdeckMax();
        return weight + "/" + max + ")";
      default:
        return "";
    }
  };

  const _WIC_needsCommand = Window_ItemCategory.prototype.needsCommand
  Window_ItemCategory.prototype.needsCommand = function(name) {
    return NLMGparam.deckAnno && name === "item" ? false : _WIC_needsCommand.call(this, name);
  }; // 「システム2」のアイテムカテゴリーの「アイテム」は無視

// Window_ItemList関係（メニューアイテム改変）
  const _Window_ItemList_includes = Window_ItemList.prototype.includes;
  Window_ItemList.prototype.includes = function(item) {
    if (this._category === "deck") {
      return DataManager.isItem(item) && item.itypeId === 5;
    } else {
      return _Window_ItemList_includes.apply(this, arguments);
    }
  };

  Window_ItemList.prototype.NLMGwinHalf = function() {
    const index = this.index();
    const col   = Window_ItemList.prototype.maxCols();
    return index % col >= col / 2;
  };

  // 個数を水増しして表示（NLM_ItemDilution.jsを改修して取り込み）
  const _WIL_makeItemList = Window_ItemList.prototype.makeItemList;
  Window_ItemList.prototype.makeItemList = function() {
    if (!this.needsNumber() && SceneManager._scene.constructor !== Scene_Equip) {
      this.NLMGmakeItemList();
    } else {
      _WIL_makeItemList.apply(this, arguments);
    }
  };

  Window_ItemList.prototype.NLMGmakeItemList = function() {
    this._data = [];
    $gameParty.allItems().forEach((tItem) => {
      if (this.includes(tItem)) {
        const num = $gameParty.NLMGnumItemsForShow(tItem);
        for (let j=0; j<num; j++) {this._data.push(tItem);}
      }
    });
  };

  const _WIL_needsNumber = Window_ItemList.prototype.needsNumber;
  Window_ItemList.prototype.needsNumber = function() {
    const bat = $gameParty.inBattle();
    if (!NLMGparam.battleCategory && bat) return false;
    const c = this._category;
    if (c === "deck"  && !DataManager._NLMGdeckNumDisp     && !bat) return false;
    if (c === "deck"  && NLMGparam.bDeckNumDisp !== "true" &&  bat) return false;
    if (c === "item"  && NLMGparam.offDeckNumDisp !== "true") return false;
    if (c === "hand"  && !DataManager._NLMGhandNumDisp)       return false;
    if (c === "disc"  && NLMGparam.discNumDisp    !== "true") return false;
    if (c === "board" && NLMGparam.boardNumDisp   !== "true") return false;
    return _WIL_needsNumber.call(this);
  };

// Window_DeckItem関係（新設）
  function Window_DeckItem() { // 新設
    this.initialize(...arguments);
  }

  Window_DeckItem.prototype = Object.create(Window_ItemList.prototype);
  Window_DeckItem.prototype.constructor = Window_DeckItem;

  Window_DeckItem.prototype.initialize = function(rect) {
    Window_ItemList.prototype.initialize.apply(this, arguments);
    this._actor = null;
  };

  Window_DeckItem.prototype.maxCols = function() {
    return Math.floor(Window_ItemList.prototype.maxCols() / 2);
  };

  Window_DeckItem.prototype.includes = function(item) {
    if (NLMGcategory === "deck") {
      return DataManager.isItem(item) && item.itypeId === 1;
    } else {
      return DataManager.isItem(item) && item.itypeId === 5;
    }
  };

// Window_ShopStatus関係（「持っている数」にデッキ数を追加）
  if (NLMGparam.deckAnno) {
    Window_ShopStatus.prototype.drawPossession = function(x, y) {
      const item = this._item
      const id  = item.id;
      const num = $gameParty.numItems(item) + $gameTemp.cardnum(id,5);
      const width = this.innerWidth - this.itemPadding() - x;
      const possessionWidth = this.textWidth("0000");
      this.changeTextColor(ColorManager.systemColor());
      this.drawText(TextManager.possession, x, y, width - possessionWidth);
      this.resetTextColor();
      this.drawText(num, x, y, width, "right");
    };
  }

// Window_EventItem関係（プラグインコマンド「カード選択」後の処理変更など）
  const _Window_EventItem_initialize = Window_EventItem.prototype.initialize;
  Window_EventItem.prototype.initialize = function(rect) {
    _Window_EventItem_initialize.apply(this, arguments);
    this._NLMGmaxCols = NLCLparam.itemCols || 2;
  };

  const _Window_EventItem_start = Window_EventItem.prototype.start;
  Window_EventItem.prototype.start = function() { // アイテム選択のウインドウ透過（中央寄せ時）
    _Window_EventItem_start.apply(this, arguments);
    const frame = $gameSystem.NLMGeventCentering() && (NLMGparam.frameTransparency
                   || DataManager._NLMGeFrameTransparency);
    const back  = $gameSystem.NLMGeventCentering() && (NLMGparam.backTransparency
                   || DataManager._NLMGeBackTransparency);
    this.frameVisible = frame ? false : true;
    this.backOpacity  = back ? 0 : $gameSystem.windowOpacity();
    if (!this._data.length && !$gameSystem.NLMGeventItemCancel()) {
      $gameSystem.NLMGeventItemCancel(1);
    }
  };

  const _WEI_updateCancelButton = Window_EventItem.prototype.updateCancelButton;
  Window_EventItem.prototype.updateCancelButton = function() {
    if (this._cancelButton && !$gameSystem.NLMGeventItemCancel()) {
      this._cancelButton.visible = false;
    } else {
      _WEI_updateCancelButton.apply(this, arguments);
    }
  };

  const _Window_eventItem_includes = Window_EventItem.prototype.includes;
  Window_EventItem.prototype.includes = function(item) {
    const element = $gameSystem.NLMGmatchCondition();
    const eId     = $gameSystem.NLMGmatchElementId();
    const script  = $gameSystem.NLMGmatchScript();
    return _Window_eventItem_includes.call(this, item)
           && $gameTemp.NLMGmatchCondition(item, element, eId, script);
  };

  const _WEI_needsNumber = Window_EventItem.prototype.needsNumber;
  Window_EventItem.prototype.needsNumber = function() {
    const itypeId = $gameMessage.itemChoiceItypeId();
    const needNum = $gameSystem.NLMGneedsNumber()
    if (needNum) {
      return needNum === 1;
    } else if (itypeId >= 3) {
      return DataManager._NLMGhiddenItemNumber;
    } else {
      return _WEI_needsNumber.call(this);
    }
  };

  const _Window_EventItem_isEnabled = Window_EventItem.prototype.isEnabled;
  Window_EventItem.prototype.isEnabled = function(item) {
    let eva = true;
    if ($gameSystem.NLMGdisableCard() > 1 && item) {
      eva = $gameParty.canUse(item);
    }
    return _Window_EventItem_isEnabled.apply(this, arguments) && eva;
  };

  const _Window_EventItem_onOK = Window_EventItem.prototype.onOk;
  Window_EventItem.prototype.onOk = function() {
    if ($gameSystem.NLMGselectCard()) {
      this.NLMGonOk();
    } else {
      _Window_EventItem_onOK.apply(this, arguments);
    }
  };

  Window_EventItem.prototype.NLMGonOk = function() {
    const item   = this.item();
    const itemId = item ? item.id : 0;
    const iType  = item ? item.itypeId : 0;
    const cId    = $gameTemp.iTypeExchange(itemId, "<", iType);
    $gameVariables.setValue($gameMessage.itemChoiceVariableId(), cId);
    $gameTemp.appliVar($dataItems[cId], iType); // 該当変数セット
    $gameSystem.NLMGeventItemClear();
    this._messageWindow.terminateMessage();
    this.close();
    if ($gameSystem.NLMGpictureNeed()) { // ピクチャセット
      $gameTemp.NLMGcardPictureSet($dataItems[cId]);
      $gameSystem.NLMGpictureNeed(0);
    }
  };

  const _Window_EventItem_onCancel = Window_EventItem.prototype.onCancel
  Window_EventItem.prototype.onCancel = function() {
    if ($gameSystem.NLMGeventItemCancel()) {
      $gameSystem.NLMGeventItemClear();
      if ($gameSystem.NLMGpictureNeed()) {
        $gameSwitches.setValue(NLCLparam.successSwId, false);
        $gameSystem.NLMGpictureNeed(0);
      }
      _Window_EventItem_onCancel.apply(this, arguments);
    }
  };

  // アイテム選択の中央寄せ表示
  const _WEI_updatePlacement = Window_EventItem.prototype.updatePlacement;
  Window_EventItem.prototype.updatePlacement = function() {
    if ($gameSystem.NLMGeventCentering()) {
      const mY = this._messageWindow.y;
      const mH = this._messageWindow.height;
      if (mY >= Graphics.boxHeight / 2) {
        this.y = mY - this.height - 70;
      } else if (mY >= Graphics.boxHeight / 4) {
        this.y = Graphics.boxHeight - this.height;
      } else {
        this.y = mY + this._messageWindow.height + 70;
      }
      this.y += DataManager._NLMGeventItemY;
    } else {
      _WEI_updatePlacement.apply(this, arguments);
    }
  };

  Window_EventItem.prototype.maxCols = function() {
    return this._NLMGmaxCols;
  };

  const _Window_EventItem_refresh = Window_EventItem.prototype.refresh;
  Window_EventItem.prototype.refresh = function() {
    const iCols = Window_ItemList.prototype.maxCols.call(this);
    if ($gameSystem.NLMGeventCentering()) {
      this.makeItemList();
      this.NLMGchangeMaxCols(this._data, iCols);
    } else {
      this._NLMGmaxCols = iCols; 
      const fHeight = DataManager._NLMGeventNormalHeight;
      this.x = 0;
      this.width  = Graphics.boxWidth;
      this.height = Window_Selectable.prototype.fittingHeight(fHeight);
      _Window_EventItem_refresh.apply(this, arguments);
    }
  };

  Window_EventItem.prototype.NLMGrefresh = function() {
    const gbW   = Graphics.boxWidth;
    const iCols = Window_ItemList.prototype.maxCols.call(this);
    const bCols = this.maxCols();
    const extra = !bCols && !DataManager._NLMGcols0 ? 0 : 24
    const width = (gbW - 24) / iCols * bCols + extra;
    const fHeit = DataManager._NLMGeventCenterHeight;
    const heigt = Window_Selectable.prototype.fittingHeight(fHeit);
    this.x      = (gbW - width) / 2;
    this.width  = width;
    this.height = heigt;
    Window_Selectable.prototype.refresh.call(this);
  };

// Window_Message関係（アイコン拡大）
  Window_Message.prototype.drawIcon = function(iconIndex, x, y) {
    const bitmap = ImageManager.loadSystem("IconSet");
    const pw = ImageManager.iconWidth;
    const ph = ImageManager.iconHeight;
    const sx = (iconIndex % 16) * pw;
    const sy = Math.floor(iconIndex / 16) * ph;
    const dot = ImageManager._NLMGicon;
    this.contents.blt(bitmap, sx, sy, pw, ph, x, y, dot, dot); // dotに拡大
  };

  const _Window_Message_processDrawIcon = Window_Message.prototype.processDrawIcon;
  Window_Message.prototype.processDrawIcon = function(iconIndex, textState) {
    _Window_Message_processDrawIcon.apply(this, arguments);
    const iWidth = ImageManager.standardIconWidth || ImageManager.iconWidth; // コアv1.9対策
    textState.x += ImageManager._NLMGicon - iWidth; // 拡大した分ひろげる
  };

// Window_ActorCommand関係（アクターコマンド改造）
  if (NLMGparam.commandAnno === "true") {
    Window_ActorCommand.prototype.makeCommandList = function() {
      this.NLMGmakeCommandList();
  　};

    Window_ActorCommand.prototype.addItemCommand = function() {
      const name = NLMGparam.itemCommandName || textManager.item;
      this.addCommand(name, "item");
    };
  }

  Window_ActorCommand.prototype.NLMGmakeCommandList = function() {
    if (this._actor) {
      const cClass = this._actor.currentClass();
      const list   = DataManager.NLMGcommandList(cClass);
      for (const elm of list) {
        switch (elm) {
          case "a":
            this.addAttackCommand();
            break;
          case "s":
            this.addSkillCommands();
            break;
          case "g":
            this.addGuardCommand();
            break;
          case "i":
            this.addItemCommand();
            break;
        }
      }
    }
  };

// Window_BattleSkill関係（戦闘スキルウインドウ改造）
  const _Window_BattleSkill_initialize = Window_BattleSkill.prototype.initialize;
  Window_BattleSkill.prototype.initialize = function(rect) {
    _Window_BattleSkill_initialize.apply(this, arguments);
    const frame = (NLMGparam.skillCentering && NLMGparam.frameTransparency)
                   || DataManager._NLMGsFrameTransparency;
    const back  = (NLMGparam.skillCentering && NLMGparam.backTransparency)
                   || DataManager._NLMGsBackTransparency;
    this.frameVisible = frame ? false : true;
    this.backOpacity  = back ? 0 : $gameSystem.windowOpacity();
    this._NLMGmaxCols = NLCLparam.skillCols || 2;
  };

  const _Window_BattleSkill_show = Window_BattleSkill.prototype.show;
  Window_BattleSkill.prototype.show = function() {
    this._helpWindow.clear(); // 説明文中の変数を最新のものに更新
    _Window_BattleSkill_show.apply(this, arguments);
  };

  //戦闘スキルの中央寄せ表示
  if (NLMGparam.skillCentering) {
    Window_BattleSkill.prototype.maxCols = function() {
      return this._NLMGmaxCols;
    };

    Window_BattleSkill.prototype.refresh = function() {
      this.makeItemList();
      const iCols = Window_SkillList.prototype.maxCols.call(this);
      this.NLMGchangeMaxCols(this._data, iCols);
    };
  }

// Window_BattleItem関係（戦闘アイテムウインドウ改造）
  const _Window_BattleItem_initialize = Window_BattleItem.prototype.initialize;
  Window_BattleItem.prototype.initialize = function(rect) {
    _Window_BattleItem_initialize.apply(this, arguments);
    const frame = NLMGparam.frameTransparency || DataManager._NLMGiFrameTransparency;
    const back  = NLMGparam.backTransparency  || DataManager._NLMGiBackTransparency;
    this.frameVisible = frame ? false : true;
    this.backOpacity  = back ? 0 : $gameSystem.windowOpacity();
    this._actor = null;
    this._NLMGmaxCols = NLCLparam.itemCols || 2;
  };

  Window_BattleItem.prototype.setActor = function(actor) { // 追加
    if (this._actor !== actor) {
        this._actor = actor;
        this.refresh();
        this.scrollTo(0, 0);
    }
  };

  Window_BattleItem.prototype.isEnabled = function(item) {
      const actor = this._actor;
      return actor && actor.canUse(item);
  };

  const _Window_BattleItem_show = Window_BattleItem.prototype.show;
  Window_BattleItem.prototype.show = function() {
    this._helpWindow.clear(); // 説明文中の変数を最新のものに更新
    _Window_BattleItem_show.apply(this, arguments);
  };

  // 戦闘アイテムの中央寄せ表示
  if (NLMGparam.itemCentering) {
    Window_BattleItem.prototype.maxCols = function() {
      return this._NLMGmaxCols;
    };

    if (!NLMGparam.battleCategory) { // 戦闘カテゴリーを使わない場合
      Window_BattleItem.prototype.refresh = function() {
        this.NLMGchangeMaxCols("hand");
      };
    }
  }

  Window_BattleItem.prototype.setCategory = function(category) {
    if (this._category !== category) {
      this._category = category;
      this.NLMGchangeMaxCols(category);
      this.scrollTo(0, 0);
    } 
  };

  Window_BattleItem.prototype.NLMGchangeMaxCols = function(category) {
    if (NLMGparam.itemCentering) {
      this.makeItemList();
      const iCols = Window_ItemList.prototype.maxCols.call(this);
      if (DataManager.NLMGcentering(category)) {
        const num = this._data.length;
        this._NLMGmaxCols = !num && DataManager._NLMGcols0 ? iCols :
                             num < iCols ? num : iCols;
      } else {
        this._NLMGmaxCols = iCols;
      }
      this.NLMGrefresh(iCols);
    } else {
      this.refresh();
    }
  };

// Window_BattleStatus関係（戦闘ステータスウインドウ改造(隠し))
  const _WBS_refreshBack = Window_BattleStatus.prototype._refreshBack;
  Window_BattleStatus.prototype._refreshBack = function() {
    if (!DataManager._NLMGaBackTransparency) {
      _WBS_refreshBack.apply(this, arguments);
    }
  };

// Window_BattleEnemy関係（戦闘エネミーウインドウ改造)
  const _WBE_refreshFrame = Window_BattleEnemy.prototype._refreshFrame;
  Window_BattleEnemy.prototype._refreshFrame = function() {
    if (!DataManager._NLMGyFrameTransparency) {
      _WBE_refreshFrame.apply(this, arguments);
    }
  };

  const _WBE_refreshBack = Window_BattleEnemy.prototype._refreshBack;
  Window_BattleEnemy.prototype._refreshBack = function() {
    if (!DataManager._NLMGyBackTransparency) {
      _WBE_refreshBack.apply(this, arguments);
    }
  };

  const _WBE_itemRect = Window_BattleEnemy.prototype.itemRect;
  Window_BattleEnemy.prototype.itemRect = function(index) {
    const rect = _WBE_itemRect.apply(this, arguments);
    if (DataManager._NLMGenemyCentering && NLCLparam.enemyOn === "true") {
      const iW   = this.innerWidth;
      const col  = this.maxCols();
      const len  = this._enemies.length;
      if (len < col) {
        rect.x += Math.floor((iW - iW / col * len) / 2);
      }  // エネミーウインドウ中央寄せ
    }
    return rect;
  };

// Sprite_Damage関係（ダメージ倍率％変数が100より大きかった時に色を変える）
  const _Sprite_Damage_damageColor = Sprite_Damage.prototype.damageColor;
  Sprite_Damage.prototype.damageColor = function() {
    const color = DataManager._NLMGdamageColor;
    if (!this._colorType && NLMGvar("damage") > 100 && color) {
      return ColorManager.textColor(color);
    } else {
      return _Sprite_Damage_damageColor.apply(this, arguments);
    }
  };
})();
